"""TCP multiplayer transport for local-host and persistent server sessions."""
import json
import hashlib
import ipaddress
import os
import re
import socket
import subprocess
import threading
import ctypes
import time

PORT = 44121
EMPTY_KEYS = {"left": False, "right": False, "jump": False}


class NetPlay:
    PORT = PORT
    VPN_ADAPTER_MARKERS = (
        "vpn", "wireguard", "wintun", "tailscale", "zerotier", "openvpn",
        "tun/tap", "tun adapter", "tap-windows", "tap adapter", "happ", "xray",
        "nordlynx", "nordvpn", "protonvpn", "mullvad", "expressvpn", "surfshark",
        "cyberghost", "windscribe", "cloudflare warp", "outline", "amnezia",
        "forticlient", "globalprotect", "anyconnect", "cisco secure", "pulse secure",
        "softether", "hamachi", "vyprvpn", "hide.me", "adguard vpn", "psiphon",
    )
    _vpn_cache_lock = threading.Lock()
    _vpn_cache_time = 0.0
    _vpn_cache = ()

    class VPNActiveError(ValueError):
        """Raised when multiplayer is attempted while a VPN adapter is active."""

    @classmethod
    def active_vpn_adapters(cls, refresh=False):
        """Find active VPN-like adapters with an assigned IPv4 address."""
        now = time.monotonic()
        with cls._vpn_cache_lock:
            if not refresh and now - cls._vpn_cache_time < 3.0:
                return list(cls._vpn_cache)
            active = []
            for adapter, address in cls.local_ip_details():
                normalized = adapter.casefold()
                # This is only a route probe label, not proof that a VPN is connected.
                if normalized.startswith("default route"):
                    continue
                if normalized == "vpn" or any(marker in normalized for marker in cls.VPN_ADAPTER_MARKERS):
                    active.append((adapter, address))
            cls._vpn_cache = tuple(active)
            cls._vpn_cache_time = now
            return list(cls._vpn_cache)

    @classmethod
    def vpn_is_active(cls, refresh=False):
        return bool(cls.active_vpn_adapters(refresh=refresh))

    def __init__(self):
        self.role = None
        self.sock = None
        self.listener = None
        self.thread = None
        self.lock = threading.Lock()
        self.messages = []
        self.latest_state = None
        self.remote_keys = {}
        self.clients = {}
        self.client_threads = []
        self.client_names = {}
        self.disconnect_events = []
        self.authenticator = None
        self.reserved_names = set()
        self.connected = False
        self.error = None
        self.player_index = 1
        self.player_name = ""
        self.max_clients = 1
        self._send_lock = threading.Lock()

    @staticmethod
    def password_proof(password):
        return hashlib.pbkdf2_hmac(
            "sha256", str(password).encode("utf-8"), b"stickman-in-mine-login-v1", 150_000
        ).hex()

    @staticmethod
    def local_ip():
        addresses = NetPlay.local_ips()
        return addresses[0] if addresses else "127.0.0.1"

    @staticmethod
    def local_ips():
        return [address for _, address in NetPlay.local_ip_details()]

    @staticmethod
    def local_ip_details():
        """Return usable IPv4 addresses from Wi-Fi, Ethernet, and VPN adapters."""
        addresses = []

        def add_address(value, adapter):
            try:
                address = ipaddress.ip_address(value.strip())
            except ValueError:
                return
            if (address.version == 4 and not address.is_loopback and not address.is_link_local
                    and not address.is_multicast and all(existing != value.strip() for _, existing in addresses)):
                addresses.append((adapter, value.strip()))

        def friendly_adapter_name(adapter, index):
            name = adapter.casefold()
            if any(part in name for part in ("wi-fi", "wifi", "wireless", "wlan", "беспровод")):
                return "Wi-Fi"
            if any(part in name for part in NetPlay.VPN_ADAPTER_MARKERS):
                return "VPN"
            if any(part in name for part in ("ethernet", "ether", "lan", "локальная сеть")):
                return "Ethernet"
            if "default route" in name:
                return "Default route"
            return f"Adapter {index}"

        # On Windows, ipconfig lists every adapter. Keep only IPv4 address
        # lines so gateway and DNS addresses cannot be mistaken for this PC.
        if os.name == "nt":
            try:
                result = subprocess.run(["ipconfig"], capture_output=True, timeout=5,
                                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                adapter_name = "Network adapter"
                try:
                    oem_codepage = int(ctypes.windll.kernel32.GetOEMCP())
                    ipconfig_text = result.stdout.decode(f"cp{oem_codepage}", errors="replace")
                except (AttributeError, OSError, ValueError):
                    ipconfig_text = result.stdout.decode("mbcs", errors="replace")
                for line in ipconfig_text.splitlines():
                    stripped_line = line.strip()
                    if (stripped_line.endswith(":")
                            and any(word in stripped_line.casefold() for word in ("adapter", "адаптер"))):
                        adapter_name = stripped_line.rstrip(":")
                    if any(token in line.casefold() for token in ("ipv4", "ip address", "ip-адрес", "ip-адрес")):
                        for value in re.findall(r"(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)", line):
                            add_address(value, adapter_name)
            except (OSError, subprocess.SubprocessError):
                pass

        # This route probe can reveal an address used by an active VPN even
        # when the adapter's name is not reported by ipconfig.
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("8.8.8.8", 80))
            add_address(probe.getsockname()[0], "Default route (possibly VPN)")
        except OSError:
            pass
        finally:
            probe.close()

        try:
            for entry in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
                add_address(entry[4][0], "Network adapter")
        except OSError:
            pass
        return [(friendly_adapter_name(adapter, index + 1), address)
                for index, (adapter, address) in enumerate(addresses)]

    def host(self, max_clients=1, dedicated=False):
        if self.vpn_is_active(refresh=True):
            raise self.VPNActiveError("Отключите VPN, чтобы играть по сети.")
        self.stop()
        self.role = "server" if dedicated else "host"
        self.max_clients = max(1, min(2, int(max_clients)))
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(("0.0.0.0", PORT))
        self.listener.listen(self.max_clients)
        self.listener.settimeout(0.5)
        self.thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.thread.start()

    def join(self, address, username, password):
        if self.vpn_is_active(refresh=True):
            raise self.VPNActiveError("Отключите VPN, чтобы играть по сети.")
        self.stop()
        if not 6 <= len(str(password)) <= 128:
            raise ValueError("Пароль должен быть длиной от 6 до 128 знаков.")
        address = str(address).strip()
        if not address:
            raise ValueError("Введи IP-адрес сервера, например 192.168.1.25:44121.")

        # The connection screen and Wi-Fi guide show ADDRESS:PORT. Split that
        # form before passing the host to socket.create_connection; otherwise
        # Windows tries to resolve the whole string as a computer name.
        if address.startswith("["):
            closing_bracket = address.find("]")
            if closing_bracket < 0:
                raise ValueError("Проверь адрес: у IPv6-адреса не хватает символа ].")
            host = address[1:closing_bracket].strip()
            port_suffix = address[closing_bracket + 1:].strip()
            if port_suffix:
                if not port_suffix.startswith(":"):
                    raise ValueError("После адреса сервера укажи порт через двоеточие.")
                port_text = port_suffix[1:]
            else:
                port_text = str(PORT)
        elif address.count(":") == 1:
            host, port_text = address.rsplit(":", 1)
            host = host.strip()
            port_text = port_text.strip()
        else:
            host, port_text = address, str(PORT)

        if not host:
            raise ValueError("Не указан адрес сервера.")
        try:
            port = int(port_text)
        except (TypeError, ValueError):
            raise ValueError("Порт должен быть числом, например :44121.") from None
        if not 1 <= port <= 65535:
            raise ValueError("Номер порта должен быть от 1 до 65535.")

        self.role = "client"
        client = socket.create_connection((host, port), timeout=8)
        client.settimeout(8)
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock = client
        self.connected = True
        try:
            password_proof = self.password_proof(password)
            with self._send_lock:
                self._send_socket(client, {"type": "auth", "username": username,
                                           "password": password_proof})
            buffer = b""
            while b"\n" not in buffer:
                packet = client.recv(4096)
                if not packet:
                    raise ConnectionError("Сервер закрыл подключение")
                buffer += packet
            line, buffer = buffer.split(b"\n", 1)
            response = json.loads(line.decode("utf-8"))
            if response.get("type") != "welcome":
                raise ValueError(response.get("message", "Неверный ник или пароль"))
            self.player_index = int(response.get("player_index", 1))
            self.player_name = str(response.get("username", username))
            client.settimeout(None)
            self.thread = threading.Thread(target=self._read_loop,
                                           args=(client, None, buffer), daemon=True)
            self.thread.start()
        except (OSError, ValueError, ConnectionError, json.JSONDecodeError):
            self.connected = False
            self.role = None
            self.sock = None
            client.close()
            raise

    def _accept_loop(self):
        while self.role in ("host", "server"):
            with self.lock:
                if len(self.clients) >= self.max_clients:
                    at_capacity = True
                else:
                    at_capacity = False
            if at_capacity:
                threading.Event().wait(0.1)
                continue
            try:
                connection, _ = self.listener.accept()
                connection.settimeout(None)
                connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                with self.lock:
                    available = [slot for slot in range(self.max_clients) if slot not in self.clients]
                    if not available:
                        connection.close()
                        continue
                    slot = available[0]
                    self.clients[slot] = connection
                    self.remote_keys[slot] = dict(EMPTY_KEYS)
                reader = threading.Thread(target=self._read_loop, args=(connection, slot, b""), daemon=True)
                self.client_threads.append(reader)
                reader.start()
            except socket.timeout:
                continue
            except OSError as error:
                if self.role in ("host", "server"):
                    self.error = str(error)
                return

    def _read_loop(self, connection, slot, initial_buffer=b""):
        buffer = initial_buffer
        authenticated = slot is None
        normal_disconnect = False
        disconnect_reason = "Соединение закрыто без сообщения о нормальном выходе"
        try:
            if slot is not None:
                connection.settimeout(10)
            while self.role is not None:
                chunk = connection.recv(65536)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if not line:
                        continue
                    message = json.loads(line.decode("utf-8"))
                    if message.get("type") in ("leave", "server_stopping"):
                        normal_disconnect = True
                        break
                    if slot is not None and not authenticated:
                        if message.get("type") != "auth" or not callable(self.authenticator):
                            self._send_socket(connection, {"type": "auth_failed", "message": "Нужна регистрация"})
                            return
                        success, reason, username = self.authenticator(
                            message.get("username", ""), message.get("password", ""))
                        if not success:
                            self._send_socket(connection, {"type": "auth_failed", "message": reason})
                            return
                        player_index = 1 if self.role == "host" else slot
                        connection.settimeout(None)
                        with self._send_lock:
                            with self.lock:
                                duplicate = username.casefold() in self.reserved_names or any(
                                    active.casefold() == username.casefold()
                                    for active in self.client_names.values())
                                if not duplicate:
                                    self.client_names[slot] = username
                                    self.connected = True
                            if duplicate:
                                self._send_socket(connection, {"type": "auth_failed",
                                                               "message": "Этот ник уже используется."})
                                return
                            self._send_socket(connection, {"type": "welcome", "player_index": player_index,
                                                           "username": username})
                        authenticated = True
                        continue
                    with self.lock:
                        if message.get("type") == "state":
                            self.latest_state = message.get("data")
                        elif message.get("type") == "welcome" and slot is None:
                            self.player_index = int(message.get("player_index", 1))
                        elif message.get("type") == "keys" and slot is not None:
                            self.remote_keys[slot] = message.get("data", dict(EMPTY_KEYS))
                        elif message.get("type") == "command":
                            self.messages.append({"type": "command", "data": message.get("data", {}), "slot": slot})
                if normal_disconnect:
                    break
        except (OSError, ValueError, json.JSONDecodeError) as error:
            self.error = str(error)
            disconnect_reason = f"{type(error).__name__}: {error}"
        finally:
            if authenticated and not normal_disconnect and self.role is not None:
                with self.lock:
                    self.disconnect_events.append({"slot": slot, "reason": disconnect_reason})
            if slot is None:
                self.connected = False
            else:
                with self.lock:
                    if self.clients.get(slot) is connection:
                        del self.clients[slot]
                    self.remote_keys[slot] = dict(EMPTY_KEYS)
                    self.client_names.pop(slot, None)
                    self.connected = bool(self.client_names)
            try:
                connection.close()
            except OSError:
                pass

    @staticmethod
    def _send_socket(connection, message):
        packet = (json.dumps(message, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
        connection.sendall(packet)

    def send(self, message):
        if self.role == "client":
            if not self.connected or not self.sock:
                return False
            try:
                with self._send_lock:
                    self._send_socket(self.sock, message)
                return True
            except OSError as error:
                self.error = str(error)
                self.connected = False
                return False
        with self.lock:
            connections = [connection for slot, connection in self.clients.items()
                           if slot in self.client_names]
        succeeded = bool(connections)
        for connection in connections:
            try:
                with self._send_lock:
                    self._send_socket(connection, message)
            except OSError:
                succeeded = False
        return succeeded

    def take_messages(self):
        with self.lock:
            result, self.messages = self.messages, []
            return result

    def take_state(self):
        with self.lock:
            result, self.latest_state = self.latest_state, None
            return result

    def get_remote_keys(self, slot=0):
        with self.lock:
            return dict(self.remote_keys.get(slot, EMPTY_KEYS))

    def get_client_names(self):
        with self.lock:
            return dict(self.client_names)

    def take_disconnect_events(self):
        with self.lock:
            result, self.disconnect_events = self.disconnect_events, []
            return result

    @property
    def player_count(self):
        with self.lock:
            return len(self.client_names)

    def stop(self):
        if self.role == "client" and self.connected and self.sock:
            try:
                with self._send_lock:
                    self._send_socket(self.sock, {"type": "leave"})
            except OSError:
                pass
        elif self.role in ("host", "server"):
            with self.lock:
                clients_to_notify = list(self.clients.values())
            for connection in clients_to_notify:
                try:
                    with self._send_lock:
                        self._send_socket(connection, {"type": "server_stopping"})
                except OSError:
                    pass
        self.connected = False
        with self.lock:
            sockets = list(self.clients.values())
        for item in [self.sock, self.listener, *sockets]:
            if item:
                try:
                    item.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    item.close()
                except OSError:
                    pass
        self.sock = self.listener = self.thread = None
        self.role = None
        self.latest_state = None
        self.messages.clear()
        with self.lock:
            self.remote_keys.clear()
            self.clients.clear()
            self.client_names.clear()
            self.messages.clear()
        self.error = None
        self.player_index = 1
        self.player_name = ""
        self.reserved_names.clear()

