# -*- coding: utf-8 -*-
import os
import sys
import asyncio
import random
import time
import json
import io
import re
import math
import zipfile
import subprocess
import hashlib
import hmac
import secrets
import shutil
import threading
import traceback
import ctypes
from difflib import SequenceMatcher

DEDICATED_SERVER_MODE = "--server" in sys.argv
IS_WEB = sys.platform == "emscripten"
if DEDICATED_SERVER_MODE:
    os.environ["SDL_VIDEODRIVER"] = "dummy"
from netplay import NetPlay

try:
    import pygame
except ImportError:
    print("Error: pygame is not installed!")
    input()
    sys.exit()

pygame.init()
if not pygame.mixer.get_init():
    try:
        pygame.mixer.init()
    except pygame.error:
        pass

# Игра рисуется в настоящем Full HD, а не увеличивается с маленького холста.
BASE_WIDTH, BASE_HEIGHT = 1244, 700
DISPLAY_SIZE = (1920, 1080)
SCALE = DISPLAY_SIZE[1] / BASE_HEIGHT
WIDTH, HEIGHT = DISPLAY_SIZE
MAX_PLAYER_HEALTH = 30


def u(value):
    """Переводит размер из прежней игровой сетки в Full HD."""
    return round(value * SCALE)


is_fullscreen = True


def set_borderless_fullscreen():
    """Окно без рамки на весь экран не сворачивается при открытии скриншота Windows."""
    if IS_WEB:
        return pygame.display.set_mode(DISPLAY_SIZE)
    try:
        desktop_width, desktop_height = pygame.display.get_desktop_sizes()[0]
    except (AttributeError, IndexError, pygame.error):
        display_info = pygame.display.Info()
        desktop_width = display_info.current_w or WIDTH
        desktop_height = display_info.current_h or HEIGHT
    return pygame.display.set_mode((desktop_width, desktop_height), pygame.NOFRAME)


def set_maximized_window():
    """Обычное окно на всю рабочую область: видны заголовок и панель задач."""
    window = pygame.display.set_mode((BASE_WIDTH, BASE_HEIGHT), pygame.RESIZABLE)
    if os.name == "nt":
        try:
            window_handle = pygame.display.get_wm_info().get("window")
            if window_handle:
                # Windows сам подгонит окно между заголовком и панелью задач.
                ctypes.windll.user32.ShowWindow(window_handle, 3)  # SW_MAXIMIZE
                pygame.event.pump()
                window = pygame.display.get_surface() or window
        except (AttributeError, OSError, pygame.error):
            pass
    return window


try:
    # Безрамочный полный экран сохраняет размер игры, когда PrintScreen открывает оверлей.
    display_surface = pygame.display.set_mode(DISPLAY_SIZE) if DEDICATED_SERVER_MODE else set_borderless_fullscreen()
except pygame.error:
    display_surface = pygame.display.set_mode(DISPLAY_SIZE, pygame.FULLSCREEN)
screen = pygame.Surface((WIDTH, HEIGHT)).convert()
pygame.display.set_caption("Stickman in Mine — Safe Boot Update! 🏪🕹️")
clock = pygame.time.Clock()
physics_step = 1.0
netplay = NetPlay()
network_remote_keys = {0: {"left": False, "right": False, "jump": False},
                       1: {"left": False, "right": False, "jump": False}}
network_last_state_send = 0.0
network_join_address = ""
network_username = ""
network_password = ""
network_input_focus = "address"
network_error = ""
network_notice = ""

# Тёмная шахта и направленный луч фонарика.
MINE_DARKNESS_ALPHA = 190
MINE_BEAM_LENGTH = u(620)
MINE_BEAM_HALF_HEIGHT = u(190)
MINE_BEAM_START_HALF_HEIGHT = u(24)
mine_lighting_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA).convert_alpha()
mine_light_mask = pygame.Surface((MINE_BEAM_LENGTH + 1, MINE_BEAM_HALF_HEIGHT * 2), pygame.SRCALPHA)
light_center_y = MINE_BEAM_HALF_HEIGHT
for beam_x in range(0, MINE_BEAM_LENGTH, 4):
    distance_ratio = beam_x / MINE_BEAM_LENGTH
    half_height = round(MINE_BEAM_START_HALF_HEIGHT +
                        (MINE_BEAM_HALF_HEIGHT - MINE_BEAM_START_HALF_HEIGHT) * distance_ratio)
    # Луч медленнее теряет силу, поэтому вдали остаётся заметно светлее.
    beam_alpha = round(255 * (1 - distance_ratio) ** 0.65)
    edge_softness = min(u(24), half_height)
    for edge_step in range(6):
        inset = round(edge_softness * edge_step / 5)
        edge_alpha = round(beam_alpha * (0.25 + 0.75 * edge_step / 5))
        top = light_center_y - half_height + inset
        bottom = light_center_y + half_height - inset
        pygame.draw.rect(
            mine_light_mask, (0, 0, 0, edge_alpha),
            pygame.Rect(beam_x, top, min(4, MINE_BEAM_LENGTH - beam_x), max(1, bottom - top))
        )
mine_light_mask_left = pygame.transform.flip(mine_light_mask, True, False)


def apply_mine_lighting(light_sources, darkness_alpha):
    """Затемняет шахту и высветляет лучи только от включённых фонариков."""
    mine_lighting_surface.fill((0, 0, 0, darkness_alpha))
    for light_x, light_y, facing_right in light_sources:
        if facing_right:
            mask, left = mine_light_mask, light_x
        else:
            mask, left = mine_light_mask_left, light_x - MINE_BEAM_LENGTH
        mine_lighting_surface.blit(
            mask,
            (left, light_y - MINE_BEAM_HALF_HEIGHT),
            special_flags=pygame.BLEND_RGBA_SUB
        )
    screen.blit(mine_lighting_surface, (0, 0))


def present_frame():
    if display_surface.get_size() == screen.get_size():
        display_surface.blit(screen, (0, 0))
    else:
        pygame.transform.scale(screen, display_surface.get_size(), display_surface)
    pygame.display.flip()


def to_game_position(position):
    display_width, display_height = display_surface.get_size()
    return (round(position[0] * WIDTH / display_width),
            round(position[1] * HEIGHT / display_height))

# Шрифты создаем сразу на старте
try: 
    font_menu = pygame.font.Font(None, u(36))
    font = pygame.font.Font(None, u(20))
    font_sub = pygame.font.Font(None, u(14))
except: 
    font_menu = pygame.font.SysFont("Arial", u(30))
    font = pygame.font.SysFont("Arial", u(16))
    font_sub = pygame.font.SysFont("Arial", u(12))


def set_language_fonts(language):
    """Подбирает шрифт с буквами выбранного языка."""
    global font_menu, font, font_sub
    family = {"zh": "Microsoft YaHei", "ja": "Yu Gothic UI", "es": "Arial",
              "fr": "Arial", "sr": "Arial"}.get(language)
    if family:
        font_menu = pygame.font.SysFont(family, u(36))
        font = pygame.font.SysFont(family, u(20))
        font_sub = pygame.font.SysFont(family, u(14))

# Путь к текстурам
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
RES_DIR = os.path.join(CURRENT_DIR, "resurspack")
APP_DIR = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else CURRENT_DIR
LOG_DIR = os.path.join(APP_DIR, "logs")
MODS_DIR = os.path.join(APP_DIR, "mods")
WORLDS_DIR = os.path.join(APP_DIR, "worlds")
SETTINGS_PATH = os.path.join(APP_DIR, "settings.json")


def read_game_settings():
    defaults = {"fullscreen": False, "volume": 0.7}
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as settings_file:
            saved = json.load(settings_file)
        if isinstance(saved, dict):
            defaults["fullscreen"] = bool(saved.get("fullscreen", defaults["fullscreen"]))
            defaults["volume"] = max(0.0, min(1.0, float(saved.get("volume", defaults["volume"]))))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass
    return defaults


game_settings = read_game_settings()
master_volume = game_settings["volume"]
is_fullscreen = game_settings["fullscreen"]


def save_game_settings():
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as settings_file:
            json.dump({"fullscreen": is_fullscreen, "volume": master_volume},
                      settings_file, ensure_ascii=False, indent=2)
    except OSError:
        pass


def apply_master_volume():
    if pygame.mixer.get_init():
        pygame.mixer.music.set_volume(master_volume)
        for channel_index in range(pygame.mixer.get_num_channels()):
            pygame.mixer.Channel(channel_index).set_volume(master_volume)


apply_master_volume()

MINE_BREAK_SOUND_PATH = os.path.join(RES_DIR, "sounds", "Sound_Breaking_a_stone.mp3")
MINE_FOOTSTEPS_SOUND_PATH = os.path.join(RES_DIR, "sounds", "the_sound_of_walking_on_stones.mp3")
mine_break_sound_ready = False
mine_footsteps_sound_ready = False
mine_break_sound_stop_at = 0.0
current_game_audio_track = None


def load_mine_break_sound():
    global mine_break_sound_ready, mine_footsteps_sound_ready
    if not pygame.mixer.get_init():
        return
    try:
        pygame.mixer.music.load(MINE_BREAK_SOUND_PATH)
        pygame.mixer.music.set_volume(master_volume)
        mine_break_sound_ready = True
    except pygame.error:
        mine_break_sound_ready = False
    try:
        pygame.mixer.music.load(MINE_FOOTSTEPS_SOUND_PATH)
        pygame.mixer.music.set_volume(master_volume)
        mine_footsteps_sound_ready = True
    except pygame.error:
        mine_footsteps_sound_ready = False
    if mine_break_sound_ready:
        try:
            pygame.mixer.music.load(MINE_BREAK_SOUND_PATH)
            pygame.mixer.music.set_volume(master_volume)
        except pygame.error:
            mine_break_sound_ready = False


def start_game_audio_track(track_name, sound_path):
    global current_game_audio_track
    if current_game_audio_track == track_name and pygame.mixer.music.get_busy():
        return
    pygame.mixer.music.stop()
    pygame.mixer.music.load(sound_path)
    pygame.mixer.music.set_volume(master_volume)
    pygame.mixer.music.play(loops=-1, start=0.0)
    current_game_audio_track = track_name


def play_mine_break_sound():
    global mine_break_sound_stop_at
    if not mine_break_sound_ready:
        return
    try:
        start_game_audio_track("mine_break", MINE_BREAK_SOUND_PATH)
        # Keep the sound going between pickaxe hits; stop if mining pauses.
        mine_break_sound_stop_at = time.monotonic() + 0.7
    except pygame.error:
        mine_break_sound_stop_at = 0.0


def finish_mine_break_sound():
    global mine_break_sound_stop_at
    if mine_break_sound_ready and pygame.mixer.music.get_busy():
        mine_break_sound_stop_at = time.monotonic() + 0.15


def update_mine_footsteps(is_walking_on_stone):
    global current_game_audio_track
    if not mine_footsteps_sound_ready or mine_break_sound_stop_at:
        return
    try:
        if is_walking_on_stone:
            start_game_audio_track("mine_footsteps", MINE_FOOTSTEPS_SOUND_PATH)
        elif current_game_audio_track == "mine_footsteps":
            pygame.mixer.music.fadeout(100)
            current_game_audio_track = None
    except pygame.error:
        current_game_audio_track = None


def update_game_sounds():
    global mine_break_sound_stop_at, current_game_audio_track
    if mine_break_sound_stop_at and time.monotonic() >= mine_break_sound_stop_at:
        pygame.mixer.music.fadeout(120)
        mine_break_sound_stop_at = 0.0
        current_game_audio_track = None


load_mine_break_sound()


if not DEDICATED_SERVER_MODE and not is_fullscreen:
    display_surface = set_maximized_window()
MOD_ITEMS = []
MOD_TEXTURE_PATHS = {}
MOD_TEXTURE_DATA = {}
MOD_DROP_WEIGHTS = {}
MOD_MIN_DEPTHS = {}
MOD_ITEM_EFFECTS = {}
MOD_FOOD_ITEMS = set()
MOD_ITEM_SPEED_DURATIONS = {}
MOD_PIG_DROPS = {}


def load_game_mods():
    """Загружает предметы из папок или JAR-модов, не запуская их Java-код."""
    global MOD_TEXTURE_DATA
    loaded_items = []
    MOD_TEXTURE_DATA = {}
    occupied_ids = {
        "classic_stone", "melon", "raw_pork", "bone", "gelatin", "raspberry", "marmalade",
        "magic_stone", "magic_gold", "ore_iron", "lapis", "amethyst", "aquamarine",
        "sapphire", "ruby", "diamond", "emerald", "kyawthuite", "quartz", "pink_quartz",
        "moon_stone", "green_jade", "amethyst_with_rutile_quartz", "citrine"
    }
    os.makedirs(MODS_DIR, exist_ok=True)
    for mod_name in sorted(os.listdir(MODS_DIR)):
        mod_path = os.path.join(MODS_DIR, mod_name)
        is_archive = os.path.isfile(mod_path) and mod_name.lower().endswith(".jar")
        if is_archive:
            try:
                archive = zipfile.ZipFile(mod_path, "r")
                names_in_archive = archive.namelist()
                if len(names_in_archive) > 1000:
                    archive.close()
                    continue
                manifest_name = "mod.json" if "mod.json" in names_in_archive else "META-INF/stikman/mod.json"
                manifest_info = archive.getinfo(manifest_name)
                if manifest_info.file_size > 1_000_000:
                    archive.close()
                    continue
                mod_data = json.loads(archive.read(manifest_name).decode("utf-8-sig"))
            except (OSError, KeyError, UnicodeError, json.JSONDecodeError, zipfile.BadZipFile):
                continue
        else:
            manifest_path = os.path.join(mod_path, "mod.json")
            if not os.path.isdir(mod_path) or not os.path.isfile(manifest_path):
                continue
            try:
                with open(manifest_path, "r", encoding="utf-8-sig") as mod_file:
                    mod_data = json.load(mod_file)
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                continue
        try:
            if not isinstance(mod_data, dict) or not mod_data.get("enabled", True):
                if is_archive:
                    archive.close()
                continue
            for item_data in mod_data.get("items", []):
                if not isinstance(item_data, dict):
                    continue
                item_id = item_data.get("id", "")
                texture_name = item_data.get("texture", "")
                if (not isinstance(item_id, str) or not re.fullmatch(r"mod_[a-z0-9_]{1,27}", item_id)
                        or item_id in occupied_ids):
                    continue
                if not isinstance(texture_name, str) or not texture_name.lower().endswith(".png"):
                    continue
                texture_path = None
                texture_bytes = None
                if is_archive:
                    safe_name = texture_name.replace("\\", "/")
                    if safe_name.startswith("/") or any(part in ("", ".", "..") for part in safe_name.split("/")):
                        continue
                    try:
                        texture_info = archive.getinfo(safe_name)
                    except KeyError:
                        continue
                    if texture_info.file_size > 8_000_000:
                        continue
                    texture_bytes = archive.read(safe_name)
                else:
                    if os.path.basename(texture_name) != texture_name:
                        continue
                    texture_path = os.path.abspath(os.path.join(mod_path, texture_name))
                    if os.path.commonpath((os.path.abspath(mod_path), texture_path)) != os.path.abspath(mod_path):
                        continue
                    if not os.path.isfile(texture_path):
                        continue
                try:
                    price = max(1, min(1_000_000_000, int(item_data.get("price", 10))))
                    drop_weight = max(0.1, min(100.0, float(item_data.get("drop_weight", 1))))
                    min_depth = max(0, min(100_000, int(item_data.get("min_depth", 0))))
                except (TypeError, ValueError):
                    continue
                names = item_data.get("name", {})
                if isinstance(names, str):
                    names = {"ru": names, "en": names}
                if not isinstance(names, dict):
                    names = {}
                item_type = item_data.get("type", "mineral")
                if item_type not in ("mineral", "food"):
                    continue
                use_effect = item_data.get("use_effect", "")
                if use_effect not in ("", "heal", "heal_speed"):
                    use_effect = ""
                try:
                    use_amount = max(1, min(MAX_PLAYER_HEALTH, int(item_data.get("use_amount", 1))))
                except (TypeError, ValueError, NameError):
                    use_amount = 1
                try:
                    use_duration = max(1, min(60, float(item_data.get("use_duration", 5))))
                    drop_chance = max(0.0, min(1.0, float(item_data.get("drop_chance", 0))))
                except (TypeError, ValueError):
                    continue
                drop_source = item_data.get("drop_source", "")
                if drop_source not in ("", "pig"):
                    drop_source = ""
                if item_type == "food" and use_effect not in ("heal", "heal_speed"):
                    continue
                color = item_data.get("fallback_color", [120, 120, 120])
                if not isinstance(color, list) or len(color) != 3 or any(
                        not isinstance(channel, int) or not 0 <= channel <= 255 for channel in color):
                    color = [120, 120, 120]
                loaded_items.append({
                    "id": item_id,
                    "texture": texture_name,
                    "texture_path": texture_path,
                    "price": price,
                    "drop_weight": drop_weight,
                    "min_depth": min_depth,
                    "use_effect": use_effect,
                    "use_amount": use_amount,
                    "use_duration": use_duration,
                    "type": item_type,
                    "drop_source": drop_source,
                    "drop_chance": drop_chance,
                    "name": {language: str(names.get(language, "")).strip()
                             for language in ("ru", "en", "es", "zh", "ja")},
                    "fallback_color": tuple(color)
                })
                if texture_bytes is not None:
                    MOD_TEXTURE_DATA[item_id] = texture_bytes
                occupied_ids.add(item_id)
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            if is_archive:
                archive.close()
            continue
        if is_archive:
            archive.close()
    return loaded_items


MOD_ITEMS = load_game_mods()
MOD_TEXTURE_PATHS = {item["id"]: item["texture_path"] for item in MOD_ITEMS if item["texture_path"]}
MOD_DROP_WEIGHTS = {item["id"]: item["drop_weight"] for item in MOD_ITEMS}
MOD_MIN_DEPTHS = {item["id"]: item["min_depth"] for item in MOD_ITEMS}
MOD_ITEM_EFFECTS = {item["id"]: (item["use_effect"], item["use_amount"])
                    for item in MOD_ITEMS if item["use_effect"]}
MOD_FOOD_ITEMS = {item["id"] for item in MOD_ITEMS if item["type"] == "food"}
MOD_ITEM_SPEED_DURATIONS = {item["id"]: item["use_duration"] for item in MOD_ITEMS
                            if item["use_effect"] == "heal_speed"}
MOD_PIG_DROPS = {item["id"]: item["drop_chance"] for item in MOD_ITEMS
                 if item["drop_source"] == "pig" and item["drop_chance"] > 0}
RESOURCE_TEXTURE_KEYS = {
    "classic_stone", "magic_stone", "magic_gold", "ore_iron", "lapis", "amethyst",
    "aquamarine", "sapphire", "ruby", "garnet", "diamond", "emerald", "kyawthuite",
    "quartz", "pink_quartz", "moon_stone", "green_jade", "amethyst_with_rutile_quartz", "melon", "citrine",
    "shark_tooth"
}

# Список текстур для поочерёдной загрузки индикатором
texture_files = {
    "jerry_idle": ("Jerry.png", (75, 112), (0, 0, 0)),
    "jerry_left": ("left_leg_running.png", (75, 112), (0, 0, 0)),
    "jerry_right": ("rigt_leg_running.png", (75, 112), (0, 0, 0)),
    "dandelion": ("dandelion.png", (76, 116), (240, 190, 30)),
    "spider": ("spider.png", (72, 84), (145, 95, 70)),
    "web": ("web.png", (42, 42), (230, 230, 230)),
    "parrot": ("parrot.png", (135, 75), (0, 162, 232)),
    "parrot_wing": ("parrot_wing.png", (52, 39), (112, 146, 190)),
    "melon_bush": ("bush_watermelons.png", (150, 64), (35, 125, 45)),
    "raspberry_bush": ("bush_raspberry.png", (108, 64), (35, 135, 55)),
    "studio_logo": ("black_hole_logo.jpg", (480, 270), (12, 15, 25)),
    "boulder_variant_0": ("boulder.png", (145, 190), (120, 120, 120)),
    "boulder_variant_1": ("boulder0.png", (145, 190), (120, 120, 120)),
    "boulder_variant_2": ("boulder1.png", (145, 190), (120, 120, 120)),
    "boulder_variant_3": ("boulder2.png", (145, 190), (120, 120, 120)),
    "boulder_variant_4": ("boulder3.png", (145, 190), (120, 120, 120)),
    "boulder_variant_5": ("boulder4.png", (145, 190), (120, 120, 120)),
    "extract_one": ("Extraction_stage_one.png", (75, 112), (255, 255, 255)),
    "extract_two": ("Extraction_stage_two.png", (75, 112), (255, 255, 255)),
    "extract_three": ("Extraction_stage_three.png", (75, 112), (255, 255, 255)),
    "extract_four": ("Extraction_stage_four.png", (75, 112), (255, 255, 255)),
    "classic_stone": ("classic_stone.png", (40, 40), (120, 120, 120)),
    "stone_block": ("stone_block.png", (48, 48), (120, 120, 120)),
    # Большая картинка залежи. Файл пользователь добавит в resurspack.
    "ore_deposit": ("deposit.png", (220, 170), (95, 91, 88)),
    "citrine": ("citrine.png", (40, 40), (255, 215, 0)),
    "garnet": ("garnet.png", (40, 40), (150, 20, 45)),
    "melon": ("melon.png", (50, 50), (30, 180, 60)),
    "magic_stone": ("magic_stone.png", (40, 40), (150, 0, 255)),
    "magic_gold": ("magic_gold.png", (45, 45), (255, 215, 0)),
    "ore_iron": ("ore_iron.png", (40, 40), (139, 69, 19)),
    "lapis": ("lapis.png", (40, 40), (0, 100, 255)),
    "amethyst": ("amethyst.png", (40, 40), (138, 43, 226)),
    "aquamarine": ("aquamarine.png", (40, 40), (127, 255, 212)),
    "sapphire": ("sapphire.png", (40, 40), (0, 0, 255)),
    "ruby": ("ruby.png", (40, 40), (255, 0, 0)),
    "diamond": ("diamond.png", (40, 40), (0, 240, 255)),
    "emerald": ("emerald.png", (40, 40), (0, 255, 0)),
    "kyawthuite": ("kyawthuite.png", (40, 40), (255, 140, 0)),
    "quartz": ("quartz.png", (70, 40), (245, 240, 210)),
    "pink_quartz": ("pink_quartz.png", (70, 40), (255, 190, 220)),
    "moon_stone": ("moon_stone.png", (70, 40), (120, 200, 255)),
    "green_jade": ("green_jade.png", (70, 40), (70, 190, 110)),
    "amethyst_with_rutile_quartz": ("amethyst_with_rutile_quartz.png", (70, 40), (225, 170, 130)),
    "inventory_slots": ("open_inventory.png", (1487, 504), (185, 122, 87)),
    "mine_plate": ("mine_plate.png", (1487, 504), (65, 60, 58)),
    "store_display": ("store_display.png", (600, 190), (240, 240, 240)),
    "cells": ("cells.png", (280, 120), (80, 80, 80)),
    # Рисунок длинный и плоский, сохраняем его форму вместо растяжения в квадрат.
    "grass_plate": ("grass_plate.png", (WIDTH, round(WIDTH * 343 / 1258)), (34, 139, 34)),
    "sky": ("Sky.png", (WIDTH, round(WIDTH * 167 / 304)), (135, 206, 235)),
    "sky_mine": ("Sky_mine.png", (WIDTH, round(WIDTH * 167 / 304)), (75, 75, 80)),
    "ocean_access": ("access_to_the_ocean.png", (500, 210), (55, 165, 205)),
    "ocean_water": ("water.png", (620, 230), (0, 150, 215)),
    "ocean_boat": ("boat.png", (360, 190), (150, 95, 60)),
    "text_window": ("text_window.png", (760, 428), (45, 48, 55)),
    "assistant_icon": ("assistant.png", (110, 110), (70, 145, 190)),
    "shark_tooth": ("shark_tooth.png", (40, 40), (230, 235, 240)),
    "sell_btn": ("sell.png", (95, 22), (200, 0, 0)),
    "mask": ("Irkutsk_resident's_mask.png", (40, 40), (50, 50, 50)),
    "stone_pick": ("stone_pickaxe.png", (44, 58), (139, 69, 19)),
    "iron_pick": ("iron_pickaxe.png", (30, 50), (192, 192, 192)),
    "gold_pick": ("gold_pickaxe.png", (56, 72), (255, 200, 40)),
    "wood_sword": ("wood_sword.png", (52, 72), (139, 69, 19)),
    "stone_sword": ("stone_sword.png", (52, 72), (130, 130, 130)),
    "iron_sword": ("iron_sword.png", (52, 72), (190, 195, 205)),
    "store_building": ("store.png", (90, 90), (0, 200, 0)),
    "inventory_button": ("inventory.png", (60, 60), (180, 110, 45)),
    "entrance_mine": ("entrance_mine.png", (round(220 * BASE_WIDTH / 1000), round(130 * BASE_WIDTH / 1000)), (80, 80, 80)),
    "flag_ru": ("Russian_languale.png", (160, 100), (0, 0, 255)),
    "flag_en": ("English_languale.png", (160, 100), (255, 0, 0)),
    "flag_es": ("español.png", (160, 100), (255, 0, 0)),
    "flag_zh": ("中文.png", (160, 100), (220, 0, 0)),
    "flag_ja": ("日本語.png", (160, 100), (255, 255, 255)),
    "flag_fr": ("français.png", (160, 100), (30, 85, 190)),
    "flag_sr": ("Српски.png", (160, 100), (200, 40, 55)),
    "exit": ("exit.png", (48, 48), (255, 0, 0))
}
texture_files["one_player"] = ("1_player.png", (170, 150), (200, 35, 45))
if os.path.exists(os.path.join(RES_DIR, "flashlight.png")):
    texture_files["flashlight"] = ("flashlight.png", (75, 24), (225, 225, 120))
for two_player_image in ("2_player.png", "2_players.png", "two_player.png"):
    if os.path.exists(os.path.join(RES_DIR, two_player_image)):
        texture_files["two_player"] = (two_player_image, (170, 150), (200, 35, 45))
        break

for mod_item in MOD_ITEMS:
    texture_files[mod_item["id"]] = (mod_item["texture"], (40, 40), mod_item["fallback_color"])
    RESOURCE_TEXTURE_KEYS.add(mod_item["id"])

# Увеличиваем игровые спрайты и интерфейс до Full HD. Большие фоны уже заданы в Full HD.
for texture_key, (file_name, size, default_color) in list(texture_files.items()):
    if texture_key == "mine_plate":
        # Как grass_plate: растягиваем по ширине экрана, сохраняя пропорции рисунка.
        size = (WIDTH, round(WIDTH * 504 / 1487))
    elif texture_key not in ("inventory_slots", "grass_plate", "sky", "sky_mine"):
        if texture_key in RESOURCE_TEXTURE_KEYS:
            size = (70, 70)
        else:
            size = (u(size[0]), u(size[1]))
        if texture_key in RESOURCE_TEXTURE_KEYS:
            size = (u(size[0]), u(size[1]))
        texture_files[texture_key] = (file_name, size, default_color)

textures = {}

# Фон запуска загружаем заранее, чтобы он был виден с самого первого кадра загрузки.
studio_background = None
try:
    studio_background_path = os.path.join(RES_DIR, "black_hole_logo.jpg")
    if os.path.isfile(studio_background_path):
        studio_background = pygame.image.load(studio_background_path).convert()
        studio_background = pygame.transform.smoothscale(studio_background, (WIDTH, HEIGHT))
except (OSError, pygame.error):
    studio_background = None
studio_background_overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
studio_background_overlay.fill((7, 9, 16, 138))


def draw_studio_background():
    if studio_background is not None:
        screen.blit(studio_background, (0, 0))
    else:
        screen.fill((25, 25, 30))
    screen.blit(studio_background_overlay, (0, 0))


def remove_exterior_white(surface):
    """Быстро прячет внешний белый фон, оставляя белые детали рисунка."""
    width, height = surface.get_size()
    # Pygame строит маску и ищет связанные области в быстром коде, без
    # медленного обхода каждого пикселя отдельной командой Python.
    white_pixels = pygame.mask.from_threshold(
        surface, (255, 255, 255, 255), (5, 5, 5, 254)
    )
    exterior_white = pygame.mask.Mask((width, height))

    for x in range(width):
        for y in (0, height - 1):
            if white_pixels.get_at((x, y)) and not exterior_white.get_at((x, y)):
                exterior_white.draw(white_pixels.connected_component((x, y)), (0, 0))
    for y in range(height):
        for x in (0, width - 1):
            if white_pixels.get_at((x, y)) and not exterior_white.get_at((x, y)):
                exterior_white.draw(white_pixels.connected_component((x, y)), (0, 0))

    if exterior_white.count():
        alpha_mask = exterior_white.to_surface(
            setcolor=(255, 255, 255, 0), unsetcolor=(255, 255, 255, 255)
        )
        surface.blit(alpha_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    return surface

def draw_loading_screen(progress, current_file_name):
    """Отрисовка экрана загрузки с индикатором"""
    draw_studio_background()
    load_title = font_menu.render("LOADING GAME...", True, (255, 255, 255))
    screen.blit(load_title, (WIDTH // 2 - load_title.get_width() // 2, u(250)))
    
    bar_width, bar_height = u(600), u(30)
    bar_x = WIDTH // 2 - bar_width // 2
    bar_y = HEIGHT // 2 - bar_height // 2
    pygame.draw.rect(screen, (60, 60, 65), (bar_x, bar_y, bar_width, bar_height), border_radius=u(5))
    
    current_bar_width = int(bar_width * (progress / 100.0))
    if current_bar_width > 0:
        pygame.draw.rect(screen, (0, 200, 100), (bar_x, bar_y, current_bar_width, bar_height), border_radius=u(5))
        
    percent_txt = font.render(f"{progress}%  |  Loading: {current_file_name}", True, (180, 180, 180))
    screen.blit(percent_txt, (WIDTH // 2 - percent_txt.get_width() // 2, bar_y + u(50)))
    present_frame()

# === ЭТАП 1: БЕЗОПАСНАЯ ЗАГРУЗКА РЕСУРСОВ (БЕЗ ФАЛЬШ-ВЫЛЕТОВ) ===
total_items = len(texture_files)
current_item_index = 0
for key, info in texture_files.items():
    file_name, size, default_color = info
    current_item_index += 1
    progress = int((current_item_index / total_items) * 100)
    
    # Очищаем очередь событий, но не выключаем игру во время загрузки!
    pygame.event.pump()
    draw_loading_screen(progress, file_name)
    
    full_path = MOD_TEXTURE_PATHS.get(key, os.path.join(RES_DIR, file_name))
    loaded = False
    if key in MOD_TEXTURE_DATA or os.path.exists(full_path):
        try:
            if key in MOD_TEXTURE_DATA:
                img = pygame.image.load(io.BytesIO(MOD_TEXTURE_DATA[key])).convert_alpha()
            else:
                img = pygame.image.load(full_path).convert_alpha()
            if key == "parrot":
                # Убираем белый холст и сохраняем крыло отдельно для анимации взмахов.
                img.set_colorkey((255, 255, 255))
                bounds = img.get_bounding_rect()
                img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                texture = pygame.Surface(size, pygame.SRCALPHA)
                fitted_image = pygame.transform.scale(img, fitted_size).convert_alpha()
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            elif key == "parrot_wing":
                # Это отдельный рисунок крыла: его можно оставить, меняя parrot.png.
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size).convert_alpha()
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            elif key in ("melon_bush", "raspberry_bush", "ocean_access", "ocean_water", "ocean_boat", "assistant_icon"):
                # Убираем белый фон у новых рисунков и оставляем только их содержимое.
                img = remove_exterior_white(img)
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                if key == "melon_bush":
                    # Куст арбузов делаем шире, чтобы он читался как куст, а не как огурец.
                    textures[key] = pygame.transform.scale(img, size).convert_alpha()
                else:
                    fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                    fitted_size = (max(1, round(img.get_width() * fit_scale)),
                                   max(1, round(img.get_height() * fit_scale)))
                    fitted_image = pygame.transform.scale(img, fitted_size).convert_alpha()
                    texture = pygame.Surface(size, pygame.SRCALPHA)
                    texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                                (size[1] - fitted_size[1]) // 2))
                    textures[key] = texture.convert_alpha()
                loaded = True
            elif key in ("spider", "web"):
                # У паука прозрачный фон, а у паутины убираем белое поле снаружи.
                if key == "web":
                    img.set_colorkey((255, 255, 255))
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size).convert_alpha()
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            if key in ("grass_plate", "mine_plate"):
                # У платформ белый фон; делаем его прозрачным, как у grass_plate.
                img.set_colorkey((255, 255, 255))
            if key == "ore_deposit":
                # Месторождение нарисовано на белом холсте; белое делаем прозрачным.
                img.set_colorkey((255, 255, 255))
            if key == "store_display":
                # Срезаем пустые поля вокруг витрины, сохраняя белый фон ячеек.
                img = img.subsurface(pygame.Rect(120, 226, 1145, 362)).copy()
            if key == "cells":
                # Убираем белые поля и оставляем рамки ячеек прозрачными поверх игры.
                img.set_colorkey((255, 255, 255))
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
            if key == "dandelion":
                # Убираем большой белый холст и сохраняем нарисованную форму цветка.
                img.set_colorkey((255, 255, 255))
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
            if key == "citrine":
                # Убираем только внешний белый фон, оставляя белые грани кристалла.
                img = remove_exterior_white(img)
            if key.startswith("boulder_variant_"):
                # У валунов белый фон, а рисунок обрезаем и вписываем в общий размер.
                img.set_colorkey((255, 255, 255))
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            if key in ("one_player", "two_player"):
                # Удаляем белое снаружи круглой кнопки, сохраняя белые детали внутри.
                icon_mask = pygame.Surface(img.get_size(), pygame.SRCALPHA)
                pygame.draw.ellipse(icon_mask, (255, 255, 255, 255),
                                    pygame.Rect(12, 10, img.get_width() - 24, img.get_height() - 20))
                img.blit(icon_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            if key == "flashlight":
                # Вырезаем нарисованный фонарик с большого белого холста.
                img = img.subsurface(pygame.Rect(442, 772, 437, 143)).copy()
                flashlight_mask = pygame.Surface(img.get_size(), pygame.SRCALPHA)
                pygame.draw.rect(flashlight_mask, (255, 255, 255, 255),
                                 pygame.Rect(0, 23, 395, 94), border_radius=16)
                pygame.draw.ellipse(flashlight_mask, (255, 255, 255, 255),
                                    pygame.Rect(389, 0, 48, 143))
                img.blit(flashlight_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            if key == "exit":
                # Обрезаем белые поля, сохраняя белый крестик внутри красного круга.
                white_mask = pygame.mask.from_threshold(img, (255, 255, 255), (10, 10, 10, 255))
                white_mask.invert()
                non_white_bounds = white_mask.get_bounding_rects()
                if non_white_bounds:
                    bounds = non_white_bounds[0].unionall(non_white_bounds[1:])
                    img = img.subsurface(bounds).copy()
                    # Маска делает прозрачными углы вокруг круга, не трогая крестик.
                    radius = min(img.get_width(), img.get_height()) // 2
                    circle_mask = pygame.Surface(img.get_size(), pygame.SRCALPHA)
                    pygame.draw.circle(circle_mask, (255, 255, 255, 255),
                                       (img.get_width() // 2, img.get_height() // 2), radius)
                    img.blit(circle_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            if key in ("jerry_idle", "jerry_left", "jerry_right"):
                # Кадры бега имеют большие прозрачные поля: обрезаем их, чтобы Джерри не уменьшался при беге.
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
            if key.startswith("extract_"):
                # Вырезаем прозрачные поля и вписываем кадр в размер Джерри без искажения.
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            if key in ("parrot", "parrot_wing", "spider", "web"):
                pass
            elif key in ("stone_pick", "iron_pick", "gold_pick", "wood_sword", "stone_sword", "iron_sword"):
                # На рисунках предметы лежат на большом прозрачном холсте: обрезаем пустоту.
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            if key in ("parrot", "parrot_wing", "spider", "web"):
                pass
            elif key.startswith("flag_"):
                # У карточек языков большие белые поля: убираем их, оставляя белые детали внутри рисунка.
                img = remove_exterior_white(img)
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
                loaded = True
            elif key.startswith("extract_") or key.startswith("boulder_variant_") or key in ("stone_pick", "iron_pick", "gold_pick", "wood_sword", "stone_sword", "iron_sword"):
                pass
            elif key == "shark_tooth":
                # У авторской текстуры белый холст, оставляем прозрачным только внешний фон.
                img = remove_exterior_white(img)
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)), max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2, (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
            elif key in RESOURCE_TEXTURE_KEYS:
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)), max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2, (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
            elif key == "stone_block":
                # Убираем белый холст вокруг авторской текстуры и вписываем рисунок в форму блока.
                img = remove_exterior_white(img)
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                textures[key] = pygame.transform.scale(img, size).convert_alpha()
            elif key == "ore_deposit":
                # У рисунка месторождения большие пустые поля: обрезаем их и сохраняем пропорции.
                bounds = img.get_bounding_rect()
                if bounds.width and bounds.height:
                    img = img.subsurface(bounds).copy()
                fit_scale = min(size[0] / img.get_width(), size[1] / img.get_height())
                fitted_size = (max(1, round(img.get_width() * fit_scale)),
                               max(1, round(img.get_height() * fit_scale)))
                fitted_image = pygame.transform.scale(img, fitted_size)
                texture = pygame.Surface(size, pygame.SRCALPHA)
                texture.blit(fitted_image, ((size[0] - fitted_size[0]) // 2,
                                            (size[1] - fitted_size[1]) // 2))
                textures[key] = texture.convert_alpha()
            elif "emerald" in file_name.lower(): textures[key] = pygame.transform.scale(img, size).convert()
            else: textures[key] = pygame.transform.scale(img, size).convert_alpha()
            loaded = True
        except Exception: pass
    if not loaded:
        surf = pygame.Surface(size)
        if key == "ore_deposit":
            # Временный простой рисунок из каменных форм до появления авторской картинки.
            surf = pygame.Surface(size, pygame.SRCALPHA)
            deposit_shape = [(u(12), u(105)), (u(28), u(55)), (u(76), u(28)),
                             (u(116), u(42)), (u(165), u(25)), (size[0] - u(12), u(70)),
                             (size[0] - u(20), size[1] - u(10)), (u(30), size[1] - u(8))]
            pygame.draw.polygon(surf, (112, 108, 103), deposit_shape)
            for shard_x, shard_y in ((u(60), u(80)), (u(127), u(68)), (u(176), u(111))):
                pygame.draw.polygon(surf, (75, 72, 70), [(shard_x, shard_y),
                                   (shard_x + u(22), shard_y - u(12)),
                                   (shard_x + u(37), shard_y + u(8)),
                                   (shard_x + u(12), shard_y + u(21))])
            pygame.draw.polygon(surf, (35, 33, 32), deposit_shape, max(1, u(3)))
        else:
            surf.fill(default_color)
        textures[key] = surf


def make_inventory_icon(item):
    icon = pygame.Surface((u(52), u(52)), pygame.SRCALPHA)
    if item == "fish":
        pygame.draw.ellipse(icon, (75, 160, 210), (u(7), u(14), u(36), u(25)))
        pygame.draw.polygon(icon, (50, 125, 185), [(u(39), u(26)), (u(49), u(17)), (u(49), u(35))])
        pygame.draw.circle(icon, (255, 255, 255), (u(17), u(23)), u(3))
        pygame.draw.circle(icon, (20, 30, 40), (u(18), u(23)), u(1))
        pygame.draw.arc(icon, (180, 225, 245), (u(18), u(17), u(16), u(18)), 0.4, 2.4, max(1, u(2)))
    elif item == "raw_pork":
        pygame.draw.ellipse(icon, (185, 58, 67), (u(7), u(14), u(38), u(25)))
        pygame.draw.ellipse(icon, (255, 205, 195), (u(18), u(19), u(19), u(13)))
        pygame.draw.ellipse(icon, (255, 240, 220), (u(23), u(22), u(8), u(6)))
    elif item == "bone":
        pygame.draw.line(icon, (240, 231, 202), (u(15), u(37)), (u(37), u(15)), u(9))
        for point in ((u(13), u(39)), (u(10), u(32)), (u(39), u(13)), (u(32), u(10))):
            pygame.draw.circle(icon, (248, 242, 220), point, u(7))
        pygame.draw.line(icon, (180, 161, 124), (u(15), u(37)), (u(37), u(15)), max(1, u(1)))
    elif item == "raspberry":
        for row, count in enumerate((2, 3, 2)):
            for column in range(count):
                pygame.draw.circle(icon, (200, 35 + row * 8, 90),
                                   (u(15 + column * 12 + row * 5), u(17 + row * 10)), u(8))
        pygame.draw.polygon(icon, (40, 145, 55), [(u(16), u(17)), (u(25), u(7)), (u(34), u(17))])
    elif item == "gelatin":
        pygame.draw.rect(icon, (225, 115, 170, 225), (u(10), u(12), u(32), u(32)), border_radius=u(5))
        pygame.draw.rect(icon, (255, 210, 235), (u(15), u(16), u(10), u(7)), border_radius=u(3))
        pygame.draw.rect(icon, (120, 55, 90), (u(10), u(12), u(32), u(32)), max(1, u(2)), border_radius=u(5))
    else:
        pygame.draw.ellipse(icon, (220, 65, 90), (u(9), u(9), u(34), u(38)))
        pygame.draw.ellipse(icon, (250, 140, 115), (u(15), u(14), u(11), u(8)))
        pygame.draw.ellipse(icon, (80, 145, 55), (u(19), u(7), u(17), u(8)))
    return icon


def make_abyss_pickaxe():
    """Нарисованная в пиксельном стиле кирка бездны, без отдельного файла картинки."""
    pickaxe = pygame.Surface((u(58), u(70)), pygame.SRCALPHA)
    pygame.draw.line(pickaxe, (25, 18, 34), (u(15), u(65)), (u(39), u(18)), u(10))
    pygame.draw.line(pickaxe, (123, 74, 151), (u(15), u(63)), (u(39), u(18)), u(4))
    head = [(u(5), u(20)), (u(12), u(7)), (u(33), u(4)), (u(54), u(16)),
            (u(44), u(27)), (u(25), u(22)), (u(12), u(29))]
    pygame.draw.polygon(pickaxe, (30, 17, 53), head)
    pygame.draw.polygon(pickaxe, (118, 48, 196),
                        [(u(8), u(18)), (u(14), u(10)), (u(32), u(8)),
                         (u(46), u(16)), (u(41), u(21)), (u(23), u(17)), (u(13), u(24))])
    pygame.draw.polygon(pickaxe, (55, 215, 255),
                        [(u(14), u(12)), (u(23), u(10)), (u(18), u(17)), (u(11), u(20))])
    pygame.draw.line(pickaxe, (10, 8, 20), (u(5), u(20)), (u(12), u(7)), max(1, u(2)))
    pygame.draw.line(pickaxe, (10, 8, 20), (u(12), u(7)), (u(33), u(4)), max(1, u(2)))
    pygame.draw.line(pickaxe, (10, 8, 20), (u(33), u(4)), (u(54), u(16)), max(1, u(2)))
    pygame.draw.line(pickaxe, (10, 8, 20), (u(54), u(16)), (u(44), u(27)), max(1, u(2)))
    return pickaxe


for inventory_item in ("raw_pork", "bone", "gelatin", "raspberry", "marmalade", "fish"):
    textures[inventory_item] = make_inventory_icon(inventory_item)
textures["abyss_pick"] = make_abyss_pickaxe()
textures["sell_button"] = pygame.transform.scale(textures["sell_btn"], (u(84), u(18)))
textures["fishing_rod"] = pygame.Surface((u(48), u(48)), pygame.SRCALPHA)
pygame.draw.line(textures["fishing_rod"], (104, 66, 38), (u(8), u(42)), (u(35), u(7)), u(4))
pygame.draw.line(textures["fishing_rod"], (225, 215, 190), (u(35), u(7)), (u(41), u(39)), max(1, u(1)))
pygame.draw.circle(textures["fishing_rod"], (240, 70, 70), (u(41), u(39)), u(3))

flashlight_equipped = "flashlight" in textures
flashlight_on = False
selected_tool = "pickaxe"
show_hitboxes = False
boulder_size = (u(145), u(190))
boulder_textures = [textures[f"boulder_variant_{index}"] for index in range(6)]
boulder_masks = [pygame.mask.from_surface(texture) for texture in boulder_textures]
small_rock_texture = pygame.transform.scale(textures["classic_stone"], (u(28), u(25)))
BLOCK_SIZE = u(48)
stone_block_texture = pygame.transform.scale(textures["stone_block"], (BLOCK_SIZE, BLOCK_SIZE))
PLAYER_SPRITE_KEYS = ("jerry_idle", "jerry_left", "jerry_right",
                      "extract_one", "extract_two", "extract_three", "extract_four")
# Сохраняем высоту персонажа, но вписываем его по ширине в один каменный блок.
player_render_textures = {
    key: pygame.transform.scale(textures[key], (BLOCK_SIZE, textures[key].get_height()))
    for key in PLAYER_SPRITE_KEYS if key in textures
}


dandelion_texture = textures["dandelion"]
spider_texture = textures["spider"]
web_texture = textures["web"]

# Берём одну ячейку из рисунка инвентаря и повторяем её для всех предметов.
inventory_slot_source = textures["inventory_slots"].subsurface(pygame.Rect(48, 29, 285, 424)).copy()
inventory_slot_texture = pygame.transform.scale(inventory_slot_source, (u(88), u(130)))

# Локализация
LANG_PACK = {
    "ru": {
        "title": "Выбери язык / Choose Language",
        "hero": "Герой (20 лет, смелый и равнодушный)",
        "controls": "Управление: A/D - Бег, Пробел - Прыжок, E - Войти/выйти из шахты",
        "controls_p1": "Игрок 1: A / D — идти, Пробел — прыгать",
        "controls_p2": "Игрок 2: ← / → — идти, ↑ — прыгать",
        "network_host_address": "Адрес для друга:",
        "flashlight_hint": "В шахте нажми 2, чтобы взять фонарик, потом F — включить свет",
        "flashlight_on": "Фонарик включён",
        "flashlight_off": "Фонарик выключен",
        "no_flashlight": "Сначала нужен фонарик",
        "choose_flashlight": "Нажми 2, чтобы взять фонарик",
        "hotbar_pickaxe": "КИРКА",
        "hotbar_abyss": "БЕЗДНА",
        "hotbar_flashlight": "СВЕТ",
        "hotbar_blocks": "БЛОКИ",
        "hotbar_empty": "ПУСТО",
        "hotbar_sword": "МЕЧ",
        "hotbar_melon": "АРБУЗ",
        "need_sword": "Сначала купи меч в магазине",
        "boulder_stone": "Валун разбит! +15 камня",
        "boulder_bonus": "Валун разбит! +15 камня и {} × {}",
        "boulder_hp": "Прочность: {}",
        "hitboxes_on": "Показ хитбоксов включён (F3)",
        "hitboxes_off": "Показ хитбоксов выключен (F3)",
        "saving": "Сохраняем прогресс…",
        "player_hp": "Здоровье: {} из 30",
        "flower_hit": "Одуванчик получил удар! Осталось здоровья: {}",
        "flower_hit_sword": "Удар мечом! У одуванчика осталось здоровья: {}",
        "flower_need_weapon": "Выбери кирку (1) или купленный меч (3)",
        "flower_defeated": "Одуванчик побеждён! Выпало: 2 маг. камня и 15 алмазов",
        "flower_attacked": "Одуванчик атаковал!",
        "flower_knocked_out": "Одуванчик победил! Ты вернулся ко входу в шахту.",
        "parrot_bite": "Попугай клюнул! -29 здоровья",
        "parrot_knockout": "Попугай клюнул! Ты потерял сознание и вернулся на поверхность.",
        "pet_success": "Ты погладил персонажа!",
        "spider_slow": "Паутина замедлила тебя!",
        "spider_frozen": "Ты запутался в паутине! Заморозка на 10 секунд!",
        "select_players": "Выбери количество игроков",
        "one_player_label": "1 ИГРОК",
        "two_player_label": "2 ИГРОКА",
        "enter_mine": "E — войти в шахту",
        "leave_mine": "E — выйти на поверхность",
        "ocean_hint": "E — отправиться в океан / вернуться на берег",
        "entered_ocean": "Ты отправился в океан!",
        "returned_ocean": "Ты вернулся на берег!",
        "balance": "Баланс: {} Громок 💰",
        "store_name": "Магазин кирок",
        "inv_title": "🎒 ИНВЕНТАРЬ:",
        "sell": "ПРОДАТЬ",
        "sell_all": "ВСЁ",
        "eat": "ЕСТЬ",
        "grind": "МОЛОТЬ",
        "craft_marmalade": "СДЕЛАТЬ",
        "need_sword_pig": "Возьми меч, чтобы прогнать свинью",
        "pig_hit": "Свинья получила удар! Осталось здоровья: {}",
        "critical_hit": "Критический удар! -{} урона, осталось здоровья: {}",
        "pvp_hit": "Ты ударил другого игрока: -{} здоровья!",
        "pvp_knockout": "Игрок выбыл и появился снова с полным здоровьем!",
        "pig_killed": "Выпало: сырая свинина и кости!",
        "gathered_melon": "Собрал арбузы: +{}",
        "gathered_raspberry": "Собрал малину: +{}",
        "made_gelatin": "Перемолол 2 кости в желатин!",
        "made_marmalade": "Смешал малину с желатином: получился мармелад!",
        "need_recipe_items": "Нужна малина и желатин",
        "gather_hint": "E — собрать",
        "pig_hint": "Нажми на свинью с мечом",
        "ate_melon": "Арбуз восстановил {} HP и ускорил тебя на 5 секунд!",
        "ready": "Ты готов к суете!",
        "mined": "Добыто: {}! ✔️",
        "deposit_mined": "+5 камня, опыт +10{}",
        "deposit_hit": "Удар киркой: -{} прочности (осталось {})",
        "entered_mine": "Ты вошёл в шахту!",
        "returned_surface": "Ты вышел на поверхность!",
        "close": "Закрыть: Esc",
        "mods_loaded": "Добавлено модами минералов: {}",
        "abyss_secret": "Чёрная дыра забрала предметы! Получена кирка бездны!",
        "empty": "Ресурса нет! ❌",
        "sold": "Продано за {} громок! 💰",
        "refresh": "Пещера обновилась!",
        "passive": "[Кьявтуит принёс +{} громок!]",
        "store_title": "🏪 МАГАЗИН КИРОК:",
        "store_item_iron": "Железная кирка",
        "store_item_gold": "Золотая кирка (ресурсы X3)",
        "store_item_sword": "Деревянный меч",
        "store_item_stone_sword": "Каменный меч", "store_item_iron_sword": "Железный меч",
        "not_available": "Этот предмет пока нельзя купить",
        "iron_pick_name": "Железная кирка (Ресурсы X2)",
        "buy": "КУПИТЬ ({} Гр.)",
        "store_item_owned": "Уже куплено",
        "owned": "КУПЛЕНО ✔️",
        "no_money": "Не хватает громок! ❌"
    },
    "en": {
        "title": "Choose Language / Выбери язык",
        "hero": "Hero (20 y.o., brave and indifferent)",
        "controls": "Controls: A/D - Run, Space - Jump, E - Enter/leave mine",
        "controls_p1": "Player 1: A / D — move, Space — jump",
        "controls_p2": "Player 2: ← / → — move, ↑ — jump",
        "network_host_address": "Address for your friend:",
        "flashlight_hint": "In the mine, press 2 to hold the flashlight, then F to toggle its light",
        "flashlight_on": "Flashlight on",
        "flashlight_off": "Flashlight off",
        "no_flashlight": "You need a flashlight first",
        "choose_flashlight": "Press 2 to hold the flashlight",
        "hotbar_pickaxe": "PICKAXE",
        "hotbar_abyss": "ABYSS",
        "hotbar_flashlight": "LIGHT",
        "hotbar_blocks": "BLOCKS",
        "hotbar_empty": "EMPTY",
        "hotbar_sword": "SWORD",
        "hotbar_melon": "MELON",
        "need_sword": "Buy the sword in the shop first",
        "boulder_stone": "Boulder broken! +15 stone",
        "boulder_bonus": "Boulder broken! +15 stone and {} × {}",
        "boulder_hp": "Durability: {}",
        "hitboxes_on": "Hitbox display on (F3)",
        "hitboxes_off": "Hitbox display off (F3)",
        "saving": "Saving progress…",
        "player_hp": "Health: {} of 30",
        "flower_hit": "Dandelion hit! Health left: {}",
        "flower_hit_sword": "Sword hit! Dandelion health left: {}",
        "flower_need_weapon": "Select the pickaxe (1) or your sword (3)",
        "flower_defeated": "Dandelion defeated! Drops: 2 magic stones and 15 diamonds",
        "flower_attacked": "The dandelion attacked!",
        "flower_knocked_out": "The dandelion knocked you out! You returned to the mine entrance.",
        "parrot_bite": "The parrot bit you! -29 health",
        "parrot_knockout": "The parrot knocked you out! You returned to the surface.",
        "pet_success": "You petted the character!",
        "spider_slow": "The web slowed you down!",
        "spider_frozen": "You are caught in a web! Frozen for 10 seconds!",
        "select_players": "Choose number of players",
        "one_player_label": "1 PLAYER",
        "two_player_label": "2 PLAYERS",
        "enter_mine": "E — enter the mine",
        "leave_mine": "E — return to the surface",
        "ocean_hint": "E — sail to the ocean / return to shore",
        "entered_ocean": "You sailed into the ocean!",
        "returned_ocean": "You returned to shore!",
        "balance": "Balance: {} Gromki 💰",
        "store_name": "Pickaxe shop",
        "inv_title": "🎒 INVENTORY:",
        "sell": "SELL",
        "sell_all": "ALL",
        "eat": "EAT",
        "grind": "GRIND",
        "craft_marmalade": "CRAFT",
        "need_sword_pig": "Select the sword to hunt the pig",
        "pig_hit": "Pig hit! Health left: {}",
        "critical_hit": "Critical hit! -{} damage, health left: {}",
        "pvp_hit": "You hit the other player for {} damage!",
        "pvp_knockout": "The player respawned with full health!",
        "pig_killed": "Dropped: raw pork and bones!",
        "gathered_melon": "Watermelons collected: +{}",
        "gathered_raspberry": "Raspberries collected: +{}",
        "made_gelatin": "Ground 2 bones into gelatin!",
        "made_marmalade": "Mixed raspberry and gelatin into marmalade!",
        "need_recipe_items": "You need raspberry and gelatin",
        "gather_hint": "E — gather",
        "pig_hint": "Click a pig with the sword",
        "ate_melon": "The watermelon restored {} HP and made you faster for 5 seconds!",
        "ready": "You are ready for action!",
        "mined": "Mined: {}! ✔️",
        "deposit_mined": "+5 stone, +10 XP{}",
        "deposit_hit": "Pickaxe hit: -{} durability ({} left)",
        "entered_mine": "You entered the mine!",
        "returned_surface": "You returned to the surface!",
        "close": "Close: Esc",
        "mods_loaded": "Minerals added by mods: {}",
        "abyss_secret": "The black hole took everything! Abyss pickaxe acquired!",
        "empty": "No items! ❌",
        "sold": "Sold for {} gromki! 💰",
        "refresh": "Cave refreshed!",
        "passive": "[Kyawthuite generated +{} gromki!]",
        "store_title": "🏪 PICKAXE STORE:",
        "store_item_iron": "Iron pickaxe",
        "store_item_gold": "Gold pickaxe (resources X3)",
        "store_item_sword": "Wooden sword",
        "store_item_stone_sword": "Stone sword", "store_item_iron_sword": "Iron sword",
        "not_available": "This item cannot be bought yet",
        "iron_pick_name": "Iron Pickaxe (Resources X2)",
        "buy": "BUY ({} Gr.)",
        "store_item_owned": "Already bought",
        "owned": "OWNED ✔️",
        "no_money": "Not enough money! ❌"
    }
}

LANG_PACK["es"] = {
    "title": "Elige idioma", "hero": "Héroe (20 años, valiente, tranquilo)",
    "controls": "Controles: A/D correr, Espacio saltar, E entrar o salir de la mina",
    "controls_p1": "Jugador 1: A / D — moverse, Espacio — saltar",
    "controls_p2": "Jugador 2: ← / → — moverse, ↑ — saltar",
    "network_host_address": "Dirección para tu amigo:",
    "flashlight_hint": "En la mina: pulsa 2 para tomar la linterna y F para encenderla",
    "flashlight_on": "Linterna encendida", "flashlight_off": "Linterna apagada",
    "no_flashlight": "Primero necesitas una linterna", "choose_flashlight": "Pulsa 2 para tomar la linterna",
    "hotbar_pickaxe": "PICO", "hotbar_flashlight": "LUZ", "hotbar_blocks": "BLOQUES", "hotbar_empty": "VACÍO",
    "hotbar_sword": "ESPADA", "hotbar_melon": "MELÓN", "need_sword": "Compra primero una espada",
    "boulder_stone": "¡Roca rota! +15 de piedra", "boulder_bonus": "¡Roca rota! +15 de piedra y {} × {}",
    "boulder_hp": "Resistencia: {}", "hitboxes_on": "Cajas de colisión activadas (F3)",
    "hitboxes_off": "Cajas de colisión desactivadas (F3)", "saving": "Guardando progreso…",
    "player_hp": "Salud: {} de 30", "flower_hit": "¡Golpe al diente de león! Salud restante: {}",
    "flower_hit_sword": "¡Golpe de espada! Salud del diente de león: {}",
    "flower_need_weapon": "Elige el pico (1) o la espada comprada (3)",
    "flower_defeated": "¡Diente de león derrotado! Obtuviste 2 piedras mágicas y 15 diamantes",
    "flower_attacked": "¡El diente de león atacó!",
    "flower_knocked_out": "¡El diente de león te venció! Volviste a la entrada de la mina.",
    "select_players": "Elige el número de jugadores", "one_player_label": "1 JUGADOR",
    "two_player_label": "2 JUGADORES", "enter_mine": "E — entrar en la mina",
    "leave_mine": "E — salir a la superficie", "ocean_hint": "E — navegar al océano / volver a la costa",
    "entered_ocean": "¡Zarpaste hacia el océano!", "returned_ocean": "¡Volviste a la costa!",
    "balance": "Saldo: {} Gromki 💰",
    "store_name": "Tienda de picos", "inv_title": "🎒 INVENTARIO:", "sell": "VENDER", "sell_all": "TODO",
    "eat": "COMER", "grind": "MOLER", "craft_marmalade": "CREAR",
    "need_sword_pig": "Elige la espada para cazar al cerdo", "pig_hit": "¡Cerdo golpeado! Salud restante: {}",
    "critical_hit": "¡Golpe crítico! -{} de daño, salud restante: {}",
    "pvp_hit": "¡Golpeaste al otro jugador: -{} de salud!", "pvp_knockout": "¡El jugador reapareció con toda la salud!",
    "pig_killed": "Obtuviste: carne de cerdo cruda y huesos", "gathered_melon": "Melones recogidos: +{}",
    "gathered_raspberry": "Frambuesas recogidas: +{}", "made_gelatin": "¡Moliste 2 huesos y obtuviste gelatina!",
    "made_marmalade": "¡Mezclaste frambuesa y gelatina para hacer mermelada!",
    "need_recipe_items": "Necesitas frambuesa y gelatina", "gather_hint": "E — recoger",
    "pig_hint": "Haz clic en el cerdo con la espada",
    "ate_melon": "El melón restauró {} HP y te aceleró durante 5 segundos!",
    "ready": "¡Estás listo!", "mined": "¡Extraído: {}! ✔️",
    "deposit_mined": "+5 de piedra, +10 XP{}", "deposit_hit": "Golpe de pico: -{} de resistencia (quedan {})",
    "empty": "¡No tienes ese objeto! ❌", "sold": "Vendido por {} Gromki 💰",
    "refresh": "¡La mina se ha renovado!", "passive": "[¡Kyawthuite generó +{} Gromki!]",
    "store_title": "🏪 TIENDA DE PICOS:", "store_item_iron": "Pico de hierro",
    "store_item_gold": "Pico de oro (recursos ×3)", "store_item_sword": "Espada de madera",
    "store_item_stone_sword": "Espada de piedra", "store_item_iron_sword": "Espada de hierro",
    "not_available": "Este objeto aún no se puede comprar", "iron_pick_name": "Pico de hierro (recursos ×2)",
    "buy": "COMPRAR ({} Gromki)", "store_item_owned": "Ya lo tienes", "owned": "COMPRADO ✔️",
    "no_money": "¡No tienes suficiente dinero! ❌", "entered_mine": "¡Entraste en la mina!",
    "returned_surface": "¡Volviste a la superficie!", "close": "Cerrar: Esc",
    "mods_loaded": "Minerales añadidos por mods: {}",
    "hotbar_abyss": "ABISMO", "abyss_secret": "¡El agujero negro se lo llevó todo! ¡Pico del abismo obtenido!",
    "parrot_bite": "¡El loro te picó! -29 de salud",
    "parrot_knockout": "¡El loro te dejó inconsciente! Volviste a la superficie.",
    "pet_success": "¡Has acariciado al personaje!",
        "spider_slow": "¡La telaraña te ralentizó!",
        "spider_frozen": "¡Estás atrapado en la telaraña! Inmovilizado 10 segundos.",
}

LANG_PACK["zh"] = {
    "title": "选择语言", "hero": "英雄（20岁，勇敢，冷静）",
    "controls": "操作：A/D奔跑，空格跳跃，E进出矿洞",
    "controls_p1": "玩家1：A / D — 移动，空格 — 跳跃",
    "controls_p2": "玩家2：← / → — 移动，↑ — 跳跃",
    "network_host_address": "好友连接地址：",
    "flashlight_hint": "在矿洞按2拿手电筒，再按F开灯", "flashlight_on": "手电筒已打开",
    "flashlight_off": "手电筒已关闭", "no_flashlight": "你还没有手电筒",
    "choose_flashlight": "按2拿手电筒", "hotbar_pickaxe": "镐子", "hotbar_flashlight": "灯", "hotbar_blocks": "方块",
    "hotbar_empty": "空", "hotbar_sword": "剑", "hotbar_melon": "西瓜", "need_sword": "先去商店买剑",
    "boulder_stone": "石块碎了！+15石头", "boulder_bonus": "石块碎了！+15石头和{} × {}",
    "boulder_hp": "耐久：{}", "hitboxes_on": "碰撞框已开启（F3）",
    "hitboxes_off": "碰撞框已关闭（F3）", "saving": "正在保存进度…", "player_hp": "生命值：{} / 30",
    "flower_hit": "蒲公英被击中！剩余生命：{}", "flower_hit_sword": "剑击中！蒲公英剩余生命：{}",
    "flower_need_weapon": "选择镐子（1）或已购买的剑（3）",
    "flower_defeated": "蒲公英被打败了！获得2块魔法石和15颗钻石",
    "flower_attacked": "蒲公英攻击了！", "flower_knocked_out": "你被蒲公英打败了！回到了矿洞入口。",
    "select_players": "选择玩家人数", "one_player_label": "单人游戏", "two_player_label": "双人游戏",
    "enter_mine": "E — 进入矿洞", "leave_mine": "E — 返回地面",
    "ocean_hint": "E — 驶向海洋 / 返回海岸", "entered_ocean": "你驶向了海洋！",
    "returned_ocean": "你回到了海岸！", "balance": "余额：{} Gromki 💰",
    "store_name": "矿镐商店", "inv_title": "🎒 背包：", "sell": "出售", "sell_all": "全部", "eat": "吃",
    "grind": "研磨", "craft_marmalade": "制作", "need_sword_pig": "拿起剑来打猎",
    "pig_hit": "猪被击中！剩余生命：{}", "critical_hit": "暴击！造成{}点伤害，剩余生命：{}", "pig_killed": "获得：生猪肉和骨头",
    "pvp_hit": "你击中了另一位玩家，造成{}点伤害！", "pvp_knockout": "玩家倒下后以满生命值重生！",
    "gathered_melon": "收集到西瓜：+{}", "gathered_raspberry": "收集到树莓：+{}",
    "made_gelatin": "用2根骨头磨成了明胶！", "made_marmalade": "用树莓和明胶做成了软糖！",
    "need_recipe_items": "需要树莓和明胶", "gather_hint": "E — 收集", "pig_hint": "拿剑点击猪",
    "ate_melon": "西瓜恢复了{}点生命，并让你加速5秒！", "ready": "准备好了！",
    "mined": "开采到：{}！✔️", "deposit_mined": "+5石头，+10经验{}",
    "deposit_hit": "镐子攻击：耐久-{}（剩余{}）", "empty": "没有这个物品！❌",
    "sold": "卖出获得{} Gromki 💰", "refresh": "矿洞已更新！",
    "passive": "[Kyawthuite产生了+{} Gromki！]", "store_title": "🏪 矿镐商店：",
    "store_item_iron": "铁镐", "store_item_gold": "金镐（资源×3）", "store_item_sword": "木剑",
    "store_item_stone_sword": "石剑", "store_item_iron_sword": "铁剑",
    "not_available": "暂时无法购买此物品", "iron_pick_name": "铁镐（资源×2）",
    "buy": "购买（{} Gromki）", "store_item_owned": "已经拥有", "owned": "已购买 ✔️",
    "no_money": "钱不够！❌", "entered_mine": "你进入了矿洞！", "returned_surface": "你回到了地面！",
    "close": "关闭：Esc", "mods_loaded": "模组添加的矿物：{}",
    "hotbar_abyss": "深渊", "abyss_secret": "黑洞带走了所有物品！获得深渊镐！",
    "parrot_bite": "鹦鹉啄了你！生命值 -29",
    "parrot_knockout": "鹦鹉把你啄晕了！你回到了地面。",
    "pet_success": "你抚摸了这个角色！",
        "spider_slow": "蛛网让你减速了！",
        "spider_frozen": "你被蛛网缠住了！冻结10秒！",
}

LANG_PACK["ja"] = {
    "title": "言語を選んでください", "hero": "主人公（20歳、勇敢でおだやか）",
    "controls": "操作：A/Dで走る、Spaceでジャンプ、Eで鉱山に出入り",
    "controls_p1": "プレイヤー1：A / D — 移動、Space — ジャンプ",
    "controls_p2": "プレイヤー2：← / → — 移動、↑ — ジャンプ",
    "network_host_address": "友達に伝えるアドレス：",
    "flashlight_hint": "鉱山で2を押して懐中電灯を持ち、Fで点灯",
    "flashlight_on": "懐中電灯を点灯", "flashlight_off": "懐中電灯を消灯",
    "no_flashlight": "先に懐中電灯が必要です", "choose_flashlight": "2を押して懐中電灯を持つ",
    "hotbar_pickaxe": "ツルハシ", "hotbar_flashlight": "ライト", "hotbar_blocks": "ブロック", "hotbar_empty": "空",
    "hotbar_sword": "剣", "hotbar_melon": "スイカ", "need_sword": "先に店で剣を買ってください",
    "boulder_stone": "岩を破壊！石 +15", "boulder_bonus": "岩を破壊！石 +15 と {} × {}",
    "boulder_hp": "耐久力：{}", "hitboxes_on": "当たり判定を表示（F3）",
    "hitboxes_off": "当たり判定を非表示（F3）", "saving": "進行状況を保存中…",
    "player_hp": "体力：{} / 30", "flower_hit": "タンポポに命中！残り体力：{}",
    "flower_hit_sword": "剣で攻撃！タンポポの残り体力：{}",
    "flower_need_weapon": "ツルハシ（1）か購入した剣（3）を選んでください",
    "flower_defeated": "タンポポを倒した！魔法の石2個とダイヤ15個を獲得",
    "flower_attacked": "タンポポが攻撃した！", "flower_knocked_out": "タンポポに負けた！鉱山の入口に戻ります。",
    "select_players": "プレイヤー数を選択", "one_player_label": "1人プレイ", "two_player_label": "2人プレイ",
    "enter_mine": "E — 鉱山に入る", "leave_mine": "E — 地上に戻る",
    "ocean_hint": "E — 海へ出る / 岸へ戻る", "entered_ocean": "海へ出発しました！",
    "returned_ocean": "岸に戻りました！", "balance": "所持金：{} Gromki 💰",
    "store_name": "ツルハシ店", "inv_title": "🎒 インベントリ：", "sell": "売る", "sell_all": "全部",
    "eat": "食べる", "grind": "砕く", "craft_marmalade": "作る",
    "need_sword_pig": "剣を選んでブタを狩ろう", "pig_hit": "ブタに命中！残り体力：{}",
    "critical_hit": "クリティカル！{}ダメージ、残り体力：{}",
    "pvp_hit": "相手のプレイヤーに{}ダメージ！", "pvp_knockout": "相手は体力満タンで復活！",
    "pig_killed": "生の豚肉と骨を獲得", "gathered_melon": "スイカを収穫：+{}",
    "gathered_raspberry": "ラズベリーを収穫：+{}", "made_gelatin": "骨2個からゼラチンを作った！",
    "made_marmalade": "ラズベリーとゼラチンでグミを作った！",
    "need_recipe_items": "ラズベリーとゼラチンが必要です", "gather_hint": "E — 収穫",
    "pig_hint": "剣を持ってブタをクリック", "ate_melon": "スイカで体力が{}回復し、5秒間速くなった！",
    "ready": "準備完了！", "mined": "採掘：{}！✔️",
    "deposit_mined": "石 +5、経験値 +10{}", "deposit_hit": "ツルハシ攻撃：耐久力 -{}（残り{}）",
    "empty": "そのアイテムはありません！❌", "sold": "{} Gromkiで売却 💰",
    "refresh": "鉱山が更新された！", "passive": "[Kyawthuiteが{} Gromkiを生成！]",
    "store_title": "🏪 ツルハシ店：", "store_item_iron": "鉄のツルハシ",
    "store_item_gold": "金のツルハシ（資源×3）", "store_item_sword": "木の剣",
    "store_item_stone_sword": "石の剣", "store_item_iron_sword": "鉄の剣",
    "not_available": "このアイテムはまだ買えません", "iron_pick_name": "鉄のツルハシ（資源×2）",
    "buy": "購入（{} Gromki）", "store_item_owned": "すでに持っています", "owned": "購入済み ✔️",
    "no_money": "お金が足りません！❌", "entered_mine": "鉱山に入りました！",
    "returned_surface": "地上に戻りました！", "close": "閉じる：Esc",
    "mods_loaded": "MODで追加された鉱物：{}",
    "hotbar_abyss": "深淵", "abyss_secret": "ブラックホールが全部吸い込んだ！深淵のツルハシを入手！",
    "parrot_bite": "オウムに噛まれた！体力 -29",
    "parrot_knockout": "オウムに気絶させられた！地上に戻りました。",
    "pet_success": "キャラクターをなでました！",
        "spider_slow": "クモの巣で動きが遅くなった！",
        "spider_frozen": "クモの巣に捕まった！10秒間凍結！",
}

LANG_PACK["fr"] = {**LANG_PACK["en"],
    "title": "Choisissez une langue", "hero": "Héros (20 ans, courageux et calme)",
    "controls": "Commandes : A/D courir, Espace sauter, E entrer ou sortir de la mine",
    "controls_p1": "Joueur 1 : A / D — marcher, Espace — sauter",
    "controls_p2": "Joueur 2 : ← / → — marcher, ↑ — sauter", "network_host_address": "Adresse pour ton ami :",
    "flashlight_hint": "Dans la mine : 2 pour prendre la lampe, F pour l'allumer",
    "flashlight_on": "Lampe allumée", "flashlight_off": "Lampe éteinte", "no_flashlight": "Il te faut une lampe",
    "choose_flashlight": "Appuie sur 2 pour prendre la lampe", "hotbar_pickaxe": "PIOCHE",
    "hotbar_abyss": "ABÎME", "hotbar_flashlight": "LUMIÈRE", "hotbar_blocks": "BLOCS",
    "hotbar_empty": "VIDE", "hotbar_sword": "ÉPÉE", "hotbar_melon": "MELON",
    "need_sword": "Achète d'abord une épée dans la boutique", "boulder_stone": "Rocher brisé ! +15 pierres",
    "boulder_bonus": "Rocher brisé ! +15 pierres et {} × {}", "boulder_hp": "Résistance : {}",
    "hitboxes_on": "Boîtes de collision affichées (F3)", "hitboxes_off": "Boîtes de collision masquées (F3)",
    "saving": "Sauvegarde de la partie…", "player_hp": "Santé : {} sur 30",
    "flower_hit": "Pissenlit touché ! Santé restante : {}", "flower_hit_sword": "Coup d'épée ! Santé du pissenlit : {}",
    "flower_need_weapon": "Choisis la pioche (1) ou l'épée (3)",
    "flower_defeated": "Pissenlit vaincu ! 2 pierres magiques et 15 diamants obtenus",
    "flower_attacked": "Le pissenlit attaque !", "flower_knocked_out": "Le pissenlit t'a vaincu ! Retour à l'entrée de la mine.",
    "parrot_bite": "Le perroquet t'a mordu ! -29 santé", "parrot_knockout": "Le perroquet t'a assommé ! Retour à la surface.",
    "pet_success": "Tu as caressé le personnage !", "spider_slow": "La toile t'a ralenti !",
    "spider_frozen": "Pris dans la toile ! Gelé pendant 10 secondes !",
    "select_players": "Choisis le nombre de joueurs", "one_player_label": "1 JOUEUR", "two_player_label": "2 JOUEURS",
    "enter_mine": "E — entrer dans la mine", "leave_mine": "E — retourner à la surface",
    "ocean_hint": "E — partir vers l'océan / revenir au rivage", "entered_ocean": "Tu pars vers l'océan !",
    "returned_ocean": "Tu es revenu au rivage !", "balance": "Solde : {} Gromki 💰",
    "store_name": "Boutique de pioches", "inv_title": "🎒 INVENTAIRE :", "sell": "VENDRE", "sell_all": "TOUT",
    "eat": "MANGER", "grind": "MOUDRE", "craft_marmalade": "CRÉER",
    "need_sword_pig": "Prends l'épée pour chasser le cochon", "pig_hit": "Cochon touché ! Santé restante : {}",
    "critical_hit": "Coup critique ! -{} dégâts, santé restante : {}", "pvp_hit": "Tu as infligé {} dégâts à l'autre joueur !",
    "pvp_knockout": "Le joueur réapparaît avec toute sa santé !", "pig_killed": "Butin : porc cru et os !",
    "gathered_melon": "Pastèques récoltées : +{}", "gathered_raspberry": "Framboises récoltées : +{}",
    "made_gelatin": "2 os moulus en gélatine !", "made_marmalade": "Framboise et gélatine mélangées en bonbon !",
    "need_recipe_items": "Il faut des framboises et de la gélatine", "gather_hint": "E — ramasser",
    "pig_hint": "Clique sur le cochon avec l'épée", "ate_melon": "La pastèque rend {} PV et accélère pendant 5 secondes !",
    "ready": "Prêt pour l'aventure !", "mined": "Récupéré : {} ! ✔️", "deposit_mined": "+5 pierres, +10 XP{}",
    "deposit_hit": "Coup de pioche : -{} résistance ({} restante)", "entered_mine": "Tu es entré dans la mine !",
    "returned_surface": "Tu es revenu à la surface !", "close": "Fermer : Échap", "mods_loaded": "Minéraux ajoutés par les mods : {}",
    "abyss_secret": "Le trou noir a tout aspiré ! Pioche des abysses obtenue !", "empty": "Objet introuvable ! ❌",
    "sold": "Vendu pour {} Gromki ! 💰", "refresh": "La mine a été renouvelée !",
    "passive": "[Kyawthuite a généré +{} Gromki !]", "store_title": "🏪 BOUTIQUE DE PIOCHES :",
    "store_item_iron": "Pioche en fer", "store_item_gold": "Pioche en or (ressources ×3)",
    "store_item_sword": "Épée en bois", "store_item_stone_sword": "Épée en pierre", "store_item_iron_sword": "Épée en fer",
    "not_available": "Cet objet ne peut pas encore être acheté", "iron_pick_name": "Pioche en fer (ressources ×2)",
    "buy": "ACHETER ({} Gr.)", "store_item_owned": "Déjà acheté", "owned": "ACHETÉ ✔️", "no_money": "Pas assez de Gromki ! ❌"
}

LANG_PACK["sr"] = {**LANG_PACK["en"],
    "title": "Izaberite jezik", "hero": "Junak (20 godina, hrabar i miran)",
    "controls": "Kontrole: A/D trčanje, razmak skok, E ulaz/izlaz iz rudnika",
    "controls_p1": "Igrač 1: A / D — kretanje, razmak — skok",
    "controls_p2": "Igrač 2: ← / → — kretanje, ↑ — skok", "network_host_address": "Adresa za prijatelja:",
    "flashlight_hint": "U rudniku: pritisni 2 za lampu, zatim F za svetlo",
    "flashlight_on": "Lampa je uključena", "flashlight_off": "Lampa je isključena", "no_flashlight": "Prvo ti treba lampa",
    "choose_flashlight": "Pritisni 2 da uzmeš lampu", "hotbar_pickaxe": "PIK",
    "hotbar_abyss": "BEZDAN", "hotbar_flashlight": "SVETLO", "hotbar_blocks": "BLOKOVI",
    "hotbar_empty": "PRAZNO", "hotbar_sword": "MAČ", "hotbar_melon": "LUBENICA",
    "need_sword": "Prvo kupi mač u prodavnici", "boulder_stone": "Stena razbijena! +15 kamena",
    "boulder_bonus": "Stena razbijena! +15 kamena i {} × {}", "boulder_hp": "Izdržljivost: {}",
    "hitboxes_on": "Prikaz sudara uključen (F3)", "hitboxes_off": "Prikaz sudara isključen (F3)",
    "saving": "Čuvanje napretka…", "player_hp": "Zdravlje: {} od 30",
    "flower_hit": "Maslačak je pogođen! Preostalo zdravlje: {}", "flower_hit_sword": "Udarac mačem! Maslačku je ostalo: {}",
    "flower_need_weapon": "Izaberi pijuk (1) ili kupljeni mač (3)",
    "flower_defeated": "Maslačak je pobeđen! Dobio si 2 magična kamena i 15 dijamanata",
    "flower_attacked": "Maslačak napada!", "flower_knocked_out": "Maslačak te je pobedio! Vratio si se na ulaz u rudnik.",
    "parrot_bite": "Papagaj te je ugrizao! -29 zdravlja", "parrot_knockout": "Papagaj te je oborio! Vratio si se na površinu.",
    "pet_success": "Pomazio si lik!", "spider_slow": "Mreža te usporava!",
    "spider_frozen": "Uhvatio si se u mrežu! Zamrznut si 10 sekundi!",
    "select_players": "Izaberi broj igrača", "one_player_label": "1 IGRAČ", "two_player_label": "2 IGRAČA",
    "enter_mine": "E — uđi u rudnik", "leave_mine": "E — vrati se na površinu",
    "ocean_hint": "E — idi na okean / vrati se na obalu", "entered_ocean": "Zaplovio si ka okeanu!",
    "returned_ocean": "Vratio si se na obalu!", "balance": "Stanje: {} Gromki 💰",
    "store_name": "Prodavnica pijukâ", "inv_title": "🎒 INVENTAR:", "sell": "PRODAJ", "sell_all": "SVE",
    "eat": "JEDI", "grind": "SAMELJI", "craft_marmalade": "NAPRAVI",
    "need_sword_pig": "Uzmi mač da loviš svinju", "pig_hit": "Svinja je pogođena! Preostalo zdravlje: {}",
    "critical_hit": "Kritičan udarac! -{} štete, preostalo zdravlje: {}", "pvp_hit": "Udario si drugog igrača za {} štete!",
    "pvp_knockout": "Igrač se vratio sa punim zdravljem!", "pig_killed": "Ispalo je: sirova svinjetina i kosti!",
    "gathered_melon": "Sakupljene lubenice: +{}", "gathered_raspberry": "Sakupljene maline: +{}",
    "made_gelatin": "Samleo si 2 kosti u želatin!", "made_marmalade": "Pomešao si malinu i želatin u marmeladu!",
    "need_recipe_items": "Potrebni su malina i želatin", "gather_hint": "E — sakupi",
    "pig_hint": "Klikni na svinju dok držiš mač", "ate_melon": "Lubenica je vratila {} HP i ubrzala te na 5 sekundi!",
    "ready": "Spreman si za avanturu!", "mined": "Iskopano: {}! ✔️", "deposit_mined": "+5 kamena, +10 XP{}",
    "deposit_hit": "Udarac pijukom: -{} izdržljivosti (ostalo {})", "entered_mine": "Ušao si u rudnik!",
    "returned_surface": "Vratio si se na površinu!", "close": "Zatvori: Esc", "mods_loaded": "Minerali dodati modovima: {}",
    "abyss_secret": "Crna rupa je sve usisala! Dobio si pijuk bezdana!", "empty": "Nema tog predmeta! ❌",
    "sold": "Prodato za {} Gromkija! 💰", "refresh": "Rudnik je obnovljen!",
    "passive": "[Kyawthuite je doneo +{} Gromkija!]", "store_title": "🏪 PRODAVNICA PIJUKA:",
    "store_item_iron": "Gvozdeni pijuk", "store_item_gold": "Zlatni pijuk (resursi ×3)",
    "store_item_sword": "Drveni mač", "store_item_stone_sword": "Kameni mač", "store_item_iron_sword": "Gvozdeni mač",
    "not_available": "Ovaj predmet još ne može da se kupi", "iron_pick_name": "Gvozdeni pijuk (resursi ×2)",
    "buy": "KUPI ({} Gr.)", "store_item_owned": "Već kupljeno", "owned": "KUPLJENO ✔️", "no_money": "Nemaš dovoljno Gromkija! ❌"
}

NETWORK_TEXT = {
    "ru": ("Создать игру", "Подключиться", "Адрес сервера", "Введи адрес, ник и пароль. Новый ник зарегистрируется автоматически.",
           "Ждём второго игрока…", "Подключено!", "Не удалось подключиться", "Адрес в этой Wi‑Fi сети: {}",
           "Из другого дома нужны внешний IP и открытый на роутере порт {}.", "Связь потеряна. Нажми Esc.",
           "Запустить отдельный сервер", "Не закрывай окно сервера, пока друзья играют.",
           "Чтобы играть с этого компьютера, подключись к адресу {}.", "Никнейм", "Пароль",
           "VPN включён. Отключите VPN, чтобы играть по сети."),
    "en": ("Create game", "Join game", "Server address", "Enter an address, nickname and password. New nicknames register automatically.",
           "Waiting for another player…", "Connected!", "Could not connect", "Address on this Wi-Fi: {}",
           "From another home, use the host's public IP and open router port {}.", "Connection lost. Press Esc.",
           "Start a separate server", "Keep the server window open while friends play.",
           "To play on this computer, join this address: {}.", "Nickname", "Password",
           "VPN is on. Turn off the VPN to play online."),
    "es": ("Crear partida", "Unirse", "Dirección del servidor", "Escribe dirección, apodo y contraseña. El apodo nuevo se registra solo.",
           "Esperando a otro jugador…", "¡Conectado!", "No se pudo conectar", "Dirección de esta Wi-Fi: {}",
           "Desde otra casa, usa la IP pública del anfitrión y abre el puerto {} del router.", "Conexión perdida. Pulsa Esc.",
           "Iniciar servidor separado", "Deja abierta la ventana del servidor mientras juegan.",
           "Para jugar en este equipo, conéctate a esta dirección: {}.", "Apodo", "Contraseña",
           "La VPN está activada. Desactívala para jugar en línea."),
    "zh": ("创建游戏", "加入游戏", "服务器地址", "输入地址、昵称和密码。新昵称会自动注册。",
           "正在等待另一位玩家…", "已连接！", "连接失败", "当前 Wi-Fi 地址：{}",
           "从别处连接需要主机的公网 IP，并在路由器打开端口 {}。", "连接断开。按 Esc。",
           "启动独立服务器", "朋友游戏时请保持服务器窗口打开。",
           "要在这台电脑上玩，请连接到地址：{}。", "昵称", "密码",
           "VPN 已开启。请关闭 VPN 后再进行联机。"),
    "ja": ("ゲームを作る", "参加する", "サーバーアドレス", "アドレス、ニックネーム、パスワードを入力。新しい名前は自動登録されます。",
           "もう一人のプレイヤーを待っています…", "接続しました！", "接続できませんでした", "このWi-Fiのアドレス：{}",
           "別の家からはホストのグローバルIPと、ルーターのポート{}開放が必要です。", "切断しました。Escを押してください。",
           "専用サーバーを起動", "友達が遊んでいる間はサーバーのウィンドウを閉じないでください。",
           "このパソコンで遊ぶには、アドレス{}に接続してください。", "ニックネーム", "パスワード",
           "VPNが有効です。オンラインで遊ぶにはVPNをオフにしてください。"),
    "fr": ("Créer une partie", "Rejoindre", "Adresse du serveur", "Entre l'adresse, le pseudo et le mot de passe. Les nouveaux pseudos sont enregistrés automatiquement.",
           "En attente d'un autre joueur…", "Connecté !", "Connexion impossible", "Adresse sur ce Wi-Fi : {}",
           "Depuis une autre maison, utilise l'IP publique de l'hôte et ouvre le port {} du routeur.", "Connexion perdue. Appuie sur Échap.",
           "Lancer un serveur dédié", "Laisse la fenêtre du serveur ouverte pendant la partie.",
           "Pour jouer sur cet ordinateur, connecte-toi à cette adresse : {}.", "Pseudo", "Mot de passe",
           "Le VPN est activé. Désactive-le pour jouer en ligne."),
    "sr": ("Napravi igru", "Pridruži se", "Adresa servera", "Unesi adresu, nadimak i lozinku. Novi nadimci se automatski registruju.",
           "Čeka se drugi igrač…", "Povezano!", "Povezivanje nije uspelo", "Adresa na ovom Wi-Fi-ju: {}",
           "Iz druge kuće koristi javnu IP adresu domaćina i otvori port {} na ruteru.", "Veza je prekinuta. Pritisni Esc.",
           "Pokreni poseban server", "Ostavi prozor servera otvoren dok se igra.",
           "Za igru na ovom računaru poveži se na adresu: {}.", "Nadimak", "Lozinka",
           "VPN je uključen. Isključi VPN da bi igrao preko mreže."),
}

RESOURCE_NAMES = {
    "ru": {
        "kyawthuite": "Кьявтуит", "amethyst_with_rutile_quartz": "Рутиловый аметист",
        "green_jade": "Нефрит", "moon_stone": "Лунный камень", "pink_quartz": "Розовый кварц",
        "quartz": "Хрусталь", "emerald": "Изумруд", "diamond": "Алмаз", "ruby": "Рубин",
        "garnet": "Гранат",
        "sapphire": "Сапфир", "aquamarine": "Аквамарин", "amethyst": "Аметист",
        "magic_stone": "Магический камень", "magic_gold": "Магическое золото",
        "lapis": "Лазурит", "ore_iron": "Железная руда", "classic_stone": "Камень",
        "stone_block": "Каменный блок",
        "melon": "Арбуз", "citrine": "Цитрин", "raw_pork": "Сырая свинина",
        "bone": "Кости", "gelatin": "Желатин",
        "raspberry": "Малина", "marmalade": "Мармелад", "shark_tooth": "Зуб акулы", "fish": "Рыба"
    },
    "en": {
        "kyawthuite": "Kyawthuite", "amethyst_with_rutile_quartz": "Rutile amethyst",
        "green_jade": "Green jade", "moon_stone": "Moon stone", "pink_quartz": "Pink quartz",
        "quartz": "Quartz", "emerald": "Emerald", "diamond": "Diamond", "ruby": "Ruby",
        "garnet": "Garnet",
        "sapphire": "Sapphire", "aquamarine": "Aquamarine", "amethyst": "Amethyst",
        "magic_stone": "Magic stone", "magic_gold": "Magic gold", "lapis": "Lapis",
        "ore_iron": "Iron ore", "classic_stone": "Stone", "melon": "Watermelon",
        "stone_block": "Stone block",
        "citrine": "Citrine", "raw_pork": "Raw pork", "bone": "Bones",
        "gelatin": "Gelatin",
        "raspberry": "Raspberry", "marmalade": "Marmalade", "shark_tooth": "Shark tooth", "fish": "Fish"
    },
    "es": {
        "kyawthuite": "Kyawthuite", "amethyst_with_rutile_quartz": "Amatista con cuarzo rutilado",
        "green_jade": "Jade verde", "moon_stone": "Piedra lunar", "pink_quartz": "Cuarzo rosa",
        "quartz": "Cuarzo", "emerald": "Esmeralda", "diamond": "Diamante", "ruby": "Rubí",
        "garnet": "Granate",
        "sapphire": "Zafiro", "aquamarine": "Aguamarina", "amethyst": "Amatista",
        "magic_stone": "Piedra mágica", "magic_gold": "Oro mágico", "lapis": "Lapislázuli",
        "ore_iron": "Mineral de hierro", "classic_stone": "Piedra", "melon": "Melón",
        "stone_block": "Bloque de piedra",
        "citrine": "Citrino", "raw_pork": "Cerdo crudo", "bone": "Huesos",
        "gelatin": "Gelatina", "raspberry": "Frambuesa", "marmalade": "Gominola", "shark_tooth": "Diente de tiburón", "fish": "Pez"
    },
    "zh": {
        "kyawthuite": "锆石", "amethyst_with_rutile_quartz": "金红石紫水晶", "green_jade": "绿玉",
        "moon_stone": "月长石", "pink_quartz": "粉水晶", "quartz": "水晶", "emerald": "绿宝石",
        "diamond": "钻石", "ruby": "红宝石", "garnet": "石榴石", "sapphire": "蓝宝石", "aquamarine": "海蓝宝石",
        "amethyst": "紫水晶", "magic_stone": "魔法石", "magic_gold": "魔法金",
        "lapis": "青金石", "ore_iron": "铁矿石", "classic_stone": "石头", "stone_block": "石块", "melon": "西瓜",
        "citrine": "黄水晶", "raw_pork": "生猪肉", "bone": "骨头", "gelatin": "明胶",
        "raspberry": "树莓", "marmalade": "软糖", "shark_tooth": "鲨鱼牙齿", "fish": "鱼"
    },
    "ja": {
        "kyawthuite": "キョーソ石", "amethyst_with_rutile_quartz": "ルチル入りアメジスト",
        "green_jade": "翡翠", "moon_stone": "ムーンストーン", "pink_quartz": "ローズクォーツ",
        "quartz": "水晶", "emerald": "エメラルド", "diamond": "ダイヤモンド", "ruby": "ルビー",
        "garnet": "ガーネット",
        "sapphire": "サファイア", "aquamarine": "アクアマリン", "amethyst": "アメジスト",
        "magic_stone": "魔法の石", "magic_gold": "魔法の金", "lapis": "ラピスラズリ",
        "ore_iron": "鉄鉱石", "classic_stone": "石", "stone_block": "石ブロック", "melon": "スイカ", "citrine": "シトリン",
        "raw_pork": "生の豚肉", "bone": "骨", "gelatin": "ゼラチン",
        "raspberry": "ラズベリー", "marmalade": "グミ", "shark_tooth": "サメの歯", "fish": "魚"
    },
    "fr": {
        "kyawthuite": "Kyawthuite", "amethyst_with_rutile_quartz": "Améthyste à quartz rutile",
        "green_jade": "Jade vert", "moon_stone": "Pierre de lune", "pink_quartz": "Quartz rose",
        "quartz": "Cristal", "emerald": "Émeraude", "diamond": "Diamant", "ruby": "Rubis", "garnet": "Grenat",
        "sapphire": "Saphir", "aquamarine": "Aigue-marine", "amethyst": "Améthyste", "magic_stone": "Pierre magique",
        "magic_gold": "Or magique", "lapis": "Lapis-lazuli", "ore_iron": "Minerai de fer", "classic_stone": "Pierre",
        "stone_block": "Bloc de pierre", "melon": "Pastèque", "citrine": "Citrine", "raw_pork": "Porc cru",
        "bone": "Os", "gelatin": "Gélatine", "raspberry": "Framboise", "marmalade": "Pâte de fruits",
        "shark_tooth": "Dent de requin", "fish": "Poisson"
    },
    "sr": {
        "kyawthuite": "Kjautuit", "amethyst_with_rutile_quartz": "Ametist sa rutilom",
        "green_jade": "Zeleni žad", "moon_stone": "Mesečev kamen", "pink_quartz": "Roze kvarc",
        "quartz": "Kristal", "emerald": "Smaragd", "diamond": "Dijamant", "ruby": "Rubin", "garnet": "Granat",
        "sapphire": "Safir", "aquamarine": "Akvamarin", "amethyst": "Ametist", "magic_stone": "Magični kamen",
        "magic_gold": "Magično zlato", "lapis": "Lapis lazuli", "ore_iron": "Gvozdena ruda", "classic_stone": "Kamen",
        "stone_block": "Kameni blok", "melon": "Lubenica", "citrine": "Citrin", "raw_pork": "Sirova svinjetina",
        "bone": "Kosti", "gelatin": "Želatin", "raspberry": "Malina", "marmalade": "Marmelada",
        "shark_tooth": "Zub ajkule", "fish": "Riba"
    }
}

for mod_item in MOD_ITEMS:
    for language in LANG_PACK:
        translated_name = mod_item["name"].get(language) or mod_item["name"].get("en") or mod_item["id"]
        RESOURCE_NAMES[language][mod_item["id"]] = translated_name

INVENTORY_LABELS = {
    "ru": {**RESOURCE_NAMES["ru"], "amethyst_with_rutile_quartz": "Рутил. аметист",
           "magic_stone": "Маг. камень", "magic_gold": "Маг. золото", "ore_iron": "Жел. руда",
           "raw_pork": "Сырая свинина", "bone": "Кости", "gelatin": "Желатин",
           "raspberry": "Малина", "marmalade": "Мармелад"},
    "en": {**RESOURCE_NAMES["en"], "amethyst_with_rutile_quartz": "Rutile amethyst",
           "magic_stone": "Magic stone", "magic_gold": "Magic gold", "ore_iron": "Iron ore",
           "raw_pork": "Raw pork", "bone": "Bones", "gelatin": "Gelatin",
           "raspberry": "Raspberry", "marmalade": "Marmalade"},
    "es": {**RESOURCE_NAMES["es"], "amethyst_with_rutile_quartz": "Amatista con cuarzo rutilado"},
    "zh": {**RESOURCE_NAMES["zh"], "amethyst_with_rutile_quartz": "金红石紫水晶"},
    "ja": {**RESOURCE_NAMES["ja"], "amethyst_with_rutile_quartz": "ルチル入りアメジスト"},
    "fr": {**RESOURCE_NAMES["fr"], "amethyst_with_rutile_quartz": "Améthyste à rutile"},
    "sr": {**RESOURCE_NAMES["sr"], "amethyst_with_rutile_quartz": "Ametist sa rutilom"}
}

LANGUAGE_TEXTURES = {"ru": "flag_ru", "en": "flag_en", "es": "flag_es", "zh": "flag_zh", "ja": "flag_ja",
                     "fr": "flag_fr", "sr": "flag_sr"}
language_button_width = u(160)
language_button_gap = u(12)
language_buttons_width = language_button_width * len(LANGUAGE_TEXTURES) + language_button_gap * (len(LANGUAGE_TEXTURES) - 1)
language_buttons_left = (WIDTH - language_buttons_width) // 2
LANGUAGE_BUTTON_RECTS = {
    code: pygame.Rect(language_buttons_left + index * (language_button_width + language_button_gap),
                      u(300), language_button_width, u(100))
    for index, code in enumerate(LANGUAGE_TEXTURES)
}
one_player_button_rect = pygame.Rect(WIDTH // 2 - u(260), u(240), u(180), u(165))
two_player_button_rect = pygame.Rect(WIDTH // 2 + u(80), u(240), u(180), u(165))
world_name_input_rect = pygame.Rect(WIDTH // 2 - u(330), u(220), u(470), u(48))
world_create_button_rect = pygame.Rect(WIDTH // 2 + u(155), u(220), u(175), u(48))
settings_menu_button_rect = pygame.Rect(WIDTH // 2 - u(150), u(565), u(300), u(48))
settings_fullscreen_rect = pygame.Rect(WIDTH // 2 - u(220), u(250), u(440), u(64))
settings_volume_track_rect = pygame.Rect(WIDTH // 2 - u(190), u(380), u(380), u(22))
settings_volume_down_rect = pygame.Rect(WIDTH // 2 - u(245), u(365), u(42), u(52))
settings_volume_up_rect = pygame.Rect(WIDTH // 2 + u(203), u(365), u(42), u(52))
settings_back_rect = pygame.Rect(WIDTH // 2 - u(150), u(510), u(300), u(52))
network_host_button_rect = pygame.Rect(WIDTH // 2 - u(260), u(235), u(230), u(64))
network_join_button_rect = pygame.Rect(WIDTH // 2 + u(30), u(235), u(230), u(64))
network_address_rect = pygame.Rect(WIDTH // 2 - u(260), u(322), u(550), u(50))
network_username_rect = pygame.Rect(WIDTH // 2 - u(260), u(388), u(550), u(50))
network_password_rect = pygame.Rect(WIDTH // 2 - u(260), u(454), u(550), u(50))
network_dedicated_button_rect = pygame.Rect(WIDTH // 2 - u(260), u(548), u(550), u(58))
exit_button_rect = pygame.Rect(WIDTH - u(60), HEIGHT - u(58), u(48), u(48))
helper_button_rect = pygame.Rect(WIDTH - u(260), u(70), u(240), u(56))
selected_store_item = "iron"
STORE_PRICES = {"iron": 50000, "gold": 150000, "sword": 25000,
                "stone_sword": 60000, "iron_sword": 120000}

prices = {
    "kyawthuite": 50000, "amethyst_with_rutile_quartz": 12000, "green_jade": 9000,
    "moon_stone": 8000, "pink_quartz": 7000, "quartz": 6000,
    "emerald": 5000, "diamond": 4000, "ruby": 3000, "garnet": 2500, "sapphire": 2000,
    "aquamarine": 1500, "amethyst": 1000, "magic_stone": 700, "magic_gold": 600, "lapis": 500, 
    "ore_iron": 300, "classic_stone": 10, "stone_block": 15, "melon": 50, "citrine": 1200,
    "raw_pork": 20, "bone": 8, "gelatin": 25, "raspberry": 15, "marmalade": 60,
    "shark_tooth": 500, "fish": 90
}
for mod_item in MOD_ITEMS:
    prices[mod_item["id"]] = mod_item["price"]

NON_ORE_ITEMS = {"melon", "raw_pork", "bone", "gelatin", "raspberry", "marmalade",
                 "shark_tooth", "fish", "stone_block"}
NON_ORE_ITEMS.update(MOD_FOOD_ITEMS)


def mine_depth_tier(world_x):
    """Считает уровень глубины по расстоянию от входа в бесконечной шахте."""
    return max(0, world_x // WIDTH)


SURFACE_INVENTORY_ITEMS = {"melon", "raw_pork", "bone", "gelatin", "raspberry", "marmalade"}
SURFACE_INVENTORY_ITEMS.update(MOD_FOOD_ITEMS)
OCEAN_INVENTORY_ITEMS = {"fish", "shark_tooth"}


def mining_depth_for_item(item):
    if item == "classic_stone":
        return 0
    if item in MOD_MIN_DEPTHS:
        return MOD_MIN_DEPTHS[item]
    return max(0, math.ceil(math.sqrt(max(0, (prices.get(item, 200) - 200) / 120))))


def filtered_inventory_items():
    items = list(inventory.items())
    if inventory_category == "surface":
        return [(item, amount) for item, amount in items if item in SURFACE_INVENTORY_ITEMS]
    if inventory_category == "ocean":
        return [(item, amount) for item, amount in items if item in OCEAN_INVENTORY_ITEMS]
    if inventory_category == "mine":
        mine_items = [(item, amount) for item, amount in items
                      if item not in SURFACE_INVENTORY_ITEMS and item not in OCEAN_INVENTORY_ITEMS]
        return sorted(mine_items, key=lambda entry: (mining_depth_for_item(entry[0]), entry[0]))
    return items


def get_inventory_category_rects():
    panel_x = WIDTH - u(500)
    tab_width, gap = u(118), u(3)
    return [pygame.Rect(panel_x + u(5) + index * (tab_width + gap), u(66), tab_width, u(34))
            for index in range(4)]


def choose_ore_for_depth(world_x):
    """Глубже открываются более дорогие руды, а частота смещается к ценным."""
    depth = mine_depth_tier(world_x)
    price_limit = 200 + depth * depth * 120
    mineral_names = [name for name in prices if name not in NON_ORE_ITEMS and name != "classic_stone"
                     and MOD_MIN_DEPTHS.get(name, 0) <= depth]
    if not mineral_names:
        mineral_names = [name for name in prices if name not in NON_ORE_ITEMS and name != "classic_stone"]
    available_ores = [name for name in mineral_names if prices[name] <= price_limit]
    if not available_ores:
        available_ores = [min(mineral_names, key=prices.get)]
    best_price = max(prices[name] for name in available_ores)
    weights = [(0.5 + 3 * prices[name] / best_price) * MOD_DROP_WEIGHTS.get(name, 1)
               for name in available_ores]
    return random.choices(available_ores, weights=weights, k=1)[0]

# Системные переменные
player_x, player_y = u(300), u(510)
player2_x, player2_y = u(390), u(510)
player_speed = u(6)
player_is_jumping = False
player2_is_jumping = False
jump_velocity = u(16)
gravity = SCALE
y_velocity = 0
player2_y_velocity = 0
floor_y = u(510)
mine_entrance_rect = pygame.Rect(
    u(10), floor_y + u(90) - textures["entrance_mine"].get_height(),
    textures["entrance_mine"].get_width(), textures["entrance_mine"].get_height()
)
OCEAN_ACCESS_X = WIDTH + u(220)
ocean_access_rect = pygame.Rect(
    OCEAN_ACCESS_X - textures["ocean_access"].get_width() // 2,
    floor_y + u(90) - textures["ocean_access"].get_height(),
    textures["ocean_access"].get_width(), textures["ocean_access"].get_height()
)
gromki = 0
inventory = {
    "kyawthuite": 0, "amethyst_with_rutile_quartz": 0, "green_jade": 0,
    "moon_stone": 0, "pink_quartz": 0, "quartz": 0,
    "emerald": 0, "diamond": 0, "ruby": 0, "sapphire": 0,
    "aquamarine": 0, "amethyst": 0, "magic_stone": 0, "magic_gold": 0, "lapis": 0, 
    "ore_iron": 0, "classic_stone": 0, "stone_block": 0, "melon": 0, "citrine": 0, "garnet": 0,
    "raw_pork": 0, "bone": 0, "gelatin": 0, "raspberry": 0, "marmalade": 0,
    "shark_tooth": 0, "fish": 0
}
for mod_item in MOD_ITEMS:
    inventory[mod_item["id"]] = 0
has_iron_pickaxe = False
has_gold_pickaxe = False
has_abyss_pickaxe = False
has_wood_sword = False
has_stone_sword = False
has_iron_sword = False


def owns_sword():
    return has_wood_sword or has_stone_sword or has_iron_sword


def best_sword_texture():
    return "iron_sword" if has_iron_sword else "stone_sword" if has_stone_sword else "wood_sword"


def store_item_owned(item):
    return {"iron": has_iron_pickaxe, "gold": has_gold_pickaxe, "sword": has_wood_sword,
            "stone_sword": has_stone_sword, "iron_sword": has_iron_sword}[item]


def buy_store_item(item):
    global gromki, has_iron_pickaxe, has_gold_pickaxe, has_wood_sword, has_stone_sword, has_iron_sword
    if store_item_owned(item) or gromki < STORE_PRICES[item]:
        return False
    gromki -= STORE_PRICES[item]
    if item == "iron": has_iron_pickaxe = True
    elif item == "gold": has_gold_pickaxe = True
    elif item == "sword": has_wood_sword = True
    elif item == "stone_sword": has_stone_sword = True
    else: has_iron_sword = True
    return True
player_count = 1
current_zone = "surface"
current_world_id = ""
current_world_name = ""
current_world_seed = 91373
world_name_input = ""
world_notice = ""
world_scroll_offset = 0
world_row_buttons = []
inventory_open = False
inventory_scroll_row = 0
inventory_category = "mine"
current_graphics_store_open = False
abyss_black_hole = None
anim_counter = 0
player2_anim_counter = 0
current_jerry_sprite = "jerry_idle"
player2_jerry_sprite = "jerry_idle"
player_facing_right = True
player2_facing_right = True
player_names = ["Игрок 1", "Игрок 2"]
mining_animation_started = [0.0, 0.0]
sword_attack_ready_at = [0.0, 0.0]
pending_sword_attacks = []
last_income_time = time.time()
melon_speed_until = 0
lang = "ru"
last_action_text = ""
helper_open = False
helper_question = ""
helper_answer = "Привет! Я помощник по игре. Напиши вопрос и нажми Enter."
helper_last_intent = ""
fishing_state = "idle"
fishing_bite_at = 0.0
fishing_cast_x = 0
player_health = [MAX_PLAYER_HEALTH, MAX_PLAYER_HEALTH]
mine_experience = 0  # Очки опыта пока скрыты и сохраняются между запусками.
player_damage_cooldown = [0.0, 0.0]
pvp_attack_ready_at = [0.0, 0.0]
dandelions = []
next_dandelion_spawn_time = time.time() + 60
spiders = []
web_projectiles = []
player_slowed_until = [0.0, 0.0]
player_frozen_until = [0.0, 0.0]
next_spider_spawn_time = time.time() + random.uniform(12, 20)
pet_effects = []
camera_x = 0
surface_chunks = {}
surface_camera_y = 0
world_blocks = []

save_root = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "StickmanInMine")
server_world_id = os.environ.get("STIKMAN_WORLD_ID", "")
if server_world_id:
    save_path = os.path.join(save_root, f"savegame_{server_world_id}.json")
    server_world_path = os.path.join(save_root, f"server_world_{server_world_id}.json")
else:
    save_path = os.path.join(save_root, "savegame.json")
    server_world_path = os.path.join(save_root, "server_world.json")
legacy_save_path = save_path
server_accounts_path = os.path.join(save_root, "server_accounts.json")
server_accounts_lock = threading.Lock()
saved_session = None
logged_network_slots = set()


def _append_log_file(file_name, contents):
    """Записывает файлы журнала рядом с игрой, а при запрете записи — в сохранения."""
    for base_directory in (APP_DIR, save_root):
        directory = os.path.join(base_directory, "logs")
        try:
            os.makedirs(directory, exist_ok=True)
            full_path = os.path.join(directory, file_name)
            with open(full_path, "a", encoding="utf-8") as log_file:
                log_file.write(contents)
            return full_path
        except OSError:
            continue
    return None


def log_system_event(event_name, details=""):
    """Записывает только работу игры и соединения; не записывает действия игрока."""
    log_path = os.path.join(LOG_DIR, "game.log")
    try:
        if os.path.isfile(log_path) and os.path.getsize(log_path) > 2_000_000:
            os.replace(log_path, log_path + ".1")
    except OSError:
        pass
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S %z")
    line = f"[{timestamp}] {event_name}"
    if details:
        line += f": {str(details).replace(chr(10), ' ').replace(chr(13), ' ')}"
    return _append_log_file("game.log", line + "\n")


def log_crash(error_report):
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    crash_path = _append_log_file(f"crash-{timestamp}.log", error_report.rstrip() + "\n")
    log_system_event("CRASH", f"Неожиданная ошибка; подробности в {os.path.basename(crash_path) if crash_path else 'crash log unavailable'}")
    return crash_path


def load_progress():
    """Восстанавливает кошелёк, инвентарь и купленные вещи с прошлого раза."""
    global gromki, has_iron_pickaxe, has_gold_pickaxe, has_abyss_pickaxe, has_wood_sword, has_stone_sword, has_iron_sword, lang, player_health, mine_experience
    global current_zone, player_x, player2_x, saved_session
    global world_blocks
    try:
        with open(save_path, "r", encoding="utf-8") as save_file:
            data = json.load(save_file)
        gromki = max(0, int(data.get("gromki", 0)))
        mine_experience = max(0, int(data.get("mine_experience", 0)))
        saved_inventory = data.get("inventory", {})
        if isinstance(saved_inventory, dict):
            for item in inventory:
                inventory[item] = max(0, int(saved_inventory.get(item, 0)))
        saved_blocks = data.get("world_blocks", [])
        if isinstance(saved_blocks, list):
            loaded_blocks = []
            for block in saved_blocks[:20000]:
                if not isinstance(block, dict) or block.get("type", "stone") != "stone":
                    continue
                try:
                    block_x, block_y = int(block["x"]), int(block["y"])
                    old_size = max(1, int(block.get("size", u(32))))
                    if old_size != BLOCK_SIZE:
                        old_ground_top = surface_ground_y() - old_size
                        row = max(0, round((old_ground_top - block_y) / old_size))
                        column = math.floor(block_x / old_size)
                        block_x = column * BLOCK_SIZE
                        block_y = surface_ground_y() - BLOCK_SIZE - row * BLOCK_SIZE
                    loaded_blocks.append({"x": block_x, "y": block_y, "type": "stone"})
                except (KeyError, TypeError, ValueError):
                    continue
            world_blocks = loaded_blocks
        has_iron_pickaxe = bool(data.get("has_iron_pickaxe", False))
        has_gold_pickaxe = bool(data.get("has_gold_pickaxe", False))
        has_abyss_pickaxe = bool(data.get("has_abyss_pickaxe", False))
        has_wood_sword = bool(data.get("has_wood_sword", False))
        has_stone_sword = bool(data.get("has_stone_sword", False))
        has_iron_sword = bool(data.get("has_iron_sword", False))
        saved_health = data.get("player_health", player_health)
        if isinstance(saved_health, list):
            for index in range(min(2, len(saved_health))):
                player_health[index] = max(1, min(MAX_PLAYER_HEALTH, int(saved_health[index])))
        if data.get("lang") in LANG_PACK:
            lang = data["lang"]
        if data.get("zone") in ("surface", "mine", "ocean"):
            current_zone = data["zone"]
            player_x = max(0, int(data.get("player_x", player_x)))
            player2_x = max(0, int(data.get("player2_x", player_x + u(100))))
            saved_session = {"zone": current_zone, "player_x": player_x, "player2_x": player2_x}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass


def save_progress():
    """Надёжно сохраняет добычу и покупки в папке пользователя Windows."""
    global saved_session
    if netplay.role == "client":
        return True
    data = {
        "gromki": gromki,
        "inventory": inventory,
        "has_iron_pickaxe": has_iron_pickaxe,
        "has_gold_pickaxe": has_gold_pickaxe,
        "has_abyss_pickaxe": has_abyss_pickaxe,
        "has_wood_sword": has_wood_sword,
        "has_stone_sword": has_stone_sword,
        "has_iron_sword": has_iron_sword,
        "player_health": player_health,
        "mine_experience": mine_experience,
        "lang": lang,
        "zone": current_zone,
        "player_x": player_x,
        "player2_x": player2_x,
        "world_blocks": [{**block, "size": BLOCK_SIZE} for block in world_blocks],
    }
    try:
        os.makedirs(save_root, exist_ok=True)
        temporary_path = save_path + ".tmp"
        with open(temporary_path, "w", encoding="utf-8") as save_file:
            json.dump(data, save_file, ensure_ascii=False)
        os.replace(temporary_path, save_path)
        saved_session = {"zone": current_zone, "player_x": player_x, "player2_x": player2_x}
        return True
    except OSError as error:
        log_system_event("SAVE ERROR", str(error))
        return False


def ensure_worlds_directory():
    """Создаёт папку миров и копирует старое сохранение в отдельный мир, не удаляя его."""
    os.makedirs(WORLDS_DIR, exist_ok=True)
    known_worlds = [name for name in os.listdir(WORLDS_DIR)
                    if os.path.isdir(os.path.join(WORLDS_DIR, name))]
    if not known_worlds and os.path.isfile(legacy_save_path):
        legacy_id = "world_legacy"
        legacy_folder = os.path.join(WORLDS_DIR, legacy_id)
        os.makedirs(legacy_folder, exist_ok=True)
        with open(os.path.join(legacy_folder, "world.json"), "w", encoding="utf-8") as info:
            json.dump({"id": legacy_id, "name": "Старый мир", "seed": 91373}, info, ensure_ascii=False)
        shutil.copyfile(legacy_save_path, os.path.join(legacy_folder, "savegame.json"))


def list_available_worlds():
    ensure_worlds_directory()
    result = []
    for world_id in os.listdir(WORLDS_DIR):
        if not re.fullmatch(r"world_(?:legacy|[0-9a-f]{12})", world_id):
            continue
        metadata_path = os.path.join(WORLDS_DIR, world_id, "world.json")
        try:
            with open(metadata_path, "r", encoding="utf-8") as info:
                metadata = json.load(info)
            if not isinstance(metadata, dict):
                continue
            name = str(metadata.get("name", "Мир"))[:32]
            seed = max(0, int(metadata.get("seed", 91373)))
            result.append({"id": world_id, "name": name, "seed": seed})
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    return sorted(result, key=lambda world: world["name"].casefold())


def create_world(name):
    name = " ".join(str(name).split())[:32]
    if not name:
        return None
    world_id = "world_" + secrets.token_hex(6)
    world_folder = os.path.join(WORLDS_DIR, world_id)
    try:
        os.makedirs(world_folder, exist_ok=False)
        with open(os.path.join(world_folder, "world.json"), "w", encoding="utf-8") as info:
            json.dump({"id": world_id, "name": name, "seed": secrets.randbelow(2_000_000_000)},
                      info, ensure_ascii=False, indent=2)
        return world_id
    except OSError:
        return None


def reset_world_progress():
    """Начинает чистое сохранение и очищает временных существ старого мира."""
    global gromki, has_iron_pickaxe, has_gold_pickaxe, has_abyss_pickaxe
    global has_wood_sword, has_stone_sword, has_iron_sword, player_health, mine_experience
    global current_zone, player_x, player2_x, player_y, player2_y, player_is_jumping, player2_is_jumping
    global y_velocity, player2_y_velocity, saved_session, next_ore_chunk_x, last_mine_refresh_time
    global collapse_stage, collapse_boulders, collapse_small_stones, dandelions, spiders, web_projectiles
    global fishing_state, flashlight_on, last_action_text
    global world_blocks, surface_camera_y
    gromki = 0
    for item in inventory:
        inventory[item] = 0
    has_iron_pickaxe = has_gold_pickaxe = has_abyss_pickaxe = False
    has_wood_sword = has_stone_sword = has_iron_sword = False
    player_health = [MAX_PLAYER_HEALTH, MAX_PLAYER_HEALTH]
    mine_experience = 0
    current_zone = "surface"
    player_x, player2_x = u(300), u(390)
    player_y = player2_y = floor_y
    player_is_jumping = player2_is_jumping = False
    y_velocity = player2_y_velocity = 0
    saved_session = None
    flashlight_on = False
    fishing_state = "idle"
    last_action_text = ""
    surface_chunks.clear()
    world_blocks.clear()
    surface_camera_y = 0
    random.seed(current_world_seed)
    mineral_deposits.clear()
    generate_ore_chunk(0)
    next_ore_chunk_x = WIDTH
    last_mine_refresh_time = time.time()
    dandelions.clear()
    spiders.clear()
    web_projectiles.clear()
    collapse_stage = "waiting"
    collapse_boulders.clear()
    collapse_small_stones.clear()


def open_world(world_id):
    global current_world_id, current_world_name, current_world_seed, save_path
    if not re.fullmatch(r"world_(?:legacy|[0-9a-f]{12})", str(world_id)):
        return False
    world_folder = os.path.abspath(os.path.join(WORLDS_DIR, world_id))
    if os.path.commonpath((os.path.abspath(WORLDS_DIR), world_folder)) != os.path.abspath(WORLDS_DIR):
        return False
    try:
        with open(os.path.join(world_folder, "world.json"), "r", encoding="utf-8") as info:
            metadata = json.load(info)
        current_world_id = world_id
        current_world_name = str(metadata.get("name", "Мир"))[:32]
        current_world_seed = max(0, int(metadata.get("seed", 91373)))
        save_path = os.path.join(world_folder, "savegame.json")
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return False
    reset_world_progress()
    load_progress()
    return True


def configure_world_start():
    global current_zone, player_x, player2_x, player_y, player2_y
    global player_is_jumping, player2_is_jumping, y_velocity, player2_y_velocity
    global last_mine_refresh_time, next_ore_chunk_x
    if saved_session:
        current_zone = saved_session["zone"]
        player_x = saved_session["player_x"]
        player2_x = saved_session["player2_x"]
        if current_zone == "mine":
            next_ore_chunk_x = ((max(player_x, player2_x) // WIDTH) + 1) * WIDTH
            refresh_mine_ores(max(0, min(player_x, player2_x) - WIDTH // 2))
            last_mine_refresh_time = time.time()
    else:
        current_zone = "surface"
        player_x, player2_x = u(300), u(390)
    player_y = player2_y = floor_y
    player_is_jumping = player2_is_jumping = False
    y_velocity = player2_y_velocity = 0


def maybe_activate_abyss_secret():
    """Обменивает полный инвентарь на кирку бездны один раз за сохранение."""
    global has_abyss_pickaxe, abyss_black_hole, last_action_text
    if has_abyss_pickaxe or abyss_black_hole is not None or not inventory:
        return
    if not all(amount >= 999 for amount in inventory.values()):
        return
    for item in inventory:
        inventory[item] = 0
    has_abyss_pickaxe = True
    direction = 1 if player_facing_right else -1
    abyss_black_hole = {
        "x": max(u(45), player_x + direction * u(135)),
        "y": player_y - u(55),
        "started_at": time.time(),
        "duration": 3.0
    }
    last_action_text = LANG_PACK[lang]["abyss_secret"]
    save_progress()


def draw_abyss_black_hole():
    if abyss_black_hole is None:
        return
    elapsed = time.time() - abyss_black_hole["started_at"]
    center = (round(abyss_black_hole["x"] - camera_x), round(abyss_black_hole["y"]))
    pulse = round(u(7) * (0.5 + 0.5 * math.sin(elapsed * 9)))
    radius = u(32) + pulse
    outer = pygame.Rect(center[0] - radius, center[1] - radius, radius * 2, radius * 2)
    pygame.draw.ellipse(screen, (58, 22, 115), outer.inflate(u(14), u(14)), max(1, u(4)))
    pygame.draw.ellipse(screen, (110, 50, 215), outer.inflate(u(6), u(6)), max(1, u(4)))
    pygame.draw.ellipse(screen, (5, 3, 12), outer)
    pygame.draw.ellipse(screen, (27, 8, 50), outer.inflate(-u(12), -u(12)))
    for index in range(3):
        angle = elapsed * (2.8 + index * 0.7) + index * 2.1
        orbit = radius + u(10 + index * 4)
        point = (center[0] + round(math.cos(angle) * orbit),
                 center[1] + round(math.sin(angle) * orbit * 0.55))
        color = ((65, 225, 255), (191, 73, 255), (255, 205, 70))[index]
        pygame.draw.circle(screen, color, point, max(2, u(4 - index // 2)))


def show_saving_screen():
    screen.fill((24, 27, 31))
    message = font_menu.render(LANG_PACK[lang]["saving"], True, (255, 220, 80))
    screen.blit(message, (WIDTH // 2 - message.get_width() // 2,
                          HEIGHT // 2 - message.get_height() // 2))
    present_frame()
    pygame.time.wait(900)


load_progress()
set_language_fonts(lang)

# Новая система добычи: шахта зарастает крупными месторождениями.
mineral_deposits = []
DEPOSIT_WIDTH = u(220)
DEPOSIT_HEIGHT = u(170)
DEPOSITS_PER_CHUNK = 8
DEPOSIT_MAX_DURABILITY = 30
DEPOSIT_HIT_INTERVAL = 0.42


def spawn_deposit(world_x):
    rect = pygame.Rect(world_x, floor_y + u(20), DEPOSIT_WIDTH, DEPOSIT_HEIGHT)
    return {"rect": rect, "active": True, "durability": DEPOSIT_MAX_DURABILITY,
            "last_hit": 0.0}


def spawn_mineral_deposits():
    """Ставит много крупных залежей на первом участке шахты."""
    mineral_deposits.clear()
    generate_ore_chunk(0)


next_ore_chunk_x = WIDTH
MINE_REFRESH_SECONDS = 45
last_mine_refresh_time = time.time()


def generate_ore_chunk(start_x):
    """Заполняет новый участок шахты большими месторождениями."""
    spacing = max(u(1), (WIDTH - DEPOSIT_WIDTH) // DEPOSITS_PER_CHUNK)
    for index in range(DEPOSITS_PER_CHUNK):
        jitter = random.randint(-u(22), u(22))
        world_x = start_x + index * spacing + jitter
        mineral_deposits.append(spawn_deposit(max(0, world_x)))


spawn_mineral_deposits()


SURFACE_CHUNK_WIDTH = WIDTH


def surface_ground_y():
    grass_top = floor_y + u(90) - round(WIDTH * 40 / 1258)
    return grass_top + u(45)


def world_block_rect(block):
    return pygame.Rect(block["x"], block["y"], BLOCK_SIZE, BLOCK_SIZE)


def surface_block_tile(world_x, world_y):
    ground_top = surface_ground_y()
    lowest_block_top = ground_top - BLOCK_SIZE
    row = max(0, math.floor((lowest_block_top - world_y) / BLOCK_SIZE))
    tile_x = math.floor(world_x / BLOCK_SIZE) * BLOCK_SIZE
    tile_y = lowest_block_top - row * BLOCK_SIZE
    return pygame.Rect(tile_x, tile_y, BLOCK_SIZE, BLOCK_SIZE)


def place_stone_block(world_x, world_y, player_index=0):
    global last_action_text
    if current_zone != "surface":
        return False
    if inventory.get("stone_block", 0) <= 0:
        last_action_text = "Сначала добудь блок в шахте" if lang == "ru" else "Mine a block in the cave first"
        return False
    actor_x, actor_y = (player_x, player_y) if player_index == 0 else (player2_x, player2_y)
    if abs(world_x - actor_x) > u(300) or abs(world_y - actor_y) > u(300):
        return False
    rect = surface_block_tile(world_x, world_y)
    # Если нажали на уже поставленный блок, следующий блок пристроится сверху.
    # Повторяем поиск, чтобы башню можно было продолжать строить тем же способом.
    while True:
        occupied = next((block for block in reversed(world_blocks)
                         if world_block_rect(block).colliderect(rect)), None)
        if occupied is None:
            break
        rect.y = world_block_rect(occupied).top - BLOCK_SIZE
    players = ((player_x, player_y), (player2_x, player2_y))
    for index, (px, py) in enumerate(players):
        if index < player_count and player_hitbox(px, py).colliderect(rect):
            last_action_text = "Отойди, чтобы поставить блок" if lang == "ru" else "Move away to place the block"
            return False
    world_blocks.append({"x": rect.x, "y": rect.y, "type": "stone"})
    inventory["stone_block"] -= 1
    last_action_text = "Каменный блок поставлен" if lang == "ru" else "Stone block placed"
    save_progress()
    return True


def mine_placed_block(world_x, world_y):
    global last_action_text
    if current_zone != "surface" or selected_tool != "pickaxe":
        return False
    for block in reversed(world_blocks):
        if world_block_rect(block).collidepoint(world_x, world_y):
            world_blocks.remove(block)
            inventory["stone_block"] += 1
            last_action_text = "Добыт каменный блок: +1" if lang == "ru" else "Mined a stone block: +1"
            save_progress()
            return True
    return False


def surface_block_supports_player(world_x, world_y):
    player_box = player_hitbox(world_x, world_y)
    for block in world_blocks:
        rect = world_block_rect(block)
        # Нижняя грань хитбокса персонажа должна касаться верхней грани блока.
        stand_y = rect.top - u(90)
        if abs(world_y - stand_y) <= u(3) and player_box.left < rect.right and player_box.right > rect.left:
            return True
    return False


def surface_block_landing_y(world_x, previous_y, new_y):
    if new_y <= previous_y:
        return None
    player_box = player_hitbox(world_x, new_y)
    landing_y = None
    for block in world_blocks:
        rect = world_block_rect(block)
        stand_y = rect.top - u(90)
        if (previous_y <= stand_y <= new_y and player_box.left < rect.right and
                player_box.right > rect.left and (landing_y is None or stand_y < landing_y)):
            landing_y = stand_y
    return landing_y


def surface_block_ceiling_y(world_x, previous_y, new_y):
    """Останавливает прыжок, если голова персонажа ударилась о нижнюю грань блока."""
    if new_y >= previous_y:
        return None
    old_box = player_hitbox(world_x, previous_y)
    new_box = player_hitbox(world_x, new_y)
    collision_y = None
    for block in world_blocks:
        rect = world_block_rect(block)
        if (old_box.top >= rect.bottom and new_box.top < rect.bottom and
                new_box.left < rect.right and new_box.right > rect.left and
                (collision_y is None or rect.bottom > collision_y)):
            collision_y = rect.bottom + u(20)
    return collision_y


def resolve_surface_block_side(world_x, world_y, previous_x):
    """Не даёт пройти сквозь бок каменного блока на поверхности."""
    if current_zone != "surface":
        return world_x
    player_box = player_hitbox(world_x, world_y)
    previous_box = player_hitbox(previous_x, world_y)
    for block in world_blocks:
        rect = world_block_rect(block)
        if not player_box.colliderect(rect):
            continue
        if previous_box.right <= rect.left:
            world_x = rect.left - u(12) - player_box.width
        elif previous_box.left >= rect.right:
            world_x = rect.right - u(12)
        else:
            world_x = previous_x
        player_box = player_hitbox(world_x, world_y)
    return world_x


def ensure_surface_chunks(camera_x):
    # Позиция камеры может стать дробной после движения игрока, а номера чанков должны быть целыми.
    camera_x = int(camera_x)
    first_chunk = max(0, camera_x // SURFACE_CHUNK_WIDTH - 1)
    last_chunk = (camera_x + WIDTH) // SURFACE_CHUNK_WIDTH + 1
    for chunk_index in range(first_chunk, last_chunk + 1):
        if chunk_index in surface_chunks:
            continue
        rng = random.Random(current_world_seed + chunk_index * 7919)
        objects = []
        kinds = (["melon_bush"] * rng.randint(1, 2) +
                 ["raspberry_bush"] * rng.randint(2, 4) +
                 ["pig"] * rng.randint(1, 2) +
                 ["parrot"] * rng.randint(1, 2))
        rng.shuffle(kinds)
        for kind in kinds:
            world_x = chunk_index * SURFACE_CHUNK_WIDTH + rng.randint(u(220), WIDTH - u(220))
            if chunk_index == 0 and (abs(world_x - mine_entrance_rect.centerx) < u(280) or
                                     abs(world_x - graphics_store_building_rect.centerx) < u(160)):
                world_x = min((chunk_index + 1) * SURFACE_CHUNK_WIDTH - u(220), world_x + u(300))
            obj = {
                "kind": kind, "x": world_x, "active": True, "chunk": chunk_index,
                "amount": rng.randint(1, 3), "hp": 50, "direction": rng.choice((-1, 1)),
                "next_turn": time.time() + rng.uniform(0.5, 2.5),
                "flight_phase": rng.random() * math.tau,
                "next_bite_at": time.time() + rng.uniform(1.5, 4.0)
            }
            if kind == "parrot":
                obj["flight_y"] = surface_ground_y() - u(175)
                obj["flight_target_y"] = obj["flight_y"]
                obj["next_flight_target"] = time.time() + rng.uniform(0.5, 1.5)
            objects.append(obj)
        surface_chunks[chunk_index] = objects


def visible_surface_objects(camera_x):
    camera_x = int(camera_x)
    first_chunk = max(0, camera_x // SURFACE_CHUNK_WIDTH - 1)
    last_chunk = (camera_x + WIDTH) // SURFACE_CHUNK_WIDTH + 1
    for chunk_index in range(first_chunk, last_chunk + 1):
        yield from surface_chunks.get(chunk_index, ())


def surface_object_rect(obj):
    ground = surface_ground_y()
    if obj["kind"] == "parrot":
        bird_size = textures["parrot"].get_size()
        base_y = obj.get("flight_y", ground - u(175))
        flight_y = base_y + round(math.sin(time.time() * 3 + obj.get("flight_phase", 0)) * u(8))
        flight_y = max(u(5), min(ground - bird_size[1], flight_y))
        return pygame.Rect(obj["x"] - bird_size[0] // 2, flight_y, *bird_size)
    if obj["kind"] == "pig":
        return pygame.Rect(obj["x"] - u(36), ground - u(48), u(78), u(48))
    if obj["kind"] in ("melon_bush", "raspberry_bush"):
        bush_size = textures[obj["kind"]].get_size()
        return pygame.Rect(obj["x"] - bush_size[0] // 2, ground - bush_size[1], *bush_size)
    return pygame.Rect(obj["x"] - u(42), ground - u(54), u(84), u(54))


PARROT_BITE_RADIUS = u(95)


def surface_animal_hitbox(obj):
    """Возвращает компактный прямоугольник попадания внутри спрайта животного."""
    sprite_rect = surface_object_rect(obj)
    if obj["kind"] == "parrot":
        width, height = round(sprite_rect.width * 0.68), round(sprite_rect.height * 0.68)
    elif obj["kind"] == "pig":
        width, height = round(sprite_rect.width * 0.78), round(sprite_rect.height * 0.78)
    else:
        return sprite_rect
    return pygame.Rect(sprite_rect.centerx - width // 2, sprite_rect.centery - height // 2,
                       width, height)


def parrot_can_reach_player(parrot, player_x_pos, player_y_pos):
    """Проверяет расстояние от попугая до хитбокса Джерри, включая высоту."""
    bird_center = surface_animal_hitbox(parrot).center
    player_box = player_hitbox(player_x_pos, player_y_pos)
    closest_x = max(player_box.left, min(bird_center[0], player_box.right))
    closest_y = max(player_box.top, min(bird_center[1], player_box.bottom))
    return math.hypot(bird_center[0] - closest_x, bird_center[1] - closest_y) <= PARROT_BITE_RADIUS


def update_surface_pigs(camera_x, now):
    for obj in visible_surface_objects(camera_x):
        if obj["kind"] != "pig" or not obj["active"] or now < obj["next_turn"]:
            continue
        if now < obj.get("knockback_until", 0.0):
            obj["x"] += obj.get("knockback_direction", 0) * u(5) * physics_step
        else:
            obj["x"] += obj["direction"] * u(1.2) * physics_step
        chunk_left = obj["chunk"] * SURFACE_CHUNK_WIDTH + u(100)
        chunk_right = (obj["chunk"] + 1) * SURFACE_CHUNK_WIDTH - u(100)
        if obj["x"] < chunk_left or obj["x"] > chunk_right:
            obj["direction"] *= -1
            obj["x"] = max(chunk_left, min(chunk_right, obj["x"]))
        if now < obj.get("knockback_until", 0.0):
            obj["next_turn"] = now + 0.025
            continue
        if random.random() < 0.015:
            obj["direction"] *= -1
        obj["next_turn"] = now + 0.025


def update_surface_parrots(camera_x, now):
    global player_x, player2_x, player_y, player2_y, player_is_jumping
    global player2_is_jumping, y_velocity, player2_y_velocity, last_action_text
    for obj in visible_surface_objects(camera_x):
        if obj["kind"] != "parrot" or not obj["active"]:
            continue
        ground = surface_ground_y()
        bird_height = textures["parrot"].get_height()
        if now >= obj.get("next_flight_target", 0):
            obj["flight_target_y"] = random.randint(u(5), max(u(5), ground - bird_height))
            obj["next_flight_target"] = now + random.uniform(0.8, 2.0)
        current_y = obj.get("flight_y", ground - u(175))
        target_y = obj.get("flight_target_y", current_y)
        max_step = u(2.2) * physics_step
        if abs(target_y - current_y) <= max_step:
            obj["flight_y"] = target_y
        else:
            obj["flight_y"] = current_y + (max_step if target_y > current_y else -max_step)
        obj["x"] += obj["direction"] * u(1.25) * physics_step
        left_edge = obj["chunk"] * SURFACE_CHUNK_WIDTH + u(100)
        right_edge = (obj["chunk"] + 1) * SURFACE_CHUNK_WIDTH - u(100)
        if obj["x"] <= left_edge or obj["x"] >= right_edge:
            obj["direction"] *= -1
            obj["x"] = max(left_edge, min(right_edge, obj["x"]))

        if now < obj.get("next_bite_at", 0):
            continue
        players = [(player_x, player_y, 0)]
        if player_count == 2:
            players.append((player2_x, player2_y, 1))
        near_players = []
        bird_x, bird_y = surface_animal_hitbox(obj).center
        for px, py, index in players:
            if parrot_can_reach_player(obj, px, py):
                player_box = player_hitbox(px, py)
                closest_x = max(player_box.left, min(bird_x, player_box.right))
                closest_y = max(player_box.top, min(bird_y, player_box.bottom))
                near_players.append((math.hypot(bird_x - closest_x, bird_y - closest_y), index))
        if not near_players:
            continue
        _, index = min(near_players)
        # Попугай не кусает каждый раз: шанс проверяется раз в несколько секунд рядом с птицей.
        obj["next_bite_at"] = now + 3.0
        if random.random() >= 0.32:
            continue
        player_health[index] -= 29
        if player_health[index] <= 0:
            player_health[index] = MAX_PLAYER_HEALTH
            last_action_text = LANG_PACK[lang]["parrot_knockout"]
            if index == 0:
                player_x, player_y = max(0, obj["x"] - u(140)), floor_y
                player_is_jumping, y_velocity = False, 0
            else:
                player2_x, player2_y = max(0, obj["x"] - u(60)), floor_y
                player2_is_jumping, player2_y_velocity = False, 0
        else:
            last_action_text = LANG_PACK[lang]["parrot_bite"]


def draw_surface_object(obj, camera_x):
    rect = surface_object_rect(obj).move(-camera_x, -surface_camera_y)
    x, y = rect.centerx, rect.bottom
    if obj["kind"] == "parrot":
        parrot = textures["parrot"]
        # Исходная картинка попугая смотрит влево (клюв слева), поэтому
        # отражаем её, когда птица летит вправо.
        mirrored = obj["direction"] > 0
        if mirrored:
            parrot = pygame.transform.flip(parrot, True, False)
        screen.blit(parrot, rect)
        if "parrot_wing" in textures:
            wing = textures["parrot_wing"]
            wing_anchor_x, wing_anchor_y = max(1, u(2)), max(1, u(1))
            if mirrored:
                wing = pygame.transform.flip(wing, True, False)
                wing_anchor_x = wing.get_width() - wing_anchor_x
            flap_degrees = math.sin(time.time() * 11 + obj.get("flight_phase", 0)) * 32
            # Крыло поворачивается вместе с попугаем: при развороте влево меняем
            # знак взмаха и крепим его к противоположной стороне тела.
            wing_angle = -flap_degrees if mirrored else flap_degrees
            rotated_wing = pygame.transform.rotate(wing, -wing_angle)
            hinge_x = rect.x + round(parrot.get_width() * (0.82 if mirrored else 0.18))
            hinge_y = rect.y + round(parrot.get_height() * 0.28)
            dx = wing_anchor_x - wing.get_width() / 2
            dy = wing_anchor_y - wing.get_height() / 2
            angle = math.radians(wing_angle)
            rotated_dx = dx * math.cos(angle) - dy * math.sin(angle)
            rotated_dy = dx * math.sin(angle) + dy * math.cos(angle)
            rotated_wing_rect = rotated_wing.get_rect(
                center=(round(hinge_x - rotated_dx), round(hinge_y - rotated_dy)))
            screen.blit(rotated_wing, rotated_wing_rect)
    elif obj["kind"] == "melon_bush":
        screen.blit(textures["melon_bush"], rect)
    elif obj["kind"] == "raspberry_bush":
        screen.blit(textures["raspberry_bush"], rect)
    else:
        direction = obj["direction"]
        outline = (112, 65, 67)
        skin = (224, 137, 147)
        shadow = (176, 91, 106)
        light = (250, 183, 185)

        # Ноги сначала, чтобы они выглядели под телом, а не нарисованными сверху.
        for leg_x in (x - u(22), x - u(2), x + u(15)):
            leg = pygame.Rect(leg_x, y - u(18), u(8), u(16))
            pygame.draw.rect(screen, shadow, leg, border_radius=u(3))
            hoof = pygame.Rect(leg_x - u(1), y - u(5), u(10), u(5))
            pygame.draw.rect(screen, outline, hoof, border_radius=u(2))
            pygame.draw.line(screen, (70, 48, 50), (hoof.centerx, hoof.y + u(1)),
                             (hoof.centerx, hoof.bottom - u(1)), max(1, u(1)))

        # Петелька хвоста сзади и округлое тело с мягкой тенью по нижнему краю.
        tail_x = x - direction * u(31)
        pygame.draw.arc(screen, shadow, pygame.Rect(tail_x - u(5), y - u(38), u(12), u(15)),
                        math.radians(205), math.radians(510), max(1, u(3)))
        body = pygame.Rect(x - u(33), y - u(39), u(58), u(37))
        pygame.draw.ellipse(screen, outline, body.inflate(u(3), u(3)))
        pygame.draw.ellipse(screen, skin, body)
        belly = pygame.Rect(body.x + u(8), body.y + u(22), body.width - u(13), u(12))
        pygame.draw.ellipse(screen, (210, 116, 129), belly)
        pygame.draw.ellipse(screen, light, pygame.Rect(body.x + u(9), body.y + u(4),
                                                       u(30), u(9)))
        # Небольшие естественные пятнышки на коже.
        for spot_x, spot_y, spot_w, spot_h in ((-19, -25, 7, 4), (-7, -31, 5, 3),
                                                (5, -24, 6, 4), (-13, -17, 4, 3)):
            sx = x + u(spot_x) * direction
            spot = pygame.Rect(sx, y + u(spot_y), u(spot_w), u(spot_h))
            pygame.draw.ellipse(screen, (199, 105, 120), spot)

        # Голова, треугольное ухо и выступающее рыло смотрят по направлению движения.
        head_x = x + direction * u(20)
        ear_points = [(head_x - direction * u(8), y - u(38)),
                      (head_x - direction * u(5), y - u(55)),
                      (head_x + direction * u(5), y - u(40))]
        pygame.draw.polygon(screen, outline, [(px + direction * u(1), py + u(1))
                                               for px, py in ear_points])
        pygame.draw.polygon(screen, shadow, ear_points)
        inner_ear = [(head_x - direction * u(5), y - u(41)),
                     (head_x - direction * u(4), y - u(50)),
                     (head_x + direction * u(1), y - u(42))]
        pygame.draw.polygon(screen, (241, 145, 158), inner_ear)
        head = pygame.Rect(head_x - u(15), y - u(44), u(31), u(31))
        pygame.draw.ellipse(screen, outline, head.inflate(u(2), u(2)))
        pygame.draw.ellipse(screen, (235, 153, 164), head)
        pygame.draw.ellipse(screen, light, pygame.Rect(head.x + u(7), head.y + u(4),
                                                       u(14), u(7)))
        snout = pygame.Rect(head_x + direction * u(8) - u(2), y - u(34), u(18), u(13))
        pygame.draw.ellipse(screen, outline, snout.inflate(u(2), u(2)))
        pygame.draw.ellipse(screen, (242, 164, 174), snout)
        for nostril_offset in (4, 12):
            pygame.draw.ellipse(screen, shadow,
                                (head_x + direction * u(nostril_offset), y - u(30), u(3), u(4)))

        eye_x = head_x + direction * u(4)
        pygame.draw.circle(screen, (255, 240, 220), (eye_x, y - u(36)), u(4))
        pygame.draw.circle(screen, (45, 35, 38), (eye_x + direction * u(1), y - u(36)), u(2))
        pygame.draw.circle(screen, (255, 255, 255), (eye_x + direction * u(1), y - u(37)), max(1, u(1)))


def interact_surface():
    global last_action_text
    players = [player_x] + ([player2_x] if player_count == 2 else [])
    candidates = []
    for obj in visible_surface_objects(camera_x):
        if obj["kind"] in ("melon_bush", "raspberry_bush") and obj["active"]:
            distance = min(abs(px - obj["x"]) for px in players)
            if distance <= u(145):
                candidates.append((distance, obj))
    if not candidates:
        return False
    _, obj = min(candidates, key=lambda pair: pair[0])
    if obj["kind"] == "melon_bush":
        inventory["melon"] += obj["amount"]
        last_action_text = LANG_PACK[lang]["gathered_melon"].format(obj["amount"])
    else:
        inventory["raspberry"] += obj["amount"]
        last_action_text = LANG_PACK[lang]["gathered_raspberry"].format(obj["amount"])
    obj["active"] = False
    return True


def damage_surface_pig_at(mouse_pos, camera_x, vertical_camera=0):
    global last_action_text
    if current_zone != "surface":
        return False
    world_point = (mouse_pos[0] + camera_x, mouse_pos[1] + vertical_camera)
    if any(obj["kind"] == "parrot" and obj["active"] and
           surface_animal_hitbox(obj).collidepoint(world_point)
           for obj in visible_surface_objects(camera_x)):
        # Попугаи — мирные животные и не получают урон от кликов или оружия.
        return True
    pigs = [obj for obj in visible_surface_objects(camera_x)
            if obj["kind"] == "pig" and obj["active"]]
    for pig in reversed(pigs):
        if not surface_animal_hitbox(pig).collidepoint(world_point):
            continue
        players = [player_x] + ([player2_x] if player_count == 2 else [])
        if min(abs(px - pig["x"]) for px in players) > u(260):
            continue
        if selected_tool != "sword" or not owns_sword():
            last_action_text = LANG_PACK[lang]["need_sword_pig"]
            return True
        queue_sword_attack(pig, "pig")
        return True
    return False


def queue_sword_attack(target, target_kind):
    global last_action_text, player_facing_right, player2_facing_right
    now = time.time()
    players = [(player_x, player_is_jumping, 0)]
    if player_count == 2:
        players.append((player2_x, player2_is_jumping, 1))
    player_position, _, player_index = min(players, key=lambda item: abs(item[0] - target["x"]))
    if now < sword_attack_ready_at[player_index]:
        return
    sword_attack_ready_at[player_index] = now + 0.02
    mining_animation_started[player_index] = now
    facing_right = target["x"] >= player_position
    if player_index == 0:
        player_facing_right = facing_right
    else:
        player2_facing_right = facing_right
    pending_sword_attacks.append({"target": target, "kind": target_kind,
                                  "player": player_index, "impact_at": now + 0.02})


def apply_sword_attack(attack):
    global last_action_text
    target = attack["target"]
    kind = attack["kind"]
    player_index = attack["player"]
    if not target.get("active", False):
        return
    jumping = player_is_jumping if player_index == 0 else player2_is_jumping
    damage = (100 if jumping else 50) if has_iron_sword else (70 if jumping else 35) if has_stone_sword else (50 if jumping else 25)
    target["hp"] -= damage
    target_x = target["x"]
    player_position = player_x if player_index == 0 else player2_x
    direction = 1 if target_x >= player_position else -1
    if jumping:
        target["knockback_direction"] = direction
        target["knockback_until"] = time.time() + 0.22
        if kind == "dandelion":
            target["x"] += direction * u(45)
            target["facing_right"] = direction > 0
    if kind == "pig":
        if target["hp"] <= 0:
            target["active"] = False
            inventory["raw_pork"] += random.randint(1, 3)
            inventory["bone"] += random.randint(1, 2)
            last_action_text = LANG_PACK[lang]["pig_killed"]
            bonus_food = [item for item, chance in MOD_PIG_DROPS.items() if random.random() < chance]
            for item in bonus_food:
                inventory[item] += 1
            if bonus_food:
                food_names = ", ".join(RESOURCE_NAMES[lang].get(item, item) for item in bonus_food)
                last_action_text += " + " + food_names
        else:
            last_action_text = (LANG_PACK[lang]["critical_hit"].format(damage, target["hp"])
                                if jumping else LANG_PACK[lang]["pig_hit"].format(target["hp"]))
    else:
        if target["hp"] <= 0:
            target["active"] = False
            inventory["magic_stone"] += 2
            inventory["diamond"] += 15
            last_action_text = LANG_PACK[lang]["flower_defeated"]
        else:
            last_action_text = (LANG_PACK[lang]["critical_hit"].format(damage, target["hp"])
                                if jumping else LANG_PACK[lang]["flower_hit_sword"].format(target["hp"]))


def process_pending_sword_attacks(now):
    ready = [attack for attack in pending_sword_attacks if now >= attack["impact_at"]]
    pending_sword_attacks[:] = [attack for attack in pending_sword_attacks if now < attack["impact_at"]]
    for attack in ready:
        apply_sword_attack(attack)


def eat_melon():
    global melon_speed_until, last_action_text
    if inventory["melon"] <= 0:
        return
    inventory["melon"] -= 1
    melon_speed_until = time.time() + 5
    healing_player = min(range(player_count), key=lambda index: player_health[index])
    previous_health = player_health[healing_player]
    player_health[healing_player] = min(MAX_PLAYER_HEALTH, previous_health + 5)
    last_action_text = LANG_PACK[lang]["ate_melon"].format(player_health[healing_player] - previous_health)


def use_inventory_item(item):
    global last_action_text, gromki, melon_speed_until
    if inventory[item] <= 0:
        return
    if item == "melon":
        eat_melon()
    elif item in MOD_ITEM_EFFECTS:
        effect, effect_amount = MOD_ITEM_EFFECTS[item]
        if effect in ("heal", "heal_speed"):
            active_players = range(2) if player_count == 2 else range(1)
            healing_player = min(active_players, key=lambda index: player_health[index])
            previous_health = player_health[healing_player]
            player_health[healing_player] = min(MAX_PLAYER_HEALTH, previous_health + effect_amount)
            restored = player_health[healing_player] - previous_health
            if restored > 0 or effect == "heal_speed":
                inventory[item] -= 1
                if effect == "heal_speed":
                    duration = MOD_ITEM_SPEED_DURATIONS.get(item, 5)
                    melon_speed_until = max(melon_speed_until, time.time() + duration)
                    messages = {
                        "ru": "Съел {}: здоровье +{}, скорость повышена на {} сек.",
                        "en": "Used {}: health +{}, speed boosted for {} sec.",
                        "es": "Usaste {}: salud +{}, velocidad aumentada {} s.",
                        "zh": "使用了{}：生命值+{}，速度提升{}秒。",
                        "ja": "{}を使用：体力+{}、速度が{}秒上昇。"
                    }
                    last_action_text = messages[lang].format(
                        RESOURCE_NAMES[lang].get(item, item), restored, round(duration))
                else:
                    message = ("Восстановлено здоровья: +{}" if lang == "ru" else "Health restored: +{}")
                    last_action_text = message.format(restored)
            else:
                last_action_text = "Здоровье уже полное" if lang == "ru" else "Health is already full"
    elif item == "bone" and inventory["bone"] >= 2:
        inventory["bone"] -= 2
        inventory["gelatin"] += 1
        last_action_text = LANG_PACK[lang]["made_gelatin"]
    elif item == "raspberry" and inventory["raspberry"] > 0 and inventory["gelatin"] > 0:
        inventory["raspberry"] -= 1
        inventory["gelatin"] -= 1
        inventory["marmalade"] += 1
        last_action_text = LANG_PACK[lang]["made_marmalade"]
    else:
        inventory[item] -= 1
        gromki += prices[item]
        last_action_text = LANG_PACK[lang]["sold"].format(prices[item])


def sell_all_inventory_item(item):
    global last_action_text, gromki
    amount = inventory.get(item, 0)
    if amount <= 0 or item in ("melon", "bone", "raspberry") and (
            item == "melon" or item == "bone" and amount >= 2 or
            item == "raspberry" and inventory.get("gelatin", 0) > 0):
        return
    total = amount * prices[item]
    inventory[item] = 0
    gromki += total
    last_action_text = LANG_PACK[lang]["sold"].format(total)


COLLAPSE_INTERVAL = (WIDTH * 4, WIDTH * 7)
collapse_next_trigger_x = WIDTH * 3
collapse_stage = "waiting"
collapse_started_at = 0
collapse_wall_x = 0
collapse_boulder_count = 3
collapse_top_count = 1
collapse_small_stones = []
collapse_boulders = []


def start_mine_collapse(world_x):
    """Пускает мелкие камни, затем случайную груду валунов позади игроков."""
    global collapse_stage, collapse_started_at, collapse_wall_x, collapse_small_stones, collapse_boulders, collapse_boulder_count, collapse_top_count
    collapse_boulder_count = random.randint(3, 12)
    collapse_top_count = random.randint(1, min(3, collapse_boulder_count // 2))
    bottom_count = collapse_boulder_count - collapse_top_count
    total_wall_width = bottom_count * (boulder_size[0] - u(4)) + u(4)
    collapse_wall_x = max(0, world_x - total_wall_width - u(35))
    collapse_started_at = time.time()
    collapse_stage = "pebbles"
    collapse_boulders = []
    collapse_small_stones = []
    for _ in range(9):
        rock_rect = pygame.Rect(
            random.randint(collapse_wall_x, collapse_wall_x + total_wall_width - small_rock_texture.get_width()),
            -random.randint(u(20), u(380)),
            small_rock_texture.get_width(), small_rock_texture.get_height()
        )
        collapse_small_stones.append({"rect": rock_rect, "speed": random.uniform(2, 6), "landed": False})


def update_mine_collapse(now):
    global collapse_stage, collapse_started_at, collapse_boulders
    floor_surface_y = floor_y + u(90)
    for rock in collapse_small_stones:
        if not rock["landed"]:
            rock["rect"].y += round(rock["speed"] * physics_step)
            rock["speed"] += 0.45 * physics_step
            if rock["rect"].bottom >= floor_surface_y:
                rock["rect"].bottom = floor_surface_y
                rock["landed"] = True

    if collapse_stage == "pebbles" and now - collapse_started_at >= 1.5:
        collapse_stage = "boulders_falling"
        collapse_started_at = now
        boulder_w, boulder_h = boulder_size
        floor_surface_y = floor_y + u(90)
        top_count = collapse_top_count
        bottom_count = collapse_boulder_count - top_count
        gap = boulder_w - u(4)
        for row, row_count in enumerate((bottom_count, top_count)):
            if row_count == 0:
                continue
            row_width = (row_count - 1) * gap + boulder_w
            # Верхний ряд ставим над передними (правыми) валунами нижнего ряда.
            row_start_x = collapse_wall_x + (bottom_count - row_count) * gap
            for index in range(row_count):
                rect = pygame.Rect(row_start_x + index * gap,
                                   -boulder_h * (index + 1 + row), boulder_w, boulder_h)
                collapse_boulders.append({
                    "rect": rect, "target_y": floor_surface_y - boulder_h * (row + 1),
                    "speed": 0.0, "landed": False, "hits_left": 15, "row": row,
                    "bounces": 0,
                    "id": len(collapse_boulders), "support_id": None, "support_point": None,
                    "texture_index": random.randrange(len(boulder_textures))
                })
        bottom_boulders = [b for b in collapse_boulders if b["row"] == 0]
        for upper in (b for b in collapse_boulders if b["row"] == 1):
            support = min(bottom_boulders,
                          key=lambda b: abs(b["rect"].centerx - upper["rect"].centerx))
            upper["support_id"] = support["id"]
            upper["support_point"] = pygame.Rect(upper["rect"].centerx - u(2),
                                                   support["rect"].top - u(2), u(4), u(4))

    if collapse_stage == "boulders_falling":
        gravity_force = u(0.62) * physics_step
        terminal_speed = u(18)
        for boulder in collapse_boulders:
            if boulder["landed"]:
                continue
            boulder["speed"] = min(terminal_speed, boulder["speed"] + gravity_force)
            old_bottom = boulder["rect"].bottom
            next_y = boulder["rect"].y + round(boulder["speed"] * physics_step)
            next_bottom = next_y + boulder["rect"].height
            boulder_box = boulder_hitbox(boulder)
            supports = []
            for other in collapse_boulders:
                if other is boulder or not other["landed"]:
                    continue
                other_box = boulder_hitbox(other)
                overlap_left = max(boulder_box.left, other_box.left)
                overlap_right = min(boulder_box.right, other_box.right)
                if overlap_left < overlap_right:
                    contact_x = (overlap_left + overlap_right) // 2
                    support_y = boulder_surface_y(other, contact_x)
                    if old_bottom <= support_y <= next_bottom:
                        supports.append((other, support_y))
            support_pair = min(supports, key=lambda item: item[1]) if supports else None
            support = support_pair[0] if support_pair else None
            impact_y = support_pair[1] if support_pair else floor_surface_y
            if boulder["speed"] >= 0 and next_bottom >= impact_y:
                boulder["rect"].bottom = impact_y
                impact_speed = boulder["speed"]
                if impact_speed >= u(5) and boulder["bounces"] < 2:
                    # Тяжёлые камни подпрыгивают после сильного удара и быстро затихают.
                    boulder["speed"] = -impact_speed * 0.28
                    boulder["bounces"] += 1
                    boulder["landed"] = False
                    boulder["support_id"] = None
                    boulder["support_point"] = None
                else:
                    boulder["speed"] = 0.0
                    boulder["landed"] = True
                    boulder["support_id"] = support["id"] if support else None
                    boulder["support_point"] = (pygame.Rect(boulder["rect"].centerx - u(2),
                                                              impact_y - u(2), u(4), u(4))
                                                  if support else None)
            else:
                boulder["rect"].y = next_y
        if collapse_boulders and all(boulder["landed"] for boulder in collapse_boulders):
            collapse_stage = "blocked"


def player_hitbox(world_x, world_y):
    """Хитбокс игрока по ширине равен каменному блоку."""
    return pygame.Rect(world_x + u(12), world_y - u(20), BLOCK_SIZE, u(110))


def pet_character_at(world_x, world_y, actor_index=0):
    """Создаёт короткий эффект сердечек, если Shift+клик попал в персонажа."""
    global last_action_text
    click_point = (int(world_x), int(world_y))
    targets = []

    # Другой игрок. Своего персонажа гладить нельзя.
    if player_count == 2:
        positions = ((player_x, player_y), (player2_x, player2_y))
        for index, (target_x, target_y) in enumerate(positions):
            if index != actor_index and player_hitbox(target_x, target_y).inflate(u(16), u(12)).collidepoint(click_point):
                targets.append((0, target_x + u(36), target_y - u(38)))

    if current_zone == "surface":
        for obj in visible_surface_objects(camera_x):
            if obj["active"] and obj["kind"] in ("pig", "parrot") and surface_animal_hitbox(obj).collidepoint(click_point):
                target_rect = surface_animal_hitbox(obj)
                targets.append((1, target_rect.centerx, target_rect.top))
    else:
        for enemy in dandelions:
            if (enemy["active"] and enemy["phase"] not in ("digging", "underground") and
                    dandelion_sprite_rect(enemy).collidepoint(click_point)):
                target_rect = dandelion_sprite_rect(enemy)
                targets.append((1, target_rect.centerx, target_rect.top))
        for spider in spiders:
            if spider["active"] and spider_sprite_rect(spider).collidepoint(click_point):
                target_rect = spider_sprite_rect(spider)
                targets.append((1, target_rect.centerx, target_rect.top))

    if not targets:
        return False
    _, target_x, target_y = targets[0]
    now = time.time()
    pet_effects.append({"x": target_x, "y": target_y, "started": now, "expires": now + 1.1})
    del pet_effects[:-20]
    last_action_text = LANG_PACK[lang]["pet_success"]
    return True


def draw_pet_effects(camera_x, vertical_camera=0):
    now = time.time()
    pet_effects[:] = [effect for effect in pet_effects if effect["expires"] > now]
    for effect in pet_effects:
        progress = min(1.0, max(0.0, (now - effect["started"]) / 1.1))
        center_x = round(effect["x"] - camera_x)
        center_y = round(effect["y"] - u(12) - u(24) * progress - vertical_camera)
        radius = max(2, u(5))
        heart_color = (255, 75, 145)
        pygame.draw.circle(screen, heart_color, (center_x - radius // 2, center_y), radius)
        pygame.draw.circle(screen, heart_color, (center_x + radius // 2, center_y), radius)
        pygame.draw.polygon(screen, heart_color,
                            [(center_x - radius * 1.4, center_y + radius // 2),
                             (center_x + radius * 1.4, center_y + radius // 2),
                             (center_x, center_y + radius * 2)])


def damage_other_player_at(mouse_pos, camera_x, attacker_index=None, vertical_camera=0):
    """Sword clicks can hit the other player; the server applies the damage."""
    global player_x, player_y, player2_x, player2_y, player_health
    global player_is_jumping, player2_is_jumping, y_velocity, player2_y_velocity, last_action_text
    if player_count < 2:
        return False
    click_x, click_y = mouse_pos[0] + camera_x, mouse_pos[1] + vertical_camera
    player_positions = [(player_x, player_y), (player2_x, player2_y)]
    target_index = next((index for index, (world_x, world_y) in enumerate(player_positions)
                         if player_hitbox(world_x, world_y).inflate(u(16), u(12)).collidepoint(click_x, click_y)), None)
    if target_index is None:
        return False
    if attacker_index is None:
        attacker_index = 1 - target_index
    if attacker_index not in (0, 1) or target_index == attacker_index:
        return False
    attacker_x = player_positions[attacker_index][0]
    if abs(player_positions[target_index][0] - attacker_x) > u(150):
        return False
    if selected_tool != "sword" or not owns_sword():
        last_action_text = LANG_PACK[lang]["need_sword"]
        return True
    now = time.time()
    if now < pvp_attack_ready_at[attacker_index]:
        return True
    pvp_attack_ready_at[attacker_index] = now + 0.35
    target_x, _ = player_positions[target_index]
    jumping = player_is_jumping if attacker_index == 0 else player2_is_jumping
    damage = 12 if has_iron_sword else 8 if has_stone_sword else 5
    if jumping:
        damage *= 2
    player_health[target_index] = max(0, player_health[target_index] - damage)
    direction = 1 if target_x >= attacker_x else -1
    knockback = u(95 if jumping else 55)
    if target_index == 0:
        player_x += direction * knockback
        if jumping:
            y_velocity = -u(5)
    else:
        player2_x += direction * knockback
        if jumping:
            player2_y_velocity = -u(5)
    mining_animation_started[attacker_index] = now
    if player_health[target_index] <= 0:
        player_health[target_index] = MAX_PLAYER_HEALTH
        respawn_x = (mine_entrance_rect.right + u(20 + target_index * 100)
                     if current_zone == "mine" else u(300 + target_index * 100))
        if target_index == 0:
            player_x, player_y = respawn_x, floor_y
            player_is_jumping, y_velocity = False, 0
        else:
            player2_x, player2_y = respawn_x, floor_y
            player2_is_jumping, player2_y_velocity = False, 0
        player_damage_cooldown[target_index] = now + 1.0
        last_action_text = LANG_PACK[lang]["pvp_knockout"]
    else:
        last_action_text = LANG_PACK[lang]["pvp_hit"].format(damage)
    return True


def spawn_dandelion(world_x):
    dandelions.append({"active": True, "x": int(world_x), "phase": "walking", "timer": 0.0,
                       "hp": 100, "facing_right": False, "walk_phase": 0})


def dandelion_hitbox(dandelion, rise=0):
    floor_surface_y = floor_y + u(90)
    return pygame.Rect(dandelion["x"] + u(10), floor_surface_y - u(88) + rise,
                       u(56), u(92))


def dandelion_sprite_rect(dandelion, rise=0, camera_x=0):
    floor_surface_y = floor_y + u(90)
    return pygame.Rect(dandelion["x"] - camera_x,
                       floor_surface_y - dandelion_texture.get_height() + rise,
                       dandelion_texture.get_width(), dandelion_texture.get_height())


def nearest_player(dandelion):
    players = [(player_x, player_y, 0)]
    if player_count == 2:
        players.append((player2_x, player2_y, 1))
    return min(players, key=lambda player: abs(player[0] - dandelion["x"]))


def update_dandelion(dandelion, now):
    global player_x, player2_x, player_y, player2_y, player_is_jumping, player2_is_jumping
    global y_velocity, player2_y_velocity, last_action_text
    if not dandelion["active"] or current_zone != "mine":
        return
    dt = physics_step / 60
    if now < dandelion.get("knockback_until", 0.0):
        dandelion["x"] += dandelion.get("knockback_direction", 0) * u(2) * physics_step
        return
    target_x, target_y, target_index = nearest_player(dandelion)
    phase = dandelion["phase"]
    dandelion["timer"] += dt
    if phase == "walking":
        dx = target_x - dandelion["x"]
        dandelion["facing_right"] = dx > 0
        dandelion["x"] += (1 if dx > 0 else -1) * min(abs(dx), round(u(5.5) * physics_step))
        dandelion["walk_phase"] += 1
        if abs(dx) <= u(500):
            dandelion["phase"], dandelion["timer"] = "digging", 0.0
    elif phase == "digging":
        if dandelion["timer"] >= 0.65:
            dandelion["phase"], dandelion["timer"] = "underground", 0.0
    elif phase == "underground":
        target_x, target_y, target_index = nearest_player(dandelion)
        dx = target_x + u(30) - dandelion["x"]
        if abs(dx) <= u(24):
            dandelion["x"] = target_x - u(8)
            dandelion["phase"], dandelion["timer"] = "emerging", 0.0
        else:
            dandelion["facing_right"] = dx > 0
            dandelion["x"] += (1 if dx > 0 else -1) * min(abs(dx), round(u(13) * physics_step))
    elif phase == "emerging":
        if dandelion["timer"] >= 0.7:
            dandelion["phase"], dandelion["timer"] = "attacking", 0.0
    elif phase == "attacking":
        if dandelion["timer"] >= 1.8:
            dandelion["phase"], dandelion["timer"] = "digging", 0.0
        else:
            enemy_box = dandelion_hitbox(dandelion)
            player_boxes = [player_hitbox(player_x, player_y)]
            if player_count == 2:
                player_boxes.append(player_hitbox(player2_x, player2_y))
            for index, box in enumerate(player_boxes):
                if box.colliderect(enemy_box) and now >= player_damage_cooldown[index]:
                    player_health[index] -= 1
                    player_damage_cooldown[index] = now + 0.7
                    last_action_text = LANG_PACK[lang]["flower_attacked"]
                    if player_health[index] <= 0:
                        player_health[index] = MAX_PLAYER_HEALTH
                        last_action_text = LANG_PACK[lang]["flower_knocked_out"]
                        if index == 0:
                            player_x, player_y = mine_entrance_rect.right + u(20), floor_y
                            player_is_jumping, y_velocity = False, 0
                        else:
                            player2_x, player2_y = mine_entrance_rect.right + u(120), floor_y
                            player2_is_jumping, player2_y_velocity = False, 0
                        player_damage_cooldown[index] = now + 2.0


def update_dandelions(now):
    for enemy in list(dandelions):
        update_dandelion(enemy, now)
    dandelions[:] = [enemy for enemy in dandelions if enemy["active"]]


def spider_sprite_rect(spider, camera_x=0):
    texture = textures["spider"]
    return pygame.Rect(round(spider["x"] - texture.get_width() / 2) - int(camera_x),
                       round(spider["y"]), texture.get_width(), texture.get_height())


def shoot_spider_web(spider, now):
    players = [(player_x, player_y, 0)]
    if player_count == 2:
        players.append((player2_x, player2_y, 1))
    target_x, target_y, target_index = min(players, key=lambda p: abs(p[0] - spider["x"]))
    start_x = spider["x"]
    start_y = spider["y"] + textures["spider"].get_height() * 0.72
    dx = target_x - start_x
    dy = (target_y - u(48)) - start_y
    distance = max(1.0, math.hypot(dx, dy))
    speed = u(8)
    web_projectiles.append({
        "x": float(start_x), "y": float(start_y),
        "vx": dx / distance * speed, "vy": dy / distance * speed,
        "target": target_index, "created_at": now, "active": True
    })
    spider["shots"] += 1
    spider["next_shot"] = now + random.uniform(1.6, 2.2)
    if spider["shots"] >= 3:
        spider["phase"] = "retreating"


def update_spider_encounters(now):
    global next_spider_spawn_time, last_action_text
    if current_zone != "mine" or netplay.role == "client":
        return

    if now >= next_spider_spawn_time and sum(s["active"] for s in spiders) < 2:
        players = [(player_x, player_y, 0)]
        if player_count == 2:
            players.append((player2_x, player2_y, 1))
        target_x, target_y, target_index = random.choice(players)
        spider_x = max(0, target_x + random.randint(-u(260), u(260)))
        target_drop_y = max(u(115), min(target_y - u(135), floor_y - u(140)))
        spiders.append({
            "active": True, "x": spider_x, "y": u(4), "target_y": target_drop_y,
            "phase": "descending", "target": target_index,
            "next_shot": now + 0.8, "shots": 0
        })
        next_spider_spawn_time = now + random.uniform(25, 36)

    for spider in spiders:
        if not spider["active"]:
            continue
        if spider["phase"] == "descending":
            spider["y"] = min(spider["target_y"], spider["y"] + u(3) * physics_step)
            if spider["y"] >= spider["target_y"]:
                spider["phase"] = "hanging"
                spider["next_shot"] = now + 0.65
        elif spider["phase"] == "hanging" and now >= spider["next_shot"]:
            shoot_spider_web(spider, now)
        elif spider["phase"] == "retreating":
            spider["y"] = max(u(4), spider["y"] - u(4) * physics_step)
            if spider["y"] <= u(4):
                spider["active"] = False

    for projectile in web_projectiles:
        if not projectile["active"]:
            continue
        projectile["x"] += projectile["vx"] * physics_step
        projectile["y"] += projectile["vy"] * physics_step
        target_index = projectile["target"]
        target_x, target_y = (player_x, player_y) if target_index == 0 else (player2_x, player2_y)
        web_rect = pygame.Rect(round(projectile["x"] - u(18)), round(projectile["y"] - u(18)),
                               u(36), u(36))
        if web_rect.colliderect(player_hitbox(target_x, target_y)):
            if random.random() < 0.40:
                player_frozen_until[target_index] = max(player_frozen_until[target_index], now + 10.0)
                player_slowed_until[target_index] = 0.0
                last_action_text = LANG_PACK[lang]["spider_frozen"]
            else:
                player_slowed_until[target_index] = max(player_slowed_until[target_index], now + 6.0)
                last_action_text = LANG_PACK[lang]["spider_slow"]
            projectile["active"] = False
        elif now - projectile["created_at"] >= 4.0:
            projectile["active"] = False

    spiders[:] = [spider for spider in spiders if spider["active"]]
    web_projectiles[:] = [web for web in web_projectiles if web["active"]]


def draw_spiders_and_webs(camera_x):
    for spider in spiders:
        rect = spider_sprite_rect(spider, camera_x)
        thread_x = rect.centerx
        # Тонкая нить соединяет паука с потолком шахты.
        pygame.draw.line(screen, (90, 85, 82), (thread_x, 0), (thread_x, rect.top), max(1, u(2)))
        screen.blit(textures["spider"], rect)
    for web in web_projectiles:
        angle = math.degrees(math.atan2(web["vy"], web["vx"]))
        sprite = pygame.transform.rotate(textures["web"], -angle)
        rect = sprite.get_rect(center=(round(web["x"] - camera_x), round(web["y"])))
        screen.blit(sprite, rect)


def damage_dandelion_at(mouse_pos, camera_x):
    global last_action_text
    for dandelion in reversed(dandelions):
        if not dandelion["active"] or dandelion["phase"] in ("digging", "underground"):
            continue
        rise = 0
        if dandelion["phase"] == "emerging":
            progress = min(1.0, dandelion["timer"] / 0.7)
            rise = round((1 - progress) * u(80))
        target_box = dandelion_sprite_rect(dandelion, rise).inflate(u(18), u(12))
        if not target_box.collidepoint(mouse_pos[0] + camera_x, mouse_pos[1]):
            continue
        if selected_tool not in ("pickaxe", "sword"):
            last_action_text = LANG_PACK[lang]["flower_need_weapon"]
            return True
        if selected_tool == "sword":
            if not owns_sword():
                last_action_text = LANG_PACK[lang]["flower_need_weapon"]
                return True
            queue_sword_attack(dandelion, "dandelion")
            return True
        damage = 10
        dandelion["hp"] -= damage
        if dandelion["hp"] <= 0:
            dandelion["active"] = False
            inventory["magic_stone"] += 2
            inventory["diamond"] += 15
            last_action_text = LANG_PACK[lang]["flower_defeated"]
        else:
            hit_message = "flower_hit_sword" if selected_tool == "sword" else "flower_hit"
            last_action_text = LANG_PACK[lang][hit_message].format(dandelion["hp"])
        return True
    return False


def ore_hitbox(ore_rect):
    """Рабочая зона большого месторождения."""
    return ore_rect.inflate(-u(24), -u(18))


def boulder_hitbox(boulder):
    """Возвращает плотные границы именно того рисунка валуна, который выбран."""
    rect = boulder["rect"]
    bounds = boulder_textures[boulder["texture_index"]].get_bounding_rect()
    return pygame.Rect(rect.x + bounds.x, rect.y + bounds.y, bounds.width, bounds.height)


def boulder_mask_overlaps(player_rect, boulder):
    """Проверяет пересечение игрока с непрозрачной формой конкретного валуна."""
    player_mask = pygame.mask.Mask(player_rect.size, fill=True)
    offset = (player_rect.x - boulder["rect"].x, player_rect.y - boulder["rect"].y)
    return boulder_masks[boulder["texture_index"]].overlap(player_mask, offset) is not None


def boulder_surface_y(boulder, world_x):
    """Находит высоту верхней поверхности валуна под указанной точкой по X."""
    rect = boulder["rect"]
    mask = boulder_masks[boulder["texture_index"]]
    local_x = max(0, min(mask.get_size()[0] - 1, world_x - rect.x))
    for local_y in range(mask.get_size()[1]):
        if mask.get_at((local_x, local_y)):
            return rect.y + local_y
    return rect.bottom


def supported_by_boulder(world_x, world_y):
    feet = player_hitbox(world_x, world_y)
    for boulder in collapse_boulders:
        if boulder["landed"]:
            top = boulder_hitbox(boulder)
            surface_y = boulder_surface_y(boulder, feet.centerx)
            if feet.right > top.left and feet.left < top.right and abs(feet.bottom - surface_y) <= u(3):
                return True
    return False


def resolve_boulder_collision(world_x, world_y, previous_x, previous_y, vertical_speed, is_jumping):
    player_rect = player_hitbox(world_x, world_y)
    previous_rect = player_hitbox(previous_x, previous_y)
    for boulder in collapse_boulders:
        obstacle = boulder_hitbox(boulder)
        if not boulder["landed"]:
            # Пока камень падает, его вертикальная проекция до пола закрыта:
            # игрока выталкивает в сторону, вместо того чтобы застрять под камнем.
            floor_surface_y = floor_y + u(90)
            column_height = max(1, floor_surface_y - boulder["rect"].bottom)
            danger_column = pygame.Rect(obstacle.left, boulder["rect"].bottom,
                                        obstacle.width, column_height)
            if player_rect.colliderect(danger_column):
                if world_x > previous_x:
                    world_x = danger_column.left - u(12) - player_rect.width
                elif world_x < previous_x:
                    world_x = danger_column.right - u(12)
                elif player_rect.centerx <= danger_column.centerx:
                    world_x = danger_column.left - u(12) - player_rect.width
                else:
                    world_x = danger_column.right - u(12)
                player_rect = player_hitbox(world_x, world_y)
                continue
        if not boulder_mask_overlaps(player_rect, boulder):
            continue
        surface_y = boulder_surface_y(boulder, player_rect.centerx)
        if boulder["landed"] and previous_rect.bottom <= surface_y + u(2) and player_rect.bottom >= surface_y and vertical_speed >= 0:
            world_y = surface_y - u(90)
            vertical_speed = 0
            is_jumping = False
        elif previous_rect.top >= obstacle.bottom and player_rect.top <= obstacle.bottom and vertical_speed < 0:
            world_y = obstacle.bottom + u(20)
            vertical_speed = 0
        elif world_x > previous_x:
            world_x = obstacle.left - u(12) - player_rect.width
        elif world_x < previous_x:
            world_x = obstacle.right - u(12)
        elif player_rect.centerx <= obstacle.centerx:
            world_x = obstacle.left - u(12) - player_rect.width
        else:
            world_x = obstacle.right - u(12)
        player_rect = player_hitbox(world_x, world_y)
    return max(0, world_x), world_y, vertical_speed, is_jumping


def resolve_player_collision(first_x, first_y, second_x, second_y):
    """Не даёт двум игрокам проталкивать друг друга сквозь тела."""
    first_box = player_hitbox(first_x, first_y)
    second_box = player_hitbox(second_x, second_y)
    if first_box.colliderect(second_box):
        half_width = first_box.width // 2
        if first_box.centerx <= second_box.centerx:
            first_x = second_x - half_width * 2
        else:
            second_x = first_x + half_width * 2
    return max(0, first_x), max(0, second_x)


def damage_boulder_at(mouse_pos, camera_x):
    """Удар киркой по валуну, если игрок стоит рядом."""
    global collapse_stage, collapse_boulders, last_action_text
    if current_zone != "mine" or selected_tool != "pickaxe" or collapse_stage not in ("boulders_falling", "blocked"):
        return False
    world_mouse = (mouse_pos[0] + camera_x, mouse_pos[1])
    for boulder in list(collapse_boulders):
        rect = boulder["rect"]
        if not boulder["landed"] or not boulder_hitbox(boulder).collidepoint(world_mouse):
            continue
        local_x, local_y = world_mouse[0] - rect.x, world_mouse[1] - rect.y
        if not boulder_masks[boulder["texture_index"]].get_at((local_x, local_y)):
            continue
        players = [player_x] + ([player2_x] if player_count == 2 else [])
        if min(abs(px - rect.centerx) for px in players) > u(280):
            return False
        boulder["hits_left"] -= 1
        if boulder["hits_left"] <= 0:
            broken_id = boulder["id"]
            inventory["classic_stone"] += 15
            bonus = None
            eligible = [name for name in prices if name not in ("classic_stone",) and name not in NON_ORE_ITEMS
                        and MOD_MIN_DEPTHS.get(name, 0) <= mine_depth_tier(rect.x)
                        and prices[name] <= 200 + mine_depth_tier(rect.x) ** 2 * 120]
            if eligible and random.random() < 0.35:
                bonus = random.choice(eligible)
                bonus_amount = random.randint(1, 2)
                inventory[bonus] += bonus_amount
            if bonus:
                last_action_text = LANG_PACK[lang]["boulder_bonus"].format(
                    bonus_amount, RESOURCE_NAMES[lang][bonus])
            else:
                last_action_text = LANG_PACK[lang]["boulder_stone"]
            collapse_boulders.remove(boulder)
            unsupported_boulders = []
            for upper in collapse_boulders:
                if upper["support_id"] == broken_id:
                    upper["support_id"] = None
                    upper["support_point"] = None
                    upper["landed"] = False
                    upper["speed"] = 0.0
                    upper["bounces"] = 0
                    upper["target_y"] = floor_y + u(90) - upper["rect"].height
                    unsupported_boulders.append(upper)
            if unsupported_boulders:
                collapse_stage = "boulders_falling"
            if not collapse_boulders:
                collapse_stage = "waiting"
                collapse_small_stones.clear()
        return True
    return False


def refresh_mine_ores(world_x):
    """Обновляет месторождения рядом с шахтёром по таймеру."""
    mineral_deposits.clear()
    generate_ore_chunk(max(0, world_x))

graphics_store_building_rect = pygame.Rect(WIDTH - u(154), u(440), u(90), u(90))


def get_store_panel_rect():
    return pygame.Rect((WIDTH - u(650)) // 2, (HEIGHT - u(460)) // 2, u(650), u(460))


graphics_store_buy_btn_rect = pygame.Rect(
    WIDTH // 2 - u(150), HEIGHT // 2 + u(130), u(300), u(50))


def get_store_item_rects():
    """Области товаров в двух рядах витрины."""
    display = textures["store_display"]
    panel = get_store_panel_rect()
    box_x, box_y = panel.topleft
    display_x = box_x + (u(650) - display.get_width()) // 2
    display_y = box_y + u(80)
    # Координаты первых трёх ячеек на исходной картинке store_display.png.
    x_edges = [0, 228, 435, 600]
    scale_x = display.get_width() / 1145
    row_height = round(display.get_height() * 169 / 362)
    names = ("iron", "gold", "sword", "stone_sword", "iron_sword")
    rects = {}
    for index, name in enumerate(names):
        cell_index = index if index < 3 else index - 3
        left = display_x + round(x_edges[cell_index] * scale_x) + u(2)
        top = display_y + (u(2) if index < 3 else row_height + u(2))
        width = round((x_edges[cell_index + 1] - x_edges[cell_index]) * scale_x) - u(4)
        rects[name] = pygame.Rect(left, top, width, row_height - u(4))
    return rects


def get_hotbar_layout():
    slot_width, slot_height, gap = u(68), u(70), u(4)
    slot_count = 9
    frame_width = slot_width * slot_count + gap * (slot_count - 1) + u(12)
    frame_height = slot_height + u(8)
    frame_x = (WIDTH - frame_width) // 2
    frame_y = HEIGHT - frame_height
    frame_rect = pygame.Rect(frame_x, frame_y, frame_width, frame_height)
    slots = [pygame.Rect(frame_x + u(6) + index * (slot_width + gap),
                         frame_y + u(4), slot_width, slot_height) for index in range(slot_count)]
    return frame_rect, slots


def select_tool(tool):
    global selected_tool, flashlight_on, last_action_text
    if tool == "flashlight" and not flashlight_equipped:
        last_action_text = LANG_PACK[lang]["no_flashlight"]
        return
    if tool == "sword" and not owns_sword():
        last_action_text = LANG_PACK[lang]["need_sword"]
        return
    selected_tool = tool
    if tool != "flashlight":
        flashlight_on = False


def fish_action():
    global fishing_state, fishing_bite_at, last_action_text
    if current_zone != "ocean":
        last_action_text = {"ru": "Рыбачить можно только в океане!", "en": "You can only fish in the ocean!",
                            "es": "¡Solo puedes pescar en el océano!", "zh": "只能在海洋钓鱼！",
                            "ja": "釣りは海でできます！", "fr": "Tu peux pêcher uniquement dans l'océan !",
                            "sr": "Možeš da pecaš samo u okeanu!"}[lang]
    elif selected_tool != "fishing_rod":
        last_action_text = {"ru": "Сначала возьми удочку клавишей 5.", "en": "Equip the fishing rod with 5 first.",
                            "es": "Primero selecciona la caña con 5.", "zh": "先按5拿起鱼竿。", "ja": "先に5で釣り竿を選んでください。",
                            "fr": "Prends d'abord la canne à pêche avec la touche 5.", "sr": "Prvo uzmi štap za pecanje tasterom 5."}[lang]
    elif fishing_state == "idle":
        fishing_state = "casting"
        fishing_bite_at = time.time() + random.uniform(2.0, 5.0)
        last_action_text = {"ru": "Закинул удочку. Жди поклёвку…", "en": "Line cast. Wait for a bite…",
                            "es": "Caña lanzada. Espera la picada…", "zh": "鱼竿已抛出，等待鱼咬钩…",
                            "ja": "投げました。魚がかかるまで待とう…", "fr": "Ligne lancée. Attends une touche…",
                            "sr": "Zabacio si udicu. Sačekaj da riba zagrize…"}[lang]
    elif fishing_state == "bite":
        fishing_state = "idle"
        if random.random() < 0.08:
            inventory["shark_tooth"] += 1
            last_action_text = {"ru": "Редкая находка! Ты выловил зуб акулы!", "en": "Rare find! You caught a shark tooth!",
                                "es": "¡Hallazgo raro! ¡Pescaste un diente de tiburón!", "zh": "稀有发现！你钓到了鲨鱼牙齿！",
                                "ja": "珍しい発見！サメの歯を釣り上げた！", "fr": "Trouvaille rare ! Tu as pêché une dent de requin !",
                                "sr": "Redak ulov! Upecao si zub ajkule!"}[lang]
        else:
            fish_count = random.choices((1, 2), (0.82, 0.18), k=1)[0]
            inventory["fish"] += fish_count
            last_action_text = {"ru": f"Выловлено рыбы: {fish_count}!", "en": f"Fish caught: {fish_count}!",
                                "es": f"¡Peces capturados: {fish_count}!", "zh": f"钓到鱼：{fish_count}！",
                                "ja": f"魚を{fish_count}匹釣った！", "fr": f"Poissons pêchés : {fish_count} !",
                                "sr": f"Ulovljeno ribe: {fish_count}!"}[lang]
    else:
        last_action_text = {"ru": "Пока тихо — подожди поклёвку.", "en": "No bite yet — keep waiting.",
                            "es": "Aún no pica; espera.", "zh": "还没咬钩，再等等。", "ja": "まだです。もう少し待って。",
                            "fr": "Pas encore de touche — attends un peu.", "sr": "Još nema ugriza — sačekaj malo."}[lang]


def draw_hotbar():
    frame_rect, slots = get_hotbar_layout()
    pygame.draw.rect(screen, (25, 27, 32), frame_rect, border_radius=u(5))

    third_tool = "sword" if owns_sword() else "empty"
    third_label = "hotbar_sword" if owns_sword() else "hotbar_empty"
    tool_names = ("pickaxe", "flashlight", third_tool, "melon", "fishing_rod", "block", "empty", "empty", "empty")
    first_slot_label = LANG_PACK[lang]["hotbar_abyss"] if has_abyss_pickaxe else LANG_PACK[lang]["hotbar_pickaxe"]
    labels = (first_slot_label, LANG_PACK[lang]["hotbar_flashlight"],
              LANG_PACK[lang][third_label], LANG_PACK[lang]["hotbar_melon"],
              ("УДОЧКА" if lang == "ru" else "ROD" if lang == "en" else "CAÑA" if lang == "es" else "鱼竿" if lang == "zh" else "釣り竿"),
              LANG_PACK[lang]["hotbar_blocks"], LANG_PACK[lang]["hotbar_empty"],
              LANG_PACK[lang]["hotbar_empty"], LANG_PACK[lang]["hotbar_empty"],
              LANG_PACK[lang]["hotbar_empty"])
    for index, (tool, rect, label_text) in enumerate(zip(tool_names, slots, labels), start=1):
        pygame.draw.rect(screen, (55, 58, 62), rect, border_radius=u(4))
        pygame.draw.rect(screen, (255, 205, 45) if tool == selected_tool else (125, 125, 125),
                         rect, max(1, u(2)), border_radius=u(4))
        number = font_sub.render(str(index), True, (255, 220, 80))
        screen.blit(number, (rect.x + u(8), rect.y + u(5)))

        icon = None
        max_icon_size = (u(36), u(38))
        if tool == "pickaxe":
            if has_abyss_pickaxe:
                icon = textures["abyss_pick"]
            else:
                pickaxe_key = "gold_pick" if has_gold_pickaxe else "iron_pick" if has_iron_pickaxe else "stone_pick"
                icon = textures[pickaxe_key]
        elif tool == "flashlight" and flashlight_equipped:
            icon = textures["flashlight"]
            max_icon_size = (u(45), u(26))
        elif tool == "sword":
            icon = textures[best_sword_texture()]
        elif tool == "melon":
            icon = textures["melon"]
        elif tool == "fishing_rod":
            icon = textures["fishing_rod"]
        elif tool == "block":
            icon = stone_block_texture

        if icon is not None:
            fit = min(max_icon_size[0] / icon.get_width(), max_icon_size[1] / icon.get_height())
            icon_size = (max(1, round(icon.get_width() * fit)), max(1, round(icon.get_height() * fit)))
            icon = pygame.transform.scale(icon, icon_size)
            screen.blit(icon, (rect.centerx - icon.get_width() // 2, rect.y + u(8)))
        if tool == "melon":
            count_text = font_sub.render(str(inventory["melon"]), True, (255, 255, 255))
            screen.blit(count_text, (rect.right - count_text.get_width() - u(5), rect.y + u(5)))
        elif tool == "block":
            count_text = font_sub.render(str(inventory["stone_block"]), True, (255, 255, 255))
            screen.blit(count_text, (rect.right - count_text.get_width() - u(5), rect.y + u(5)))
        label = font_sub.render(label_text, True, (245, 245, 245))
        screen.blit(label, (rect.centerx - label.get_width() // 2, rect.bottom - u(18)))

# Хитбоксы инвентаря
y_offset = 32
sell_buttons = {}
sell_all_buttons = {}
for item in inventory.keys():
    sell_buttons[item] = pygame.Rect(u(895), u(y_offset + 6), u(95), u(22))
    y_offset += 55

def run_menu_graphics():
    draw_studio_background()
    title_text = font_menu.render(LANG_PACK[lang]["title"], True, (255, 255, 255))
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, u(150)))
    for code, rect in LANGUAGE_BUTTON_RECTS.items():
        language_image = textures[LANGUAGE_TEXTURES[code]]
        screen.blit(language_image, rect)
        if code == lang:
            pygame.draw.rect(screen, (255, 210, 70), rect, max(1, u(3)), border_radius=u(5))
    for index, key in enumerate(("controls_p1", "controls_p2")):
        control_text = font_sub.render(LANG_PACK[lang][key], True, (230, 230, 230))
        screen.blit(control_text, (WIDTH // 2 - control_text.get_width() // 2, u(450 + index * 24)))
    mods_text = font_sub.render(LANG_PACK[lang]["mods_loaded"].format(len(MOD_ITEMS)),
                                True, (180, 210, 180))
    screen.blit(mods_text, (WIDTH // 2 - mods_text.get_width() // 2, u(530)))
    pygame.draw.rect(screen, (55, 105, 75), settings_menu_button_rect, border_radius=u(8))
    settings_text = font.render("Настройки / Settings", True, (255, 255, 255))
    screen.blit(settings_text, (settings_menu_button_rect.centerx - settings_text.get_width() // 2,
                                settings_menu_button_rect.centery - settings_text.get_height() // 2))
    screen.blit(textures["exit"], exit_button_rect.topleft)


def run_settings_graphics():
    draw_studio_background()
    labels = {
        "ru": ("НАСТРОЙКИ", "Полноэкранный режим", "Включён" if is_fullscreen else "Выключен",
               "Громкость", "Назад"),
        "en": ("SETTINGS", "Fullscreen mode", "On" if is_fullscreen else "Off", "Volume", "Back"),
        "es": ("AJUSTES", "Pantalla completa", "Activada" if is_fullscreen else "Desactivada", "Volumen", "Volver"),
        "zh": ("设置", "全屏模式", "开启" if is_fullscreen else "关闭", "音量", "返回"),
        "ja": ("設定", "全画面表示", "オン" if is_fullscreen else "オフ", "音量", "戻る")
    }
    title, fullscreen_label, fullscreen_state, volume_label, back_label = labels.get(lang, labels["en"])
    title_image = font_menu.render(title, True, (255, 255, 255))
    screen.blit(title_image, (WIDTH // 2 - title_image.get_width() // 2, u(145)))

    pygame.draw.rect(screen, (55, 70, 82), settings_fullscreen_rect, border_radius=u(8))
    pygame.draw.rect(screen, (255, 210, 70), settings_fullscreen_rect, max(1, u(2)), border_radius=u(8))
    mode_text = font.render(f"{fullscreen_label}: {fullscreen_state}", True, (255, 255, 255))
    screen.blit(mode_text, (settings_fullscreen_rect.centerx - mode_text.get_width() // 2,
                            settings_fullscreen_rect.centery - mode_text.get_height() // 2))

    volume_text = font.render(f"{volume_label}: {round(master_volume * 100)}%", True, (255, 255, 255))
    screen.blit(volume_text, (WIDTH // 2 - volume_text.get_width() // 2, u(330)))
    pygame.draw.rect(screen, (55, 60, 68), settings_volume_track_rect, border_radius=u(8))
    fill_rect = settings_volume_track_rect.copy()
    fill_rect.width = round(fill_rect.width * master_volume)
    if fill_rect.width:
        pygame.draw.rect(screen, (35, 190, 105), fill_rect, border_radius=u(8))
    for rect, sign in ((settings_volume_down_rect, "−"), (settings_volume_up_rect, "+")):
        pygame.draw.rect(screen, (55, 105, 75), rect, border_radius=u(6))
        sign_image = font_menu.render(sign, True, (255, 255, 255))
        screen.blit(sign_image, (rect.centerx - sign_image.get_width() // 2,
                                 rect.centery - sign_image.get_height() // 2))
    sound_note_text = {
        "ru": "Звуки игры пока не добавлены",
        "en": "Game sounds have not been added yet",
        "es": "Aún no se han añadido sonidos",
        "zh": "游戏音效尚未添加",
        "ja": "ゲーム音声はまだありません"
    }.get(lang, "Game sounds have not been added yet")
    sound_note = font_sub.render(sound_note_text, True, (200, 205, 210))
    screen.blit(sound_note, (WIDTH // 2 - sound_note.get_width() // 2, u(435)))

    pygame.draw.rect(screen, (65, 85, 115), settings_back_rect, border_radius=u(8))
    back_image = font.render(back_label, True, (255, 255, 255))
    screen.blit(back_image, (settings_back_rect.centerx - back_image.get_width() // 2,
                             settings_back_rect.centery - back_image.get_height() // 2))
    screen.blit(textures["exit"], exit_button_rect.topleft)


async def show_studio_splash():
    """Короткая заставка студии после загрузки игровых ресурсов."""
    started_at = time.time()
    duration = 1.8
    logo_width, logo_height = u(620), u(349)
    logo = pygame.transform.smoothscale(textures["studio_logo"], (logo_width, logo_height))
    while time.time() - started_at < duration:
        elapsed = time.time() - started_at
        fade = min(1.0, elapsed / 0.45)
        screen.fill((8, 10, 18))
        studio = font_menu.render("BLACK HOLE", True, (255, 232, 205))
        subtitle = font_sub.render("GAME STUDIO", True, (210, 185, 160))
        screen.blit(studio, (WIDTH // 2 - studio.get_width() // 2, u(28)))
        screen.blit(subtitle, (WIDTH // 2 - subtitle.get_width() // 2, u(68)))
        logo.set_alpha(round(255 * fade))
        screen.blit(logo, (WIDTH // 2 - logo_width // 2, u(116)))
        pygame.draw.line(screen, (214, 139, 93),
                         (WIDTH // 2 - u(170), u(484)),
                         (WIDTH // 2 + u(170), u(484)), max(1, u(2)))
        game_name = font.render("STICKMAN IN MINE", True, (245, 225, 205))
        screen.blit(game_name, (WIDTH // 2 - game_name.get_width() // 2, u(502)))
        present_frame()
        pygame.event.pump()
        clock.tick(60)
        await asyncio.sleep(0)


def run_player_select_graphics():
    screen.fill((40, 45, 50))
    title = font_menu.render(LANG_PACK[lang]["select_players"], True, (255, 255, 255))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, u(150)))

    one_icon = textures["one_player"]
    screen.blit(one_icon, (one_player_button_rect.centerx - one_icon.get_width() // 2,
                           one_player_button_rect.y))
    if "two_player" in textures:
        two_icon = textures["two_player"]
        screen.blit(two_icon, (two_player_button_rect.centerx - two_icon.get_width() // 2,
                               two_player_button_rect.y))
    else:
        # Пока второй рисунок не добавлен, показываем двух Джерри в кнопке режима на двоих.
        pygame.draw.ellipse(screen, (200, 35, 45), two_player_button_rect)
        pygame.draw.ellipse(screen, (20, 20, 20), two_player_button_rect, max(1, u(3)))
        small_size = (u(65), u(100))
        small_jerry = pygame.transform.scale(textures["jerry_idle"], small_size)
        screen.blit(small_jerry, (two_player_button_rect.x + u(12), two_player_button_rect.y + u(34)))
        screen.blit(small_jerry, (two_player_button_rect.right - u(77), two_player_button_rect.y + u(34)))

    for rect, label_key in ((one_player_button_rect, "one_player_label"),
                            (two_player_button_rect, "two_player_label")):
        label = font.render(LANG_PACK[lang][label_key], True, (255, 220, 80))
        screen.blit(label, (rect.centerx - label.get_width() // 2, u(420)))
    control1 = font_sub.render(LANG_PACK[lang]["controls_p1"], True, (230, 230, 230))
    control2 = font_sub.render(NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[0] + " / " +
                               NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[1], True, (230, 230, 230))
    flashlight_hint = font_sub.render(LANG_PACK[lang]["flashlight_hint"], True, (230, 230, 230))
    screen.blit(control1, (one_player_button_rect.centerx - control1.get_width() // 2, u(455)))
    screen.blit(control2, (two_player_button_rect.centerx - control2.get_width() // 2, u(455)))
    screen.blit(flashlight_hint, (WIDTH // 2 - flashlight_hint.get_width() // 2, u(490)))
    screen.blit(textures["exit"], exit_button_rect.topleft)


def run_world_select_graphics():
    global world_row_buttons
    screen.fill((34, 39, 46))
    title = font_menu.render("МИРЫ" if lang == "ru" else "WORLDS", True, (255, 255, 255))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, u(90)))
    prompt_text = "Имя нового мира:" if lang == "ru" else "New world name:"
    prompt = font.render(prompt_text, True, (235, 235, 235))
    screen.blit(prompt, (WIDTH // 2 - u(330), u(185)))
    input_rect = world_name_input_rect
    pygame.draw.rect(screen, (245, 245, 245), input_rect, border_radius=u(5))
    pygame.draw.rect(screen, (245, 200, 60), input_rect, max(1, u(2)), border_radius=u(5))
    shown_name = world_name_input + ("|" if int(time.time() * 2) % 2 else "")
    name_surface = font.render(shown_name or ("Напиши название" if lang == "ru" else "Type a name"),
                               True, (35, 40, 45) if shown_name else (120, 120, 120))
    screen.blit(name_surface, (input_rect.x + u(12), input_rect.centery - name_surface.get_height() // 2))
    create_rect = world_create_button_rect
    pygame.draw.rect(screen, (40, 145, 75), create_rect, border_radius=u(5))
    create_label = font.render("Создать" if lang == "ru" else "Create", True, (255, 255, 255))
    screen.blit(create_label, (create_rect.centerx - create_label.get_width() // 2,
                               create_rect.centery - create_label.get_height() // 2))

    worlds = list_available_worlds()
    world_row_buttons = []
    visible = worlds[world_scroll_offset:world_scroll_offset + 6]
    for index, world in enumerate(visible):
        rect = pygame.Rect(WIDTH // 2 - u(330), u(300 + index * 62), u(660), u(52))
        pygame.draw.rect(screen, (65, 73, 84), rect, border_radius=u(5))
        label = font.render(world["name"], True, (255, 220, 100))
        screen.blit(label, (rect.x + u(16), rect.centery - label.get_height() // 2))
        world_row_buttons.append((world["id"], rect))
    if not worlds:
        empty = font.render("Создай первый мир" if lang == "ru" else "Create your first world",
                            True, (210, 215, 220))
        screen.blit(empty, (WIDTH // 2 - empty.get_width() // 2, u(320)))
    if len(worlds) > 6:
        scroll_hint = font_sub.render("Колесо мыши — листать миры" if lang == "ru" else "Mouse wheel — scroll worlds",
                                      True, (210, 215, 220))
        screen.blit(scroll_hint, (WIDTH // 2 - scroll_hint.get_width() // 2, u(690)))
    if world_notice:
        notice = font_sub.render(world_notice, True, (255, 150, 120))
        screen.blit(notice, (WIDTH // 2 - notice.get_width() // 2, u(710)))
    close_hint = font_sub.render("Esc — назад" if lang == "ru" else "Esc — back", True, (190, 195, 200))
    screen.blit(close_hint, (WIDTH // 2 - close_hint.get_width() // 2, HEIGHT - u(35)))
    screen.blit(textures["exit"], exit_button_rect.topleft)


def run_network_select_graphics():
    screen.fill((34, 39, 46))
    texts = NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])
    vpn_active = NetPlay.vpn_is_active()
    title = font_menu.render(texts[0] + " / " + texts[1], True, (255, 255, 255))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, u(160)))
    for rect, label in ((network_host_button_rect, texts[0]), (network_join_button_rect, texts[1])):
        pygame.draw.rect(screen, (35, 145, 75), rect, border_radius=u(9))
        pygame.draw.rect(screen, (15, 25, 20), rect, max(1, u(3)), border_radius=u(9))
        rendered = font.render(label, True, (255, 255, 255))
        screen.blit(rendered, (rect.centerx - rendered.get_width() // 2,
                               rect.centery - rendered.get_height() // 2))
    fields = ((network_address_rect, network_join_address, texts[2], "address"),
              (network_username_rect, network_username, texts[13], "username"),
              (network_password_rect, "*" * len(network_password), texts[14], "password"))
    for rect, value, placeholder, focus_name in fields:
        pygame.draw.rect(screen, (235, 238, 242), rect, border_radius=u(6))
        border_color = (255, 210, 70) if network_input_focus == focus_name else (45, 55, 65)
        pygame.draw.rect(screen, border_color, rect, max(1, u(2)), border_radius=u(6))
        rendered = font.render(value or placeholder, True, (25, 30, 35) if value else (110, 115, 120))
        screen.blit(rendered, (rect.x + u(12), rect.centery - rendered.get_height() // 2))
    hint = font_sub.render(texts[3], True, (220, 225, 230))
    screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, network_password_rect.bottom + u(5)))
    pygame.draw.rect(screen, (65, 95, 145), network_dedicated_button_rect, border_radius=u(8))
    pygame.draw.rect(screen, (20, 30, 45), network_dedicated_button_rect, max(1, u(3)), border_radius=u(8))
    dedicated_text = font.render(texts[10], True, (255, 255, 255))
    screen.blit(dedicated_text, (network_dedicated_button_rect.centerx - dedicated_text.get_width() // 2,
                                 network_dedicated_button_rect.centery - dedicated_text.get_height() // 2))
    if vpn_active:
        warning_text = font_sub.render(texts[15], True, (255, 185, 95))
        screen.blit(warning_text, (WIDTH // 2 - warning_text.get_width() // 2,
                                   network_dedicated_button_rect.bottom + u(5)))
    elif network_error:
        error_text = font_sub.render(network_error, True, (255, 135, 110))
        screen.blit(error_text, (WIDTH // 2 - error_text.get_width() // 2, network_dedicated_button_rect.bottom + u(5)))
    if network_notice and not vpn_active:
        notice_text = font_sub.render(network_notice, True, (140, 240, 170))
        screen.blit(notice_text, (WIDTH // 2 - notice_text.get_width() // 2, network_dedicated_button_rect.bottom + u(24)))
    screen.blit(textures["exit"], exit_button_rect.topleft)

def run_game_logic_and_graphics():
    global player_x, player_y, player_is_jumping, y_velocity, anim_counter, current_jerry_sprite, player_facing_right, gromki, last_income_time, last_action_text, current_graphics_store_open, has_iron_pickaxe, has_gold_pickaxe, has_abyss_pickaxe, next_ore_chunk_x, last_mine_refresh_time, next_dandelion_spawn_time, camera_x, mine_experience, abyss_black_hole, surface_camera_y
    global player2_x, player2_y, player2_is_jumping, player2_y_velocity, player2_anim_counter, player2_jerry_sprite, player2_facing_right
    global collapse_next_trigger_x
    global fishing_state, fishing_bite_at
    if current_zone == "ocean" and fishing_state == "casting" and time.time() >= fishing_bite_at:
        fishing_state = "bite"
        last_action_text = {"ru": "Клюёт! Нажми R, чтобы вытащить улов!",
                            "en": "A bite! Press R to reel in!", "es": "¡Pica! Pulsa R para recogerlo!",
                            "zh": "鱼咬钩了！按 R 收线！", "ja": "魚がかかった！Rで釣り上げよう！",
                            "fr": "Ça mord ! Appuie sur R pour remonter !", "sr": "Riba je zagrizla! Pritisni R da je izvučeš!"}[lang]
    maybe_activate_abyss_secret()
    if abyss_black_hole is not None and time.time() - abyss_black_hole["started_at"] >= abyss_black_hole["duration"]:
        abyss_black_hole = None
    resource_multiplier = 5 if has_abyss_pickaxe else 3 if has_gold_pickaxe else 2 if has_iron_pickaxe else 1
    
    if inventory["kyawthuite"] > 0 and time.time() - last_income_time >= 40:
        gromki += 10000 * inventory["kyawthuite"]
        last_income_time = time.time()

    keys = pygame.key.get_pressed()
    mouse_held = pygame.mouse.get_pressed()[0]
    mouse_x, mouse_y = to_game_position(pygame.mouse.get_pos())
    touch_left = IS_WEB and mouse_held and touch_left_rect.collidepoint((mouse_x, mouse_y))
    touch_right = IS_WEB and mouse_held and touch_right_rect.collidepoint((mouse_x, mouse_y))
    previous_player_x, previous_player2_x = player_x, player2_x
    previous_player_y, previous_player2_y = player_y, player2_y
    player1_moving = False
    player2_moving = False
    movement_speed = round((player_speed + (u(3) if time.time() < melon_speed_until else 0)) * physics_step)
    effect_now = time.time()
    player1_speed = (0 if effect_now < player_frozen_until[0] else
                     max(1, round(movement_speed * 0.35)) if effect_now < player_slowed_until[0]
                     else movement_speed)
    player2_speed = (0 if effect_now < player_frozen_until[1] else
                     max(1, round(movement_speed * 0.35)) if effect_now < player_slowed_until[1]
                     else movement_speed)
    if netplay.role == "server":
        player1_left = network_remote_keys[0]["left"]
        player1_right = network_remote_keys[0]["right"]
    elif netplay.role == "client":
        player1_left = netplay.player_index == 0 and keys[pygame.K_a]
        player1_right = netplay.player_index == 0 and keys[pygame.K_d]
    else:
        player1_left = keys[pygame.K_a] or touch_left
        player1_right = keys[pygame.K_d] or touch_right
    if helper_open:
        player1_left = player1_right = False
    if player1_left:
        player_x -= player1_speed; player1_moving = player1_speed > 0
        player_facing_right = False
        if player_x < 0: player_x = 0
    if player1_right:
        player_x += player1_speed; player1_moving = player1_speed > 0
        player_facing_right = True

    if player_count == 2:
        if netplay.role == "server":
            move_left, move_right = network_remote_keys[1]["left"], network_remote_keys[1]["right"]
        elif netplay.role == "host":
            move_left, move_right = network_remote_keys[1]["left"], network_remote_keys[1]["right"]
        elif netplay.role == "client":
            move_left = netplay.player_index == 1 and keys[pygame.K_a]
            move_right = netplay.player_index == 1 and keys[pygame.K_d]
        else:
            move_left, move_right = keys[pygame.K_LEFT], keys[pygame.K_RIGHT]
        if helper_open:
            move_left = move_right = False
        if move_left:
            player2_x -= player2_speed; player2_moving = player2_speed > 0
            player2_facing_right = False
            if player2_x < 0: player2_x = 0
        if move_right:
            player2_x += player2_speed; player2_moving = player2_speed > 0
            player2_facing_right = True

    if current_zone == "surface":
        player_x = resolve_surface_block_side(player_x, player_y, previous_player_x)
        if player_count == 2:
            player2_x = resolve_surface_block_side(player2_x, player2_y, previous_player2_x)

    if player_count == 2:
        max_player_gap = WIDTH - u(200)
        player2_x = max(player_x - max_player_gap, min(player2_x, player_x + max_player_gap))
        player_x = max(player2_x - max_player_gap, min(player_x, player2_x + max_player_gap))

    if player1_moving:
        anim_counter += 1
        current_jerry_sprite = "jerry_left" if (anim_counter // 8) % 2 == 0 else "jerry_right"
    else:
        anim_counter = 0
        current_jerry_sprite = "jerry_idle"

    if player_count == 2 and player2_moving:
        player2_anim_counter += 1
        player2_jerry_sprite = "jerry_left" if (player2_anim_counter // 8) % 2 == 0 else "jerry_right"
    else:
        player2_anim_counter = 0
        player2_jerry_sprite = "jerry_idle"

    camera_target_x = (player_x + player2_x) // 2 if player_count == 2 else player_x
    camera_x = max(0, camera_target_x - WIDTH // 2)
    if current_zone == "surface":
        ensure_surface_chunks(camera_x)
    furthest_player_x = max(player_x, player2_x) if player_count == 2 else player_x
    while current_zone == "mine" and furthest_player_x + WIDTH // 2 >= next_ore_chunk_x:
        generate_ore_chunk(next_ore_chunk_x)
        next_ore_chunk_x += WIDTH
    now = time.time()
    process_pending_sword_attacks(now)
    if current_zone == "surface":
        update_surface_pigs(camera_x, now)
        update_surface_parrots(camera_x, now)
    if now >= next_dandelion_spawn_time:
        if current_zone == "mine":
            spawn_count = random.randint(1, 15)
            spawn_start = max(0, camera_x - WIDTH // 2)
            spawn_span = WIDTH * 2
            for index in range(spawn_count):
                # Каждое растение получает свой участок карты, поэтому они не появляются кучей.
                fraction = (index + random.random()) / spawn_count
                spawn_dandelion(spawn_start + round(spawn_span * fraction))
        next_dandelion_spawn_time = now + 60
    if current_zone == "mine" and now - last_mine_refresh_time >= MINE_REFRESH_SECONDS:
        refresh_mine_ores(camera_x)
        last_mine_refresh_time = now
        last_action_text = LANG_PACK[lang]["refresh"]

    if current_zone == "mine" and not player_is_jumping and player_y < floor_y and not supported_by_boulder(player_x, player_y):
        player_is_jumping = True
        y_velocity = 0
    if player_count == 2 and current_zone == "mine" and not player2_is_jumping and player2_y < floor_y and not supported_by_boulder(player2_x, player2_y):
        player2_is_jumping = True
        player2_y_velocity = 0
    if (current_zone == "surface" and not player_is_jumping and player_y < floor_y - u(4)
            and not surface_block_supports_player(player_x, player_y)):
        player_is_jumping = True
        y_velocity = 0
    if (current_zone == "surface" and player_count == 2 and not player2_is_jumping
            and player2_y < floor_y - u(4)
            and not surface_block_supports_player(player2_x, player2_y)):
        player2_is_jumping = True
        player2_y_velocity = 0

    if effect_now >= player_frozen_until[0]:
        if not player_is_jumping and not helper_open:
            jump1_pressed = (network_remote_keys[0]["jump"] if netplay.role == "server" else
                             netplay.player_index == 0 and keys[pygame.K_SPACE] if netplay.role == "client" else
                             keys[pygame.K_SPACE] or touch_jump_requested)
            if jump1_pressed:
                player_is_jumping = True; y_velocity = -jump_velocity
        else:
            previous_fall_y = player_y
            player_y += round(y_velocity * physics_step); y_velocity += gravity * physics_step
            block_landing_y = (surface_block_landing_y(player_x, previous_fall_y, player_y)
                               if current_zone == "surface" else None)
            if block_landing_y is not None and y_velocity > 0:
                player_y = block_landing_y; player_is_jumping = False; y_velocity = 0
            elif current_zone == "surface" and y_velocity < 0:
                block_ceiling_y = surface_block_ceiling_y(player_x, previous_fall_y, player_y)
                if block_ceiling_y is not None:
                    player_y = block_ceiling_y; y_velocity = 0
            elif player_y >= floor_y:
                player_y = floor_y; player_is_jumping = False; y_velocity = 0

    p2_jump_pressed = (network_remote_keys[1]["jump"] if netplay.role in ("host", "server") else
                       netplay.player_index == 1 and keys[pygame.K_SPACE] if netplay.role == "client" else
                       keys[pygame.K_UP])
    if player_count == 2 and effect_now >= player_frozen_until[1]:
        if not player2_is_jumping and not helper_open:
            if p2_jump_pressed: player2_is_jumping = True; player2_y_velocity = -jump_velocity
        else:
            previous_fall_y = player2_y
            player2_y += round(player2_y_velocity * physics_step); player2_y_velocity += gravity * physics_step
            block_landing_y = (surface_block_landing_y(player2_x, previous_fall_y, player2_y)
                               if current_zone == "surface" else None)
            if block_landing_y is not None and player2_y_velocity > 0:
                player2_y = block_landing_y; player2_is_jumping = False; player2_y_velocity = 0
            elif current_zone == "surface" and player2_y_velocity < 0:
                block_ceiling_y = surface_block_ceiling_y(player2_x, previous_fall_y, player2_y)
                if block_ceiling_y is not None:
                    player2_y = block_ceiling_y; player2_y_velocity = 0
            elif player2_y >= floor_y:
                player2_y = floor_y; player2_is_jumping = False; player2_y_velocity = 0

    now = time.time()
    furthest_player_x = max(player_x, player2_x) if player_count == 2 else player_x
    moving_right = (player1_moving and player_facing_right) or (player_count == 2 and player2_moving and player2_facing_right)
    if current_zone == "mine":
        if moving_right and collapse_stage == "waiting" and furthest_player_x >= collapse_next_trigger_x:
            if random.random() < 0.7:
                start_mine_collapse(min(player_x, player2_x) if player_count == 2 else player_x)
            collapse_next_trigger_x = furthest_player_x + random.randint(*COLLAPSE_INTERVAL)
        if collapse_stage in ("pebbles", "boulders_falling", "blocked"):
            update_mine_collapse(now)
        player_x, player_y, y_velocity, player_is_jumping = resolve_boulder_collision(
            player_x, player_y, previous_player_x, previous_player_y, y_velocity, player_is_jumping)
        if player_count == 2:
            player2_x, player2_y, player2_y_velocity, player2_is_jumping = resolve_boulder_collision(
                player2_x, player2_y, previous_player2_x, previous_player2_y,
                player2_y_velocity, player2_is_jumping)
            player_x, player2_x = resolve_player_collision(player_x, player_y, player2_x, player2_y)
            player_x, player_y, y_velocity, player_is_jumping = resolve_boulder_collision(
                player_x, player_y, previous_player_x, previous_player_y, y_velocity, player_is_jumping)
            player2_x, player2_y, player2_y_velocity, player2_is_jumping = resolve_boulder_collision(
                player2_x, player2_y, previous_player2_x, previous_player2_y,
                player2_y_velocity, player2_is_jumping)
        update_dandelions(now)
        update_spider_encounters(now)
        camera_target_x = (player_x + player2_x) // 2 if player_count == 2 else player_x
        camera_x = max(0, camera_target_x - WIDTH // 2)

    if current_zone == "surface":
        highest_player_y = min(player_y, player2_y) if player_count == 2 else player_y
        surface_camera_y = min(0, highest_player_y - (floor_y - u(170)))
    else:
        surface_camera_y = 0
    vertical_draw_offset = surface_camera_y if current_zone == "surface" else 0

    walking_on_mine_stone = current_zone == "mine" and (
        player1_moving and not player_is_jumping or
        player_count == 2 and player2_moving and not player2_is_jumping
    )
    update_mine_footsteps(walking_on_mine_stone)

    player_rect = player_hitbox(player_x, player_y)
    player2_rect = player_hitbox(player2_x, player2_y)

    if current_zone == "surface":
        sky = textures["sky"]
        first_sky_x = -(int(camera_x) % sky.get_width())
        for sky_x in range(first_sky_x, WIDTH, sky.get_width()):
            screen.blit(sky, (sky_x, 0))
        sky_height = textures["sky"].get_height()
        pygame.draw.rect(screen, textures["sky"].get_at((0, 0)), (0, sky_height, WIDTH, HEIGHT - sky_height))
        # Верхняя зона: текстура занимает всю ширину и сохраняет исходные пропорции.
        ground_screen_y = floor_y + u(90) - surface_camera_y
        if ground_screen_y < HEIGHT:
            pygame.draw.rect(screen, (178, 116, 82),
                             (0, ground_screen_y, WIDTH, HEIGHT - ground_screen_y))
        grass_y = floor_y + u(90) - round(WIDTH * 40 / 1258)
        grass_y -= surface_camera_y
        grass = textures["grass_plate"]
        first_grass_x = -(int(camera_x) % grass.get_width())
        for grass_x in range(first_grass_x, WIDTH, grass.get_width()):
            screen.blit(grass, (grass_x, grass_y))
        for block in world_blocks:
            block_rect = world_block_rect(block).move(-camera_x, -surface_camera_y)
            if block_rect.right >= 0 and block_rect.left <= WIDTH and block_rect.bottom >= 0 and block_rect.top <= HEIGHT:
                screen.blit(stone_block_texture, block_rect)
        screen.blit(textures["entrance_mine"],
                    (mine_entrance_rect.x - camera_x, mine_entrance_rect.y - surface_camera_y))
        ocean_access_screen_x = OCEAN_ACCESS_X - camera_x
        screen.blit(textures["ocean_access"], (ocean_access_screen_x - textures["ocean_access"].get_width() // 2,
                                                ocean_access_rect.y - surface_camera_y))
        if abs(player_x - OCEAN_ACCESS_X) <= u(250):
            ocean_hint = font.render(LANG_PACK[lang]["ocean_hint"], True, (255, 255, 255))
            screen.blit(ocean_hint, (ocean_access_screen_x - ocean_hint.get_width() // 2,
                                     ocean_access_rect.y - surface_camera_y - ocean_hint.get_height() - u(4)))
        for obj in visible_surface_objects(camera_x):
            if obj["active"]:
                draw_surface_object(obj, camera_x)
                if obj["kind"] == "pig" and obj["hp"] < 50:
                    hp_label = font_sub.render(f"{obj['hp']} HP", True, (255, 255, 255))
                    rect = surface_object_rect(obj).move(-camera_x, -surface_camera_y)
                    screen.blit(hp_label, (rect.centerx - hp_label.get_width() // 2, rect.y - u(18)))
    elif current_zone == "mine":
        # В шахте вместо травы каменный пол и тёмные стены.
        screen.blit(textures["sky_mine"], (0, 0))
        sky_height = textures["sky_mine"].get_height()
        pygame.draw.rect(screen, textures["sky_mine"].get_at((0, 0)), (0, sky_height, WIDTH, HEIGHT - sky_height))
        pygame.draw.rect(screen, (65, 60, 58), (0, floor_y + u(90), WIDTH, HEIGHT - floor_y - u(90)))
        plate = textures["mine_plate"]
        # Каменная кромка находится примерно на 288-й строке исходного рисунка.
        # Ставим её на уровень пола, чтобы Джерри стоял на mine_plate, как на траве.
        mine_floor_edge = round(plate.get_height() * 288 / 504)
        plate_y = floor_y + u(90) - mine_floor_edge
        first_plate_x = -(int(camera_x) % plate.get_width())
        for bx in range(first_plate_x, WIDTH, plate.get_width()):
            screen.blit(plate, (bx, plate_y))
        screen.blit(textures["entrance_mine"], (mine_entrance_rect.x - camera_x, mine_entrance_rect.y))
    else:
        screen.fill((135, 206, 235))
        waterline_y = floor_y + u(90)
        pygame.draw.rect(screen, (0, 130, 205),
                         (0, waterline_y, WIDTH, max(0, HEIGHT - waterline_y)))
        water = textures["ocean_water"]
        first_water_x = -(int(camera_x) % water.get_width())
        for water_x in range(first_water_x, WIDTH, water.get_width()):
            screen.blit(water, (water_x, waterline_y - u(55)))
        player_mid_x = ((player_x + player2_x) // 2 if player_count == 2 else player_x) - camera_x
        boat_rect = textures["ocean_boat"].get_rect(
            midbottom=(player_mid_x, waterline_y + u(105)))
        screen.blit(textures["ocean_boat"], boat_rect)
        if selected_tool == "fishing_rod":
            player_hand_screen_x = player_x - camera_x
            hand_x = player_hand_screen_x + (u(35) if player_facing_right else -u(8))
            hand_y = player_y + u(30)
            tip_x = hand_x + (u(80) if player_facing_right else -u(80))
            tip_y = hand_y - u(70)
            pygame.draw.line(screen, (104, 66, 38), (hand_x, hand_y), (tip_x, tip_y), u(5))
            line_end_x = tip_x + (u(40) if player_facing_right else -u(40))
            line_end_y = waterline_y + u(5)
            pygame.draw.line(screen, (235, 225, 200), (tip_x, tip_y),
                             (line_end_x, line_end_y), max(1, u(2)))
            pygame.draw.circle(screen, (245, 65, 65) if fishing_state == "bite" else (245, 235, 225),
                               (line_end_x, line_end_y), u(7))
            if fishing_state == "bite":
                pygame.draw.circle(screen, (255, 220, 40), (line_end_x, line_end_y), u(12), max(1, u(2)))
        ocean_hints = {
            "ru": "E — берег | 5 — взять удочку | R — забросить / вытащить",
            "en": "E — shore | 5 — equip rod | R — cast / reel in",
            "es": "E — costa | 5 — caña | R — lanzar / recoger",
            "zh": "E — 海岸 | 5 — 鱼竿 | R — 抛竿 / 收线",
            "ja": "E — 岸 | 5 — 釣り竿 | R — 投げる / 釣り上げる"
        }
        ocean_hint = font.render(ocean_hints[lang], True, (255, 255, 255))
        screen.blit(ocean_hint, (WIDTH // 2 - ocean_hint.get_width() // 2, u(18)))
    if current_zone == "mine":
        for rock in collapse_small_stones:
            screen.blit(small_rock_texture, (rock["rect"].x - camera_x, rock["rect"].y))
        for boulder in collapse_boulders:
            rect = boulder["rect"]
            screen.blit(boulder_textures[boulder["texture_index"]], (rect.x - camera_x, rect.y))
            if boulder["landed"]:
                crack_y = rect.bottom + u(4)
                pygame.draw.line(screen, (28, 25, 24), (rect.centerx - u(28) - camera_x, crack_y),
                                 (rect.centerx - u(7) - camera_x, crack_y + u(10)), max(1, u(3)))
                pygame.draw.line(screen, (28, 25, 24), (rect.centerx - u(7) - camera_x, crack_y + u(10)),
                                 (rect.centerx + u(12) - camera_x, crack_y + u(3)), max(1, u(3)))
                hp = font_sub.render(str(boulder["hits_left"]), True, (255, 255, 255))
                screen.blit(hp, (rect.centerx - camera_x - hp.get_width() // 2, rect.y + u(8)))
        for dandelion in dandelions:
            if not dandelion["active"]:
                continue
            floor_surface_y = floor_y + u(90)
            flower_screen_x = dandelion["x"] - camera_x
            if dandelion["phase"] in ("digging", "underground"):
                tunnel = pygame.Rect(flower_screen_x - u(20), floor_surface_y - u(8), u(90), u(18))
                pygame.draw.ellipse(screen, (38, 30, 28), tunnel)
                pygame.draw.circle(screen, (100, 88, 78), (tunnel.x + u(12), tunnel.y), u(5))
                pygame.draw.circle(screen, (100, 88, 78), (tunnel.right - u(8), tunnel.y - u(3)), u(4))
            else:
                rise = 0
                if dandelion["phase"] == "emerging":
                    progress = min(1.0, dandelion["timer"] / 0.7)
                    rise = round((1 - progress) * u(80))
                flower_rect = dandelion_sprite_rect(dandelion, rise, camera_x)
                flower_sprite = dandelion_texture if dandelion["facing_right"] else pygame.transform.flip(dandelion_texture, True, False)
                screen.blit(flower_sprite, flower_rect)
                hp_label = font_sub.render(f"{dandelion['hp']} HP", True, (255, 255, 255))
                screen.blit(hp_label, (flower_rect.centerx - hp_label.get_width() // 2, flower_rect.y - u(20)))
        draw_spiders_and_webs(camera_x)
        for deposit in mineral_deposits:
            if deposit["active"]:
                deposit_rect = deposit["rect"].move(-camera_x, 0)
                screen.blit(textures["ore_deposit"], deposit_rect)
                hp_bar = pygame.Rect(deposit_rect.x + u(35), deposit_rect.y + u(8),
                                     deposit_rect.width - u(70), u(9))
                pygame.draw.rect(screen, (35, 30, 28), hp_bar, border_radius=u(3))
                hp_fill = hp_bar.copy()
                hp_fill.width = round(hp_bar.width * deposit["durability"] / DEPOSIT_MAX_DURABILITY)
                if hp_fill.width > 0:
                    hp_color = (55, 210, 80) if deposit["durability"] > 15 else (230, 180, 45)
                    pygame.draw.rect(screen, hp_color, hp_fill, border_radius=u(3))
                touching_player = 0 if player_rect.colliderect(ore_hitbox(deposit["rect"])) else (
                    1 if player_count == 2 and player2_rect.colliderect(ore_hitbox(deposit["rect"])) else None)
                hit_time = time.time()
                if (selected_tool == "pickaxe" and touching_player is not None and
                        hit_time - deposit["last_hit"] >= DEPOSIT_HIT_INTERVAL):
                    if has_abyss_pickaxe:
                        damage = 15
                    elif has_gold_pickaxe:
                        damage = random.randint(6, 10) if random.random() < 0.5 else 4
                    elif has_iron_pickaxe:
                        damage = 5
                    else:
                        damage = 3
                    deposit["last_hit"] = hit_time
                    deposit["durability"] = max(0, deposit["durability"] - damage)
                    play_mine_break_sound()
                    mining_animation_started[touching_player] = hit_time
                    if deposit["durability"] > 0:
                        last_action_text = LANG_PACK[lang]["deposit_hit"].format(
                            damage, deposit["durability"])
                    else:
                        deposit["active"] = False
                        finish_mine_break_sound()
                        inventory["classic_stone"] += 5
                        inventory["stone_block"] += 1
                        mine_experience += 10
                        reward_suffix = {"ru": ", +1 каменный блок", "en": ", +1 stone block",
                                         "es": ", +1 bloque de piedra", "zh": "，+1石块",
                                         "ja": "、石ブロック+1", "fr": ", +1 bloc de pierre",
                                         "sr": ", +1 kameni blok"}[lang]
                        if random.random() < 0.65:
                            mineral_name = choose_ore_for_depth(deposit["rect"].x)
                            mineral_amount = random.randint(1, 3) * resource_multiplier
                            inventory[mineral_name] += mineral_amount
                            reward_suffix += f", +{mineral_amount} {RESOURCE_NAMES[lang][mineral_name]}"
                        last_action_text = LANG_PACK[lang]["deposit_mined"].format(reward_suffix)
                        save_progress()

    # Разворачиваем весь спрайт вместе с ногами, чтобы шаг совпадал с направлением движения.
    mining_frame_keys = ("extract_one", "extract_two", "extract_three", "extract_four")
    extract_hand_points = ((0.73, 0.45), (0.78, 0.13), (0.79, 0.25), (0.77, 0.56))
    mining_now = time.time()
    player1_mining_elapsed = mining_now - mining_animation_started[0]
    player1_sprite_key = (mining_frame_keys[min(3, int(player1_mining_elapsed / 0.12))]
                          if 0 <= player1_mining_elapsed < 0.48 else current_jerry_sprite)
    jerry_sprite = player_render_textures[player1_sprite_key]
    if not player_facing_right:
        jerry_sprite = pygame.transform.flip(jerry_sprite, True, False)
    player1_screen_x = player_x - camera_x
    screen.blit(jerry_sprite, (player1_screen_x + u(12), player_y - u(22) - vertical_draw_offset))
    p1_name = font_sub.render(player_names[0], True, (255, 255, 255))
    p1_name_pos = (player1_screen_x + u(36) - p1_name.get_width() // 2,
                   player_y - u(67) - vertical_draw_offset)
    screen.blit(p1_name, (p1_name_pos[0] + u(1), p1_name_pos[1] + u(1)))
    screen.blit(p1_name, p1_name_pos)
    player1_badge = pygame.Rect(player1_screen_x + u(25), player_y - u(42) - vertical_draw_offset, u(22), u(22))
    pygame.draw.ellipse(screen, (255, 205, 45), player1_badge)
    pygame.draw.ellipse(screen, (30, 30, 30), player1_badge, max(1, u(2)))
    p1_text = font_sub.render("1", True, (30, 30, 30))
    screen.blit(p1_text, (player1_badge.centerx - p1_text.get_width() // 2,
                          player1_badge.centery - p1_text.get_height() // 2))

    if player_count == 2:
        player2_mining_elapsed = mining_now - mining_animation_started[1]
        player2_sprite_key = (mining_frame_keys[min(3, int(player2_mining_elapsed / 0.12))]
                              if 0 <= player2_mining_elapsed < 0.48 else player2_jerry_sprite)
        second_sprite = player_render_textures[player2_sprite_key]
        if not player2_facing_right:
            second_sprite = pygame.transform.flip(second_sprite, True, False)
        player2_screen_x = player2_x - camera_x
        screen.blit(second_sprite, (player2_screen_x + u(12), player2_y - u(22) - vertical_draw_offset))
        p2_name = font_sub.render(player_names[1], True, (255, 255, 255))
        p2_name_pos = (player2_screen_x + u(36) - p2_name.get_width() // 2,
                       player2_y - u(67) - vertical_draw_offset)
        screen.blit(p2_name, (p2_name_pos[0] + u(1), p2_name_pos[1] + u(1)))
        screen.blit(p2_name, p2_name_pos)
        player2_badge = pygame.Rect(player2_screen_x + u(25), player2_y - u(42) - vertical_draw_offset, u(22), u(22))
        pygame.draw.ellipse(screen, (75, 200, 255), player2_badge)
        pygame.draw.ellipse(screen, (30, 30, 30), player2_badge, max(1, u(2)))
        p2_text = font_sub.render("2", True, (30, 30, 30))
        screen.blit(p2_text, (player2_badge.centerx - p2_text.get_width() // 2,
                              player2_badge.centery - p2_text.get_height() // 2))

    for effect_index, (effect_x, effect_y) in enumerate(
            ((player_x, player_y), (player2_x, player2_y))):
        if effect_index >= player_count or time.time() >= player_frozen_until[effect_index]:
            continue
        frozen_box = player_hitbox(effect_x, effect_y).move(-camera_x, -vertical_draw_offset)
        frozen_web = pygame.transform.scale(textures["web"], frozen_box.size)
        frozen_web.set_alpha(190)
        screen.blit(frozen_web, frozen_box)
    draw_pet_effects(camera_x, vertical_draw_offset)

    if current_zone == "mine" and selected_tool == "pickaxe":
        if has_abyss_pickaxe:
            base_pickaxe = textures["abyss_pick"]
        else:
            pickaxe_key = "gold_pick" if has_gold_pickaxe else "iron_pick" if has_iron_pickaxe else "stone_pick"
            base_pickaxe = textures[pickaxe_key]
        miners = [(player1_screen_x, player_y, player_facing_right, 0),]
        if player_count == 2:
            miners.append((player2_screen_x, player2_y, player2_facing_right, 1))
        for holder_x, holder_y, facing_right, player_index in miners:
            elapsed = mining_now - mining_animation_started[player_index]
            if 0 <= elapsed < 0.48:
                frame_index = min(3, int(elapsed / 0.12))
                relative_x, relative_y = extract_hand_points[frame_index]
                if not facing_right:
                    relative_x = 1 - relative_x
                sprite_left = holder_x + u(12)
                hand_x = sprite_left + round(player_render_textures[mining_frame_keys[frame_index]].get_width() * relative_x)
                hand_y = holder_y - u(22) + round(player_render_textures[mining_frame_keys[frame_index]].get_height() * relative_y)
                pickaxe = base_pickaxe if facing_right else pygame.transform.flip(base_pickaxe, True, False)
                screen.blit(pickaxe, (hand_x - pickaxe.get_width() // 2,
                                      hand_y - pickaxe.get_height() + u(8)))
            else:
                hand_x = holder_x + u(60) if facing_right else holder_x + u(12)
                pickaxe = base_pickaxe if facing_right else pygame.transform.flip(base_pickaxe, True, False)
                screen.blit(pickaxe, (hand_x - pickaxe.get_width() // 2, holder_y + u(18)))

    if selected_tool == "sword" and owns_sword():
        sword_holders = [(player1_screen_x, player_y, player_facing_right)]
        if player_count == 2:
            sword_holders.append((player2_screen_x, player2_y, player2_facing_right))
        for player_index, (holder_x, holder_y, facing_right) in enumerate(sword_holders):
            sword_sprite = textures[best_sword_texture()]
            if not facing_right:
                sword_sprite = pygame.transform.flip(sword_sprite, True, False)
            elapsed = mining_now - mining_animation_started[player_index]
            if 0 <= elapsed < 0.48:
                frame_index = min(3, int(elapsed / 0.12))
                relative_x, relative_y = extract_hand_points[frame_index]
                if not facing_right:
                    relative_x = 1 - relative_x
                sprite_left = holder_x + u(12)
                hand_x = sprite_left + round(player_render_textures[mining_frame_keys[frame_index]].get_width() * relative_x)
                hand_y = holder_y - u(22) + round(player_render_textures[mining_frame_keys[frame_index]].get_height() * relative_y)
                sword_x = hand_x - sword_sprite.get_width() // 2
                sword_y = hand_y - sword_sprite.get_height() // 2 - vertical_draw_offset
            else:
                hand_x = holder_x + u(60) if facing_right else holder_x + u(12)
                sword_x = hand_x - u(8) if facing_right else hand_x - sword_sprite.get_width() + u(8)
                sword_y = holder_y + u(12) - vertical_draw_offset
            screen.blit(sword_sprite, (sword_x, sword_y))

    if current_zone == "mine" and flashlight_equipped and selected_tool == "flashlight":
        flashlight_sprite = textures["flashlight"]
        flashlight_holders = [(player1_screen_x, player_y, player_facing_right)]
        if player_count == 2:
            flashlight_holders.append((player2_screen_x, player2_y, player2_facing_right))
        for holder_x, holder_y, facing_right in flashlight_holders:
            hand_flashlight = flashlight_sprite if facing_right else pygame.transform.flip(flashlight_sprite, True, False)
            hand_x = holder_x + u(60) if facing_right else holder_x + u(12)
            flashlight_x = hand_x - u(17) if facing_right else hand_x - hand_flashlight.get_width()
            screen.blit(hand_flashlight, (flashlight_x, holder_y + u(18)))

    if current_zone == "mine":
        light_sources = []
        if flashlight_equipped and selected_tool == "flashlight" and flashlight_on:
            p1_hand_x = player1_screen_x + u(60) if player_facing_right else player1_screen_x + u(12)
            light_sources.append((p1_hand_x, player_y + u(36), player_facing_right))
            if player_count == 2:
                p2_hand_x = player2_screen_x + u(60) if player2_facing_right else player2_screen_x + u(12)
                light_sources.append((p2_hand_x, player2_y + u(36), player2_facing_right))
        darkness_alpha = min(248, round(MINE_DARKNESS_ALPHA + mine_depth_tier(furthest_player_x) * 2.5))
        apply_mine_lighting(light_sources, darkness_alpha)

    if abyss_black_hole is not None:
        draw_abyss_black_hole()

    if show_hitboxes:
        player1_debug = player_hitbox(player_x, player_y).move(-camera_x, -vertical_draw_offset)
        pygame.draw.rect(screen, (70, 255, 100), player1_debug, max(1, u(2)))
        if player_count == 2:
            player2_debug = player_hitbox(player2_x, player2_y).move(-camera_x, -vertical_draw_offset)
            pygame.draw.rect(screen, (70, 200, 255), player2_debug, max(1, u(2)))
        if current_zone == "surface":
            for block in world_blocks:
                block_hitbox = world_block_rect(block).move(-camera_x, -vertical_draw_offset)
                pygame.draw.rect(screen, (255, 220, 40), block_hitbox, max(1, u(2)))
            for animal in visible_surface_objects(camera_x):
                if not animal.get("active") or animal["kind"] not in ("pig", "parrot"):
                    continue
                hitbox = surface_animal_hitbox(animal).move(-camera_x, -vertical_draw_offset)
                hitbox_color = (255, 125, 90) if animal["kind"] == "pig" else (80, 220, 255)
                pygame.draw.rect(screen, hitbox_color, hitbox, max(1, u(2)))
                if animal["kind"] == "parrot":
                    radius_center = (hitbox.centerx, hitbox.centery)
                    pygame.draw.circle(screen, (255, 85, 75), radius_center, PARROT_BITE_RADIUS,
                                       max(1, u(2)))
        if current_zone == "mine":
            for deposit in mineral_deposits:
                if deposit["active"]:
                    pygame.draw.rect(screen, (255, 235, 40), ore_hitbox(deposit["rect"]).move(-camera_x, 0), max(1, u(2)))
            for boulder in collapse_boulders:
                mask = boulder_masks[boulder["texture_index"]]
                outline = mask.outline()
                if len(outline) >= 3:
                    points = [(boulder["rect"].x + x - camera_x, boulder["rect"].y + y)
                              for x, y in outline]
                    pygame.draw.polygon(screen, (255, 80, 70), points, max(1, u(2)))
            for dandelion in dandelions:
                if dandelion["active"] and dandelion["phase"] not in ("digging", "underground"):
                    rise = round((1 - min(1.0, dandelion["timer"] / 0.7)) * u(80)) if dandelion["phase"] == "emerging" else 0
                    pygame.draw.rect(screen, (255, 80, 240), dandelion_hitbox(dandelion, rise).move(-camera_x, 0), max(1, u(2)))


def answer_game_question(question):
    """Локальный помощник: ищет смысл вопроса, терпит опечатки и помнит тему диалога."""
    global helper_last_intent
    q = question.casefold().replace("ё", "е").strip()
    tokens = re.findall(r"[^\W_]+", q, flags=re.UNICODE)

    live_questions = {
        "health_status": ("сколько здоровья", "сколько хп", "мое здоровье", "мой хп", "how much health", "my health", "生命值多少", "体力は"),
        "inventory_status": ("что у меня в инвентаре", "что у меня есть", "сколько предметов", "inventory contents", "what is in my backpack", "背包里有什么", "持ち物は何"),
        "money_status": ("сколько денег", "мой баланс", "сколько громок", "how much money", "my balance", "所持金はいくら", "余额多少"),
        "location_status": ("где я", "мои координаты", "какая глубина", "where am i", "my coordinates", "当前位置", "今どこ")
    }
    live_intent = next((intent_id for intent_id, phrases in live_questions.items()
                        if any(phrase in q for phrase in phrases)), None)
    if live_intent:
        helper_last_intent = live_intent
        if live_intent == "health_status":
            player_index = 1 if netplay.role == "client" and netplay.player_index == 1 else 0
            return {"ru": f"У тебя {player_health[player_index]} из {MAX_PLAYER_HEALTH} здоровья.",
                    "en": f"You have {player_health[player_index]} of {MAX_PLAYER_HEALTH} health.",
                    "es": f"Tienes {player_health[player_index]} de {MAX_PLAYER_HEALTH} de salud.",
                    "zh": f"你的生命值是 {player_health[player_index]}/{MAX_PLAYER_HEALTH}。",
                    "ja": f"体力は {player_health[player_index]}/{MAX_PLAYER_HEALTH} です。",
                    "fr": f"Tu as {player_health[player_index]} points de vie sur {MAX_PLAYER_HEALTH}.",
                    "sr": f"Imaš {player_health[player_index]} od {MAX_PLAYER_HEALTH} zdravlja."}[lang]
        if live_intent == "money_status":
            return {"ru": f"Сейчас у тебя {gromki} Громок.", "en": f"You have {gromki} Gromki.",
                    "es": f"Tienes {gromki} Gromki.", "zh": f"你有 {gromki} Gromki。",
                    "ja": f"Gromkiを{gromki}持っています。", "fr": f"Tu as {gromki} Gromki.",
                    "sr": f"Imaš {gromki} Gromkija."}[lang]
        if live_intent == "inventory_status":
            found = [(RESOURCE_NAMES[lang].get(item, item), amount)
                     for item, amount in inventory.items() if amount > 0]
            if not found:
                return {"ru": "Инвентарь пока пуст. Рюкзак открывается кнопкой справа.",
                        "en": "Your inventory is empty. Open it with the backpack button on the right.",
                        "es": "Tu inventario está vacío. Ábrelo con el botón de la mochila.",
                        "zh": "背包目前是空的，点击右侧背包按钮查看。",
                        "ja": "持ち物は空です。右側のバッグボタンで開けます。",
                        "fr": "Ton inventaire est vide. Ouvre-le avec le bouton du sac à droite.",
                        "sr": "Inventar je prazan. Otvori ga dugmetom za ranac sa desne strane."}[lang]
            summary = ", ".join(f"{name} ×{amount}" for name, amount in found[:5])
            if len(found) > 5:
                summary += {"ru": f" и ещё {len(found) - 5}", "en": f" and {len(found) - 5} more",
                            "es": f" y {len(found) - 5} más", "zh": f" 等另外{len(found) - 5}种",
                            "ja": f" 他{len(found) - 5}種類", "fr": f" et {len(found) - 5} autres",
                            "sr": f" i još {len(found) - 5}"}[lang]
            return {"ru": f"В инвентаре есть: {summary}.", "en": f"In your inventory: {summary}.",
                    "es": f"En tu inventario: {summary}.", "zh": f"背包里有：{summary}。",
                    "ja": f"持ち物：{summary}。", "fr": f"Dans ton inventaire : {summary}.",
                    "sr": f"U inventaru imaš: {summary}."}[lang]
        player_index = 1 if netplay.role == "client" and netplay.player_index == 1 else 0
        px, py = (player2_x, player2_y) if player_index else (player_x, player_y)
        zone_name = {"surface": {"ru": "поверхности", "en": "the surface", "es": "la superficie", "zh": "地面", "ja": "地上"},
                     "mine": {"ru": "шахте", "en": "the mine", "es": "la mina", "zh": "矿井", "ja": "鉱山"},
                     "ocean": {"ru": "океане", "en": "the ocean", "es": "el océano", "zh": "海洋", "ja": "海"}}[current_zone]
        zone_name = zone_name.get(lang, zone_name["en"])
        coords = f"X {px // BLOCK_SIZE}, Y {py // BLOCK_SIZE}"
        depth = str(mine_depth_tier(px) + 1) if current_zone == "mine" else None
        return {"ru": f"Ты сейчас в {zone_name}. Координаты: {coords}. Уровень шахты: {depth or 'ты не в шахте'}.",
                "en": f"You are in {zone_name}. Coordinates: {coords}. Mine level: {depth or 'not in the mine'}.",
                "es": f"Estás en {zone_name}. Coordenadas: {coords}. Nivel de mina: {depth or 'no estás en la mina'}.",
                "zh": f"你现在位于{zone_name}。坐标：{coords}。矿井层级：{depth or '不在矿井'}。",
                "ja": f"現在は{zone_name}です。座標：{coords}。鉱山レベル：{depth or '鉱山の外'}。",
                "fr": f"Tu es dans {zone_name}. Coordonnées : {coords}. Niveau de mine : {depth or 'hors de la mine'}.",
                "sr": f"Nalaziš se u oblasti {zone_name}. Koordinate: {coords}. Nivo rudnika: {depth or 'nisi u rudniku'}."}[lang]

    advice_words = ("что делать", "что дальше", "куда идти", "что посоветуешь", "дай совет",
                    "как лучше", "what should i do", "what next", "recommend", "advice", "怎么办", "次は")
    if any(word in q for word in advice_words):
        helper_last_intent = "advice"
        player_index = 1 if netplay.role == "client" and netplay.player_index == 1 else 0
        hp = player_health[player_index]
        if current_zone == "ocean":
            return {"ru": "Ты в океане: нажми 5, чтобы взять удочку, и R, чтобы забросить. Жди поклёвку и нажми R ещё раз.",
                    "en": "You are in the ocean: press 5 to equip the rod, R to cast, then R again after a bite.",
                    "es": "Estás en el océano: pulsa 5 para tomar la caña y R para lanzar. Pulsa R otra vez al picar.",
                    "zh": "你在海洋：按5拿鱼竿，按R抛竿，鱼咬钩后再按R。",
                    "ja": "海にいます。5で竿を持ち、Rで投げ、魚がかかったらもう一度Rを押しましょう。",
                    "fr": "Tu es dans l'océan : appuie sur 5 pour prendre la canne et sur R pour lancer. Appuie encore sur R quand ça mord.",
                    "sr": "Na okeanu si: pritisni 5 za štap, R da zabaciš, pa ponovo R kada riba zagrize."}[lang]
        if hp <= 10 and inventory.get("melon", 0) > 0:
            return {"ru": f"Здоровья мало ({hp}/{MAX_PLAYER_HEALTH}), а у тебя есть арбуз. Нажми 4, чтобы съесть его и восстановить здоровье.",
                    "en": f"Your health is low ({hp}/{MAX_PLAYER_HEALTH}) and you have a watermelon. Press 4 to eat it and heal.",
                    "es": f"Tienes poca salud ({hp}/{MAX_PLAYER_HEALTH}) y una sandía. Pulsa 4 para comerla y curarte.",
                    "zh": f"你的生命值较低（{hp}/{MAX_PLAYER_HEALTH}），而且有西瓜。按4食用恢复生命。",
                    "ja": f"体力が少なく（{hp}/{MAX_PLAYER_HEALTH}）、スイカを持っています。4を押して食べましょう。",
                    "fr": f"Tu as peu de santé ({hp}/{MAX_PLAYER_HEALTH}) et une pastèque. Appuie sur 4 pour la manger et te soigner.",
                    "sr": f"Imaš malo zdravlja ({hp}/{MAX_PLAYER_HEALTH}) i lubenicu. Pritisni 4 da je pojedeš i oporaviš se."}[lang]
        if current_zone == "mine":
            return {"ru": "Ты в шахте. Выбери кирку (1) и разбивай месторождения. Если здоровье станет низким, вернись на поверхность и поищи арбузы.",
                    "en": "You are in the mine. Select the pickaxe (1) and break deposits. If health gets low, return to the surface and look for watermelons.",
                    "es": "Estás en la mina. Elige el pico (1) y rompe yacimientos. Si te queda poca salud, vuelve a la superficie y busca sandías.",
                    "zh": "你在矿井。按1选择镐子并开采矿床。生命值低时回到地面寻找西瓜。",
                    "ja": "鉱山にいます。1でツルハシを選んで鉱床を壊しましょう。体力が減ったら地上でスイカを探してください。",
                    "fr": "Tu es dans la mine. Choisis la pioche (1) et casse des gisements. Si ta santé baisse, retourne à la surface chercher des pastèques.",
                    "sr": "U rudniku si. Izaberi pijuk (1) i razbijaj nalazišta. Ako ti zdravlje opadne, vrati se na površinu po lubenice."}[lang]
        if inventory.get("stone_block", 0) > 0:
            return {"ru": "У тебя есть каменные блоки. На поверхности выбери ячейку 6 и ставь блоки кликом; на готовый блок можно поставить следующий.",
                    "en": "You have stone blocks. On the surface select slot 6 and click to place one; click an existing block to stack another on top.",
                    "es": "Tienes bloques de piedra. En la superficie elige la casilla 6 y haz clic; pulsa un bloque para colocar otro encima.",
                    "zh": "你有石块。在地面选择第6格并点击放置；点击已有方块可继续向上堆叠。",
                    "ja": "石ブロックを持っています。地上で6を選んでクリックし、置いたブロックをクリックして上に積みましょう。",
                    "fr": "Tu as des blocs de pierre. À la surface, choisis la case 6 et clique pour poser un bloc. Clique sur un bloc pour en empiler un autre.",
                    "sr": "Imaš kamene blokove. Na površini izaberi polje 6 i klikni da postaviš blok. Klikni na blok da staviš sledeći iznad njega."}[lang]
        return {"ru": "Начни с шахты: нажми E у входа, добудь несколько месторождений киркой и собери каменные блоки. Потом можно вернуться на поверхность, продать руду или строить вверх.",
                "en": "Start at the mine: press E by its entrance, mine a few deposits, and collect stone blocks. Then return, sell ore, or build upward.",
                "es": "Empieza en la mina: pulsa E junto a la entrada, rompe algunos yacimientos y recoge bloques. Luego vuelve, vende minerales o construye hacia arriba.",
                "zh": "可以先去矿井：在入口按E，用镐子开采并收集石块。之后回地面出售矿石或向上建造。",
                "ja": "まず鉱山へ行きましょう。入口でEを押し、鉱床を採掘してブロックを集めます。地上に戻って売却や建築ができます。",
                "fr": "Commence par la mine : appuie sur E à l'entrée, mine des gisements avec ta pioche et récupère des blocs. Reviens ensuite vendre tes minerais ou construire.",
                "sr": "Počni u rudniku: pritisni E kod ulaza, pijukom razbijaj nalazišta i skupljaj blokove. Zatim se vrati da prodaš rudu ili gradiš."}[lang]

    # Ищем название предмета в вопросе, чтобы отвечать по фактическим ценам,
    # запасу игрока и глубине появления именно этого минерала.
    item_matches = []
    for item_id, localized_name in RESOURCE_NAMES[lang].items():
        variants = {localized_name.casefold(), item_id.casefold().replace("_", " ")}
        for variant in variants:
            if len(variant) >= 3 and variant in q:
                item_matches.append((len(variant), item_id))
                break
            if len(variant) >= 5:
                for token in tokens:
                    if len(token) >= 5 and SequenceMatcher(None, token, variant).ratio() >= 0.86:
                        item_matches.append((len(variant) - 1, item_id))
                        break
    item_ask_words = ("где", "найти", "добыть", "получить", "цена", "стоит", "продать", "что такое", "для чего", "использ",
                      "where", "find", "get", "price", "worth", "sell", "about", "use", "用途", "用处", "怎么获得", "どこ", "値段", "使い道", "入手")
    if item_matches and (any(word in q for word in item_ask_words) or q in {name.casefold() for name in RESOURCE_NAMES[lang].values()}):
        _, item_id = max(item_matches)
        item_name = RESOURCE_NAMES[lang].get(item_id, item_id)
        amount = inventory.get(item_id, 0)
        value = prices.get(item_id, 0)
        if item_id in OCEAN_INVENTORY_ITEMS:
            source_detail = {"ru": "Лови удочкой; зуб акулы встречается редко.", "en": "Fish with the rod; shark teeth are rare.",
                             "es": "Pesca con la caña; el diente de tiburón es raro.", "zh": "用鱼竿钓取；鲨鱼牙齿很稀有。",
                             "ja": "釣り竿で釣ります。サメの歯は珍しいです。", "fr": "Pêche-le à la canne ; les dents de requin sont rares.",
                             "sr": "Uhvati ga štapom za pecanje; zubi ajkule su retki."}[lang]
        elif item_id in SURFACE_INVENTORY_ITEMS or item_id == "melon":
            source_detail = {"ru": "Ищи кусты или собирай предметы на поверхности.", "en": "Look for bushes or collect it on the surface.",
                             "es": "Busca arbustos o recógelo en la superficie.", "zh": "在地面寻找灌木或收集物品。",
                             "ja": "地上の茂みを探すか、アイテムを集めましょう。", "fr": "Cherche des buissons ou ramasse cet objet à la surface.",
                             "sr": "Potraži žbunje ili sakupi predmet na površini."}[lang]
            if item_id in MOD_FOOD_ITEMS and item_id in MOD_ITEM_EFFECTS:
                effect, amount_healed = MOD_ITEM_EFFECTS[item_id]
                if effect == "heal_speed":
                    duration = round(MOD_ITEM_SPEED_DURATIONS.get(item_id, 5))
                    source_detail = {
                        "ru": f"Это еда из мода: иногда выпадает со свиньи. При использовании лечит до {amount_healed} здоровья и ускоряет на {duration} сек.",
                        "en": f"This modded food sometimes drops from pigs. Using it heals up to {amount_healed} health and boosts speed for {duration} sec.",
                        "es": f"Esta comida del mod puede caer de los cerdos. Cura hasta {amount_healed} y aumenta la velocidad {duration} s.",
                        "zh": f"这是模组食物，有时从猪身上掉落。使用后恢复最多{amount_healed}点生命并加速{duration}秒。",
                        "ja": f"MODの食べ物で、ブタから時々手に入ります。体力を最大{amount_healed}回復し、{duration}秒間速くなります。",
                        "fr": f"Nourriture de mod parfois lâchée par les cochons. Elle soigne jusqu'à {amount_healed} PV et accélère pendant {duration} s.",
                        "sr": f"Hrana iz moda koju svinje ponekad ispuštaju. Vraća do {amount_healed} zdravlja i ubrzava te na {duration} s."}[lang]
            elif item_id == "melon":
                source_detail = {"ru": "Собирай с куста арбузов; съешь его клавишей 4, чтобы восстановить здоровье.",
                                 "en": "Pick it from a watermelon bush; press 4 to eat it and restore health.",
                                 "es": "Recógela de un arbusto y pulsa 4 para comerla y recuperar salud.",
                                 "zh": "从西瓜灌木采集，按4食用以恢复生命。",
                                 "ja": "スイカの茂みから採集し、4を押して食べると体力が回復します。",
                                 "fr": "Récolte-la sur un buisson de pastèques ; appuie sur 4 pour la manger et récupérer de la santé.",
                                 "sr": "Sakupi je sa žbuna lubenice; pritisni 4 da je pojedeš i vratiš zdravlje."}[lang]
            elif item_id in ("raw_pork", "bone"):
                source_detail = {"ru": "Сырая свинина и кости выпадают со свиньи, побеждённой мечом.",
                                 "en": "Raw pork and bones drop from pigs defeated with a sword.",
                                 "es": "La carne cruda y los huesos caen de cerdos vencidos con una espada.",
                                 "zh": "用剑打败猪会掉落生猪肉和骨头。",
                                 "ja": "剣でブタを倒すと生肉と骨が落ちます。",
                                 "fr": "Le porc cru et les os tombent des cochons vaincus avec une épée.",
                                 "sr": "Sirova svinjetina i kosti ispadaju kada pobediš svinju mačem."}[lang]
            elif item_id == "raspberry":
                source_detail = {"ru": "Собирай ягоды с кустов малины на поверхности.", "en": "Pick it from raspberry bushes on the surface.",
                                 "es": "Recógela de los arbustos de frambuesa.", "zh": "从地面的树莓灌木采集。",
                                 "ja": "地上のラズベリーの茂みから採集します。", "fr": "Récolte-la sur les buissons de framboises à la surface.",
                                 "sr": "Sakupi je sa žbunova maline na površini."}[lang]
            elif item_id == "gelatin":
                source_detail = {"ru": "Получи её, перемолов 2 кости в инвентаре.", "en": "Make it by grinding 2 bones in the inventory.",
                                 "es": "Se obtiene moliendo 2 huesos en el inventario.", "zh": "在背包中研磨2根骨头获得。",
                                 "ja": "持ち物画面で骨を2個砕くと作れます。", "fr": "Fabrique-la en broyant 2 os dans l'inventaire.",
                                 "sr": "Napravi je mlevenjem 2 kosti u inventaru."}[lang]
            elif item_id == "marmalade":
                source_detail = {"ru": "Соедини малину и желатин в инвентаре.", "en": "Combine raspberries and gelatin in the inventory.",
                                 "es": "Combina frambuesas y gelatina en el inventario.", "zh": "在背包中把树莓和明胶组合。",
                                 "ja": "持ち物画面でラズベリーとゼラチンを組み合わせます。", "fr": "Mélange des framboises et de la gélatine dans l'inventaire.",
                                 "sr": "Pomešaj maline i želatin u inventaru."}[lang]
        else:
            if item_id == "stone_block":
                source_detail = {"ru": "Разбивай месторождения киркой: за каждое дают один блок.", "en": "Break deposits with a pickaxe; each one gives a block.",
                                 "es": "Rompe yacimientos con el pico; cada uno da un bloque.", "zh": "用镐子打碎矿床，每个矿床会给一个方块。",
                                 "ja": "ツルハシで鉱床を壊すと1個入手できます。", "fr": "Casse les gisements avec une pioche : chacun donne un bloc.",
                                 "sr": "Razbijaj nalazišta pijukom; svako daje jedan blok."}[lang]
            elif item_id == "classic_stone":
                source_detail = {"ru": "При разрушении месторождения всегда выпадает 5 камня.", "en": "Breaking a deposit always drops 5 stone.",
                                 "es": "Al romper un yacimiento siempre caen 5 piedras.", "zh": "打碎矿床一定会掉落5块石头。",
                                 "ja": "鉱床を壊すと必ず石が5個落ちます。", "fr": "Chaque gisement détruit donne toujours 5 pierres.",
                                 "sr": "Svako razbijeno nalazište uvek daje 5 kamena."}[lang]
            else:
                level = max(mining_depth_for_item(item_id), MOD_MIN_DEPTHS.get(item_id, 0)) + 1
                source_detail = {"ru": f"Появляется примерно с уровня глубины {level}; у месторождения есть шанс дать минерал.",
                                 "en": f"It starts appearing around mine level {level}; deposits have a chance to drop it.",
                                 "es": f"Empieza a aparecer aproximadamente en el nivel {level} de la mina.",
                                 "zh": f"大约从矿井第{level}层开始出现。",
                                 "ja": f"鉱山レベル{level}あたりから出現します。", "fr": f"Apparaît à partir du niveau {level} environ ; les gisements peuvent en donner.",
                                 "sr": f"Pojavljuje se otprilike od nivoa {level}; nalazišta ga ponekad daju."}[lang]
        helper_last_intent = "item_info"
        return {"ru": f"{item_name}: {source_detail} Сейчас у тебя {amount}. Цена продажи — {value} Громок за штуку.",
                "en": f"{item_name}: {source_detail} You have {amount}. Sell price: {value} Gromki each.",
                "es": f"{item_name}: {source_detail} Tienes {amount}. Precio de venta: {value} Gromki por unidad.",
                "zh": f"{item_name}：{source_detail}你有{amount}个。售价：每个{value} Gromki。",
                "ja": f"{item_name}：{source_detail}現在{amount}個あります。売値は1個{value} Gromkiです。",
                "fr": f"{item_name} : {source_detail} Tu en as {amount}. Prix de vente : {value} Gromki l'unité.",
                "sr": f"{item_name}: {source_detail} Imaš {amount}. Prodajna cena je {value} Gromkija po komadu."}[lang]

    intents = [
        ("controls", ("управ", "клав", "двиг", "ходить", "прыга", "wasd", "controls", "move", "jump", "操作"), {
            "ru": "A и D — ходить, Пробел — прыгать, E — взаимодействовать и входить в шахту или океан. Клавиши 1–6 выбирают предметы: кирку, фонарик, меч, еду, удочку и блоки.",
            "en": "A and D move, Space jumps, E interacts or enters the mine/ocean. Keys 1–6 select the pickaxe, flashlight, sword, food, rod, and blocks.",
            "es": "A y D mueven, Espacio salta y E interactúa o entra en la mina/el océano. Las teclas 1–6 eligen herramientas y objetos.",
            "zh": "A、D移动，空格跳跃，E互动或进入矿井/海洋。数字1–6选择工具和物品。",
            "ja": "A・Dで移動、Spaceでジャンプ、Eで操作・入場。1〜6で道具やアイテムを選びます。"}),
        ("blocks", ("блок", "стро", "постав", "строит", "stone block", "build", "place block", "方块", "ブロック"), {
            "ru": "В шахте разбивай месторождения киркой — за каждое получишь каменный блок. На поверхности выбери блоки клавишей 6 и нажми мышью. Если нажать на готовый блок, новый встанет сверху. Киркой блок можно вернуть. На блоках можно подниматься выше.",
            "en": "Break mine deposits with a pickaxe to get stone blocks. On the surface select blocks with 6 and click. Clicking an existing block builds upward. Mine placed blocks with a pickaxe to recover them.",
            "es": "Rompe yacimientos con el pico para obtener bloques. En la superficie pulsa 6 y haz clic. Al pulsar un bloque colocado, el nuevo se pone encima. Recupéralo con el pico.",
            "zh": "用镐子打碎矿床获得石块。地面按6选方块并点击放置。点击已有方块可向上堆叠，用镐子可回收。",
            "ja": "鉱山でツルハシを使って鉱床を壊すとブロックを入手。地上で6を選んでクリック。置いたブロックをクリックすると上に積めます。ツルハシで回収できます。"}),
        ("mining", ("шахт", "руд", "месторож", "коп", "кирк", "mine", "ore", "mining", "鉱", "矿"), {
            "ru": "В шахте выбери кирку клавишей 1. Подойди к месторождению и кликай по нему. У месторождения 30 прочности: каменная кирка снимает 3, железная — 5, золотая — 4, но с шансом 50% снимает 6–10. За разрушение всегда дают 5 обычного камня, опыт и каменный блок; иногда выпадает руда.",
            "en": "Select the pickaxe with 1, approach a deposit, and click it. Deposits have 30 durability: stone deals 3, iron 5, gold 4, with a 50% chance for 6–10. Breaking one gives 5 stone, XP, and a block; sometimes it also drops ore.",
            "es": "Elige el pico con 1, acércate al yacimiento y haz clic. Tiene 30 de resistencia. Al romperlo obtienes piedra, experiencia y un bloque; a veces también mineral.",
            "zh": "按1选择镐子，靠近矿床并点击。矿床有30点耐久。打碎后获得石头、经验和方块，有时还有矿石。",
            "ja": "1でツルハシを選び、鉱床に近づいてクリック。耐久力は30です。壊すと石・経験値・ブロックが手に入り、ときどき鉱石も出ます。"}),
        ("fishing", ("удоч", "рыбал", "лов", "рыб", "fish", "rod", "釣", "钓"), {
            "ru": "В океане нажми 5, чтобы взять удочку, затем R — забросить. Подожди поклёвку и снова нажми R. Обычно ловится рыба, а зуб акулы — редкая находка.",
            "en": "In the ocean, press 5 to equip the rod and R to cast. Wait for a bite, then press R again. Fish are common; shark teeth are rare.",
            "es": "En el océano, pulsa 5 para tomar la caña y R para lanzar. Espera la picada y pulsa R otra vez. El diente de tiburón es raro.",
            "zh": "在海洋按5拿鱼竿，按R抛竿。等鱼咬钩后再按R。鱼常见，鲨鱼牙齿稀有。",
            "ja": "海で5を押して竿を持ち、Rで投げます。魚がかかったらもう一度R。サメの歯は珍しいです。"}),
        ("combat", ("меч", "атак", "удар", "враг", "крит", "sword", "attack", "combat", "敵", "剑"), {
            "ru": "Выбери меч клавишей 3 и нажми мышью по врагу или другому игроку. Удар в прыжке наносит больше урона. Между ударами есть короткая перезарядка 0,02 секунды.",
            "en": "Select the sword with 3 and click an enemy or another player. Jumping attacks deal more damage. The attack cooldown is 0.02 seconds.",
            "es": "Elige la espada con 3 y haz clic en un enemigo u otro jugador. Saltar aumenta el daño. La espera entre golpes es de 0,02 segundos.",
            "zh": "按3选择剑并点击敌人或玩家。跳跃攻击伤害更高，攻击间隔为0.02秒。",
            "ja": "3で剣を選び、敵や他のプレイヤーをクリック。ジャンプ攻撃は強く、攻撃間隔は0.02秒です。"}),
        ("flower", ("одуван", "цветок", "dandelion", "flower", "蒲公英", "タンポポ"), {
            "ru": "Одуванчики появляются в шахте примерно раз в минуту — от 1 до 15 штук. Они нападают на игрока. За победу над одуванчиком выпадают магические камни и алмазы.",
            "en": "Dandelions appear in the mine about once a minute, 1–15 at a time, and attack players. Defeating one drops magic stones and diamonds.",
            "es": "En la mina aparecen de 1 a 15 dientes de león aproximadamente cada minuto y atacan. Al vencerlos sueltan piedras mágicas y diamantes.",
            "zh": "蒲公英大约每分钟在矿井出现1到15只并攻击玩家。打败它们会掉落魔法石和钻石。",
            "ja": "タンポポは鉱山に約1分ごとに1〜15体現れ、攻撃してきます。倒すと魔法石とダイヤを落とします。"}),
        ("spider", ("паук", "паут", "spider", "web", "蜘蛛", "クモ", "クモの巣"), {
            "ru": "Паук появляется под потолком шахты и бросает паутину. В игре шанс замедления — 60%, шанс заморозки на 10 секунд — 40%.",
            "en": "A spider appears from the mine ceiling and throws web. The game gives a 60% chance to slow you and a 40% chance to freeze you for 10 seconds.",
            "es": "La araña aparece en el techo de la mina y lanza telaraña: 60% de ralentizar y 40% de congelar durante 10 segundos.",
            "zh": "蜘蛛会从矿井天花板出现并投掷蛛网：60%减速，40%冻结10秒。",
            "ja": "クモは鉱山の天井から現れて糸を投げます。60%で減速、40%で10秒間凍結します。"}),
        ("parrot", ("попуг", "укус", "parrot", "鹦鹉", "オウム"), {
            "ru": "Попугаи летают по поверхности и иногда кусают, если подойти близко. Укус снимает 29 здоровья. Попугая нельзя атаковать, но его можно гладить: зажми Shift и кликни по нему.",
            "en": "Parrots fly on the surface and may bite if you get close, dealing 29 damage. You cannot attack them, but you can pet one by holding Shift and clicking it.",
            "es": "Los loros vuelan por la superficie y pueden picar de cerca (29 de daño). No puedes atacarlos; acarícialos con Shift y clic.",
            "zh": "鹦鹉在地面上飞，靠近时可能啄你并造成29点伤害。不能攻击它们；按住Shift点击可以抚摸。",
            "ja": "オウムは地上を飛び、近づくと29ダメージの噛みつきをすることがあります。攻撃はできませんが、Shiftを押しながらクリックすると撫でられます。"}),
        ("animals", ("свин", "мали", "желат", "мармел", "арбузн куст", "pig", "raspberry", "gelatin", "marmalade", "猪", "豚", "ラズベリー"), {
            "ru": "На поверхности ищи кусты арбузов и малины. Арбуз восстанавливает здоровье. Свинью можно победить мечом — с неё выпадают сырая свинина и кости. Кости перемалываются в желатин, а малина вместе с желатином превращается в мармелад.",
            "en": "Find watermelon and raspberry bushes on the surface. Watermelon restores health. Defeat pigs with a sword for raw pork and bones. Grind bones into gelatin, then combine gelatin with raspberries to make marmalade.",
            "es": "Busca arbustos de sandía y frambuesa. La sandía recupera salud. Las cerdas dan carne y huesos; muele los huesos para obtener gelatina y combínala con frambuesas.",
            "zh": "地面有西瓜和树莓灌木。西瓜恢复生命。用剑打败猪可获得生肉和骨头；骨头可磨成明胶，再与树莓制作软糖。",
            "ja": "地上にはスイカとラズベリーの茂みがあります。スイカは体力を回復。ブタを剣で倒すと生肉と骨が手に入り、骨をゼラチンにしてラズベリーと合わせるとグミになります。"}),
        ("food", ("арбуз", "восстан", "леч", "съесть", "melon", "watermelon", "recover health", "恢复", "スイカ"), {
            "ru": "Арбузы растут на кустах в верхнем мире. Выбери арбуз в ячейке 4 или нажми 4, чтобы съесть его и восстановить здоровье.",
            "en": "Watermelons grow on bushes in the surface world. Select slot 4 or press 4 to eat one and restore health.",
            "es": "Las sandías crecen en arbustos de la superficie. Selecciona la casilla 4 o pulsa 4 para comer y recuperar salud.",
            "zh": "西瓜长在地面灌木上。选择第4格或按4食用来恢复生命。",
            "ja": "スイカは地上の茂みに実ります。4番スロットを選ぶか4を押して食べると体力が回復します。"}),
        ("inventory", ("инвентар", "рюкзак", "ячейк", "слот", "прод", "sell", "inventory", "背包", "売"), {
            "ru": "Рюкзак открывается кнопкой справа. Категории сверху разделяют шахту, океан и поверхность. В ячейке можно продать один предмет или нажать «Всё», чтобы продать всю стопку. Колесо мыши листает список.",
            "en": "Open the backpack button on the right. Tabs group mine, ocean, and surface items. Sell one item or press All to sell the whole stack. Use the mouse wheel to scroll.",
            "es": "Abre la mochila a la derecha. Las pestañas separan mina, océano y superficie. Puedes vender uno o toda la pila con «Todo».",
            "zh": "点击右侧背包。上方标签分类显示矿井、海洋和地面物品。可以出售一个或整组，滚动鼠标滚轮浏览。",
            "ja": "右側のバッグを開きます。上のタブで鉱山・海・地上を分けます。1個または「全部」で売れます。ホイールで一覧をスクロール。"}),
        ("saving", ("сохр", "вылет", "лог", "ошиб", "save", "crash", "logs", "保存", "セーブ"), {
            "ru": "Прогресс сохраняется автоматически примерно каждые 30 секунд и при выходе через Esc. События и сведения об ошибках записываются в папку logs рядом с игрой.",
            "en": "Progress autosaves about every 30 seconds and when leaving with Esc. Game events and error details are written to the logs folder next to the game.",
            "es": "La partida se guarda cada 30 segundos y al salir con Esc. Los eventos y errores aparecen en la carpeta logs.",
            "zh": "游戏约每30秒自动保存，按Esc退出时也会保存。事件和错误信息写入游戏旁边的logs文件夹。",
            "ja": "進行状況は約30秒ごととEsc終了時に保存されます。イベントやエラーはlogsフォルダーに記録されます。"}),
        ("coordinates", ("координ", "глубин", "depth", "coordinate", "x y", "где я", "坐标", "深さ", "座標", "深度"), {
            "ru": "Координаты X и Y и уровень глубины шахты уже показываются на экране. X и Y считаются в блоках. Уровень глубины растёт по мере продвижения по шахте.",
            "en": "Your X/Y coordinates and mine-depth level are shown on screen. Coordinates are measured in blocks; the mine level increases as you progress.",
            "es": "Las coordenadas X/Y y el nivel de profundidad se muestran en pantalla. Se miden en bloques y el nivel aumenta al avanzar.",
            "zh": "屏幕上会显示X/Y坐标和矿井深度等级。坐标按方块计算，继续前进会提高深度等级。",
            "ja": "画面にX/Y座標と鉱山の深さが表示されます。座標はブロック単位で、進むほどレベルが上がります。"}),
        ("worlds", ("мир", "созда", "новый мир", "world", "世界", "ワールド"), {
            "ru": "Чтобы создать отдельный мир, нажми кнопку создания в меню выбора миров и введи название. Каждый мир хранит своё сохранение.",
            "en": "Create a separate world from the world-selection menu by entering a name. Each world has its own save.",
            "es": "Crea otro mundo desde el menú de mundos escribiendo un nombre. Cada mundo tiene su propia partida.",
            "zh": "在世界选择菜单输入名称即可创建新世界。每个世界都有独立存档。",
            "ja": "ワールド選択メニューで名前を入力すると新しいワールドを作れます。セーブは別々です。"}),
        ("multiplayer", ("мультип", "друг", "сервер", "wi-fi", "wifi", "vpn", "подключ", "играть вместе", "multiplayer", "server", "朋友", "サーバー"), {
            "ru": "Для игры с другом один игрок создаёт сетевую игру и передаёт адрес, который показан в игре. Друг выбирает «Подключиться» и вводит этот адрес. Для постоянного мира запускается отдельный сервер; его папку нельзя отделять от файлов сервера.",
            "en": "One player hosts and shares the address shown in the game. The friend chooses Join and enters it. A dedicated server can keep a world running; keep its folder intact.",
            "es": "Un jugador crea la partida y comparte la dirección mostrada. El otro pulsa Conectar. Un servidor dedicado puede mantener el mundo activo.",
            "zh": "一名玩家创建游戏并分享屏幕上的地址，朋友选择加入并输入地址。独立服务器可让世界持续运行。",
            "ja": "一人がゲームを作成して表示されたアドレスを共有し、友達は接続して入力します。専用サーバーなら世界を継続できます。"}),
        ("mods", ("мод", "модификац", "jar", "mod", "插件", "改造"), {
            "ru": "Моды лежат в папке mods. Игра поддерживает mod.json и PNG: мод может добавить минерал или еду с эффектом. Например, звёздная конфета иногда выпадает со свиньи, лечит и ускоряет. Java-код из Minecraft-модов игра не запускает.",
            "en": "Mods go in the mods folder as mod.json and PNG. A mod can add a mineral or food with an effect. For example, Star candy sometimes drops from pigs, heals, and boosts speed. Minecraft Java code does not run.",
            "es": "Los mods van en mods: una carpeta con mod.json y PNG o un JAR con ese formato. No ejecuta código Java de Minecraft.",
            "zh": "模组放在mods文件夹中，可使用包含mod.json和PNG的文件夹或同格式JAR。不会运行Minecraft Java代码。",
            "ja": "modsフォルダーにmod.jsonとPNGを入れます。同じ形式のJARも使えます。MinecraftのJavaコードは実行されません。"}),
        ("settings", ("настрой", "звук", "громк", "полноэкран", "fullscreen", "volume", "settings", "音量", "設定"), {
            "ru": "Открой настройки из главного меню. Там можно включить или выключить полный экран и изменить громкость звука.",
            "en": "Open Settings from the main menu to toggle fullscreen and adjust the sound volume.",
            "es": "Abre Ajustes en el menú principal para cambiar pantalla completa y volumen.",
            "zh": "在主菜单打开设置，可以切换全屏并调整音量。",
            "ja": "メインメニューの設定で全画面表示と音量を変更できます。"}),
        ("shop", ("магазин кирок", "купить меч", "купить кирку", "buy sword", "buy pickaxe", "магаз", "купить", "покуп", "shop", "store", "商店"), {
            "ru": "Магазин находится на поверхности. Нажми на его здание, выбери предмет в витрине и нажми кнопку покупки. Кирки помогают добывать руду, мечи — сражаться.",
            "en": "The shop is on the surface. Click its building, choose an item on the display, then press Buy. Pickaxes mine ore; swords are for fighting.",
            "es": "La tienda está en la superficie. Haz clic en el edificio, elige un objeto y pulsa Comprar.",
            "zh": "商店在地面。点击建筑，选择展示物品并购买。镐子采矿，剑用于战斗。",
            "ja": "店は地上にあります。建物をクリックし、商品を選んで購入。ツルハシは採掘、剣は戦闘用です。"}),
        ("pet", ("глад", "shift", "поглад", "pet", "抚摸", "なで"), {
            "ru": "Зажми Shift и нажми левой кнопкой по животному или другому игроку, чтобы погладить его. Помощник не показывается поверх открытого инвентаря.",
            "en": "Hold Shift and left-click an animal or another player to pet them. The helper hides while the inventory is open.",
            "es": "Mantén Shift y haz clic izquierdo en un animal u otro jugador para acariciarlo.",
            "zh": "按住Shift并左键点击动物或其他玩家即可抚摸。打开背包时助手会隐藏。",
            "ja": "Shiftを押しながら動物や他のプレイヤーを左クリックすると撫でられます。"}),
        ("helper", ("помощник", "помоги", "умеешь", "helper", "助理", "ヘルパー"), {
            "ru": "Я встроенный помощник по Stickman in Mine. Я ищу ответ в справочнике игры, понимаю разные формулировки и некоторые опечатки. Спроси про шахту, блоки, животных, океан, настройки или сеть.",
            "en": "I am the built-in Stickman in Mine helper. I search the game's guide, understand different wording, and can handle some typos. Ask about mining, blocks, animals, ocean, settings, or multiplayer.",
            "es": "Soy la ayuda integrada del juego. Busco en la guía y entiendo varias formas de preguntar, incluso algunos errores.",
            "zh": "我是游戏内置助手，会搜索游戏指南并理解不同问法和一些拼写错误。",
            "ja": "ゲーム内の案内を検索し、言い換えや一部の誤字も理解するヘルパーです。"}),
    ]

    # Находим лучший смысловой раздел. При опечатке сравниваем похожие слова,
    # а не ищем только точное совпадение одной подстроки.
    ranked = []
    for intent_id, keywords, translations in intents:
        best_score = 0.0
        matches = 0
        for keyword in keywords:
            keyword = keyword.casefold().replace("ё", "е")
            score = 0.0
            if keyword in q:
                score = 5.0 if " " in keyword else 3.5
            else:
                keyword_parts = re.findall(r"[^\W_]+", keyword, flags=re.UNICODE)
                for token in tokens:
                    for part in keyword_parts:
                        if len(part) >= 3 and (token.startswith(part) or (len(token) >= 4 and part in token)):
                            score = max(score, 3.2)
                        elif len(token) >= 5 and len(part) >= 5:
                            similarity = SequenceMatcher(None, token, part).ratio()
                            if similarity >= 0.78:
                                score = max(score, 2.4 + similarity)
            if score:
                matches += 1
                best_score = max(best_score, score)
        ranked.append((best_score + min(0.6, max(0, matches - 1) * 0.15), intent_id, translations))

    ranked.sort(key=lambda result: result[0], reverse=True)
    if ranked and ranked[0][0] >= 2.4:
        best_score, intent_id, translations = ranked[0]
        if len(ranked) > 1 and best_score < 4.8 and best_score - ranked[1][0] < 0.2:
            helper_last_intent = ""
            intent_names = {
                "controls": {"ru": "управление", "en": "controls", "es": "controles", "zh": "操作", "ja": "操作"},
                "blocks": {"ru": "блоки", "en": "blocks", "es": "bloques", "zh": "方块", "ja": "ブロック"},
                "mining": {"ru": "шахта и руды", "en": "mining", "es": "mina y minerales", "zh": "矿井和矿石", "ja": "鉱山と鉱石"},
                "fishing": {"ru": "рыбалка", "en": "fishing", "es": "pesca", "zh": "钓鱼", "ja": "釣り"},
                "combat": {"ru": "бой", "en": "combat", "es": "combate", "zh": "战斗", "ja": "戦闘"},
                "shop": {"ru": "магазин", "en": "the shop", "es": "tienda", "zh": "商店", "ja": "店"},
                "inventory": {"ru": "инвентарь", "en": "inventory", "es": "inventario", "zh": "背包", "ja": "持ち物"}
            }
            first_topic = intent_names.get(intent_id, {}).get(lang, intent_id)
            second_topic = intent_names.get(ranked[1][1], {}).get(lang, ranked[1][1])
            return {
                "ru": f"Похоже, вопрос может быть про {first_topic} или {second_topic}. Добавь одно уточнение, например: «как купить меч» или «как атаковать мечом».",
                "en": f"This could be about {first_topic} or {second_topic}. Add a detail, such as “buy a sword” or “attack with a sword.”",
                "es": f"Puede ser sobre {first_topic} o {second_topic}. Añade un detalle para aclararlo.",
                "zh": f"这个问题可能是关于{first_topic}或{second_topic}。请再补充一点信息。",
                "ja": f"{first_topic}か{second_topic}についての質問かもしれません。もう少し詳しく教えてください。",
                "fr": f"Ta question concerne peut-être {first_topic} ou {second_topic}. Ajoute un détail pour préciser.",
                "sr": f"Pitanje je možda o temi {first_topic} ili {second_topic}. Dodaj još neki detalj."
            }[lang]
        helper_last_intent = intent_id
        return translations.get(lang, translations["en"])

    # Живые ответы используют состояние именно этого сохранения.
    dynamic_intents = {
        "health_status": ("здоров", "сколько хп", "health", "生命值", "体力"),
        "inventory_status": ("что у меня", "сколько предмет", "инвентар", "inventory status", "背包里", "持ち物"),
        "money_status": ("сколько денег", "баланс", "gromki", "money", "所持金", "余额"),
        "location_status": ("где я", "мое место", "моя глубина", "where am i", "当前位置", "現在地")
    }
    for intent_id, keywords in dynamic_intents.items():
        if any(keyword in q for keyword in keywords):
            helper_last_intent = intent_id
            if intent_id == "health_status":
                player_index = 1 if netplay.role == "client" and netplay.player_index == 1 else 0
                return {"ru": f"У тебя {player_health[player_index]} из {MAX_PLAYER_HEALTH} здоровья.",
                        "en": f"You have {player_health[player_index]} of {MAX_PLAYER_HEALTH} health.",
                        "es": f"Tienes {player_health[player_index]} de {MAX_PLAYER_HEALTH} de salud.",
                        "zh": f"你的生命值是 {player_health[player_index]}/{MAX_PLAYER_HEALTH}。",
                        "ja": f"体力は {player_health[player_index]}/{MAX_PLAYER_HEALTH} です。",
                        "fr": f"Tu as {player_health[player_index]} points de vie sur {MAX_PLAYER_HEALTH}.",
                        "sr": f"Imaš {player_health[player_index]} od {MAX_PLAYER_HEALTH} zdravlja."}[lang]
            if intent_id == "money_status":
                return {"ru": f"Сейчас у тебя {gromki} Громок.", "en": f"You have {gromki} Gromki.",
                        "es": f"Tienes {gromki} Gromki.", "zh": f"你有 {gromki} Gromki。",
                        "ja": f"Gromkiを{gromki}持っています。", "fr": f"Tu as {gromki} Gromki.",
                        "sr": f"Imaš {gromki} Gromkija."}[lang]
            if intent_id == "inventory_status":
                found = [(RESOURCE_NAMES[lang].get(item, item), amount)
                         for item, amount in inventory.items() if amount > 0]
                if not found:
                    return {"ru": "Инвентарь пока пуст. Рюкзак открывается кнопкой справа.",
                            "en": "Your inventory is empty. Open it with the backpack button on the right.",
                            "es": "Tu inventario está vacío. Ábrelo con el botón de la mochila.",
                            "zh": "背包目前是空的，点击右侧背包按钮查看。",
                            "ja": "持ち物は空です。右側のバッグボタンで開けます。",
                            "fr": "Ton inventaire est vide. Ouvre-le avec le bouton du sac à droite.",
                            "sr": "Inventar je prazan. Otvori ga dugmetom za ranac sa desne strane."}[lang]
                summary = ", ".join(f"{name} ×{amount}" for name, amount in found[:5])
                more = len(found) - min(5, len(found))
                if more:
                    summary += {"ru": f" и ещё {more}", "en": f" and {more} more", "es": f" y {more} más",
                               "zh": f" 等另外{more}种", "ja": f" 他{more}種類", "fr": f" et {more} autres",
                               "sr": f" i još {more}"}[lang]
                return {"ru": f"В инвентаре есть: {summary}.", "en": f"In your inventory: {summary}.",
                        "es": f"En tu inventario: {summary}.", "zh": f"背包里有：{summary}。",
                        "ja": f"持ち物：{summary}。", "fr": f"Dans ton inventaire : {summary}.",
                        "sr": f"U inventaru imaš: {summary}."}[lang]
            player_index = 1 if netplay.role == "client" and netplay.player_index == 1 else 0
            px, py = (player2_x, player2_y) if player_index else (player_x, player_y)
            zone_name = {"surface": {"ru": "поверхности", "en": "the surface", "es": "la superficie", "zh": "地面", "ja": "地上",
                                      "fr": "à la surface", "sr": "na površini"},
                         "mine": {"ru": "шахте", "en": "the mine", "es": "la mina", "zh": "矿井", "ja": "鉱山",
                                  "fr": "dans la mine", "sr": "u rudniku"},
                         "ocean": {"ru": "океане", "en": "the ocean", "es": "el océano", "zh": "海洋", "ja": "海",
                                   "fr": "dans l'océan", "sr": "na okeanu"}}[current_zone][lang]
            coords = f"X {px // BLOCK_SIZE}, Y {py // BLOCK_SIZE}"
            depth = f"; {mine_depth_tier(px) + 1}" if current_zone == "mine" else ""
            return {"ru": f"Ты сейчас в {zone_name}. Координаты: {coords}. Уровень глубины: {depth.strip('; ') if depth else 'не шахта'}.",
                    "en": f"You are in {zone_name}. Coordinates: {coords}. Mine level: {depth.strip('; ') if depth else 'not in the mine'}.",
                    "es": f"Estás en {zone_name}. Coordenadas: {coords}. Nivel de mina: {depth.strip('; ') if depth else 'no estás en la mina'}.",
                    "zh": f"你现在位于{zone_name}。坐标：{coords}。矿井层级：{depth.strip('; ') if depth else '不在矿井'}。",
                    "ja": f"現在は{zone_name}です。座標：{coords}。鉱山レベル：{depth.strip('; ') if depth else '鉱山の外'}。"}[lang]

    # Приветствия и благодарности важнее памяти о предыдущем вопросе.
    if any(word in q for word in ("привет", "здравствуй", "hello", "hi", "hola", "你好", "こんにちは")):
        helper_last_intent = ""
        return {"ru": "Привет! Могу подсказать про управление, шахту и руды, блоки, животных, океан, инвентарь, настройки, моды и сетевую игру.",
                "en": "Hi! Ask me about controls, mining, blocks, animals, the ocean, inventory, settings, mods, or multiplayer.",
                "es": "¡Hola! Pregunta sobre controles, minería, bloques, animales, océano, inventario, ajustes o multijugador.",
                "zh": "你好！可以问操作、采矿、方块、动物、海洋、背包、设置、模组或多人游戏。",
                "ja": "こんにちは！操作、採掘、ブロック、動物、海、持ち物、設定、MOD、通信プレイについて聞いてください。"}[lang]
    if any(word in q for word in ("спасибо", "благодар", "thanks", "thank you", "gracias", "谢谢", "ありがとう")):
        helper_last_intent = ""
        return {"ru": "Пожалуйста! Если появится ещё вопрос по игре — спрашивай.",
                "en": "You're welcome! Ask me if you have another question about the game.",
                "es": "¡De nada! Pregúntame si tienes otra duda sobre el juego.",
                "zh": "不客气！还有游戏问题的话，随时问我。",
                "ja": "どういたしまして！ゲームについて知りたいことがあれば聞いてください。"}[lang]
    if any(word in q for word in ("пока", "до свидания", "bye", "goodbye", "adiós", "再见", "さようなら")):
        helper_last_intent = ""
        return {"ru": "Пока! Удачной игры!", "en": "Goodbye! Have fun playing!",
                "es": "¡Adiós! ¡Que te diviertas!", "zh": "再见，祝你玩得开心！",
                "ja": "またね！ゲームを楽しんでください！"}[lang]

    # Короткий уточняющий вопрос продолжает последнюю тему, вместо случайного ответа.
    if helper_last_intent and (len(tokens) <= 3 or any(word in q for word in ("почему", "а дальше", "ещё", "не понял", "а как", "why", "more", "どうして"))):
        topic_names = {
            "controls": {"ru": "управлении", "en": "controls", "es": "los controles", "zh": "操作", "ja": "操作"},
            "blocks": {"ru": "блоках", "en": "blocks", "es": "los bloques", "zh": "方块", "ja": "ブロック"},
            "mining": {"ru": "добыче руды", "en": "mining", "es": "la minería", "zh": "采矿", "ja": "採掘"},
            "fishing": {"ru": "рыбалке", "en": "fishing", "es": "la pesca", "zh": "钓鱼", "ja": "釣り"},
            "combat": {"ru": "сражениях", "en": "combat", "es": "el combate", "zh": "战斗", "ja": "戦闘"},
            "flower": {"ru": "одуванчиках", "en": "dandelions", "es": "los dientes de león", "zh": "蒲公英", "ja": "タンポポ"},
            "spider": {"ru": "пауке и паутине", "en": "the spider and web", "es": "la araña y la telaraña", "zh": "蜘蛛和蛛网", "ja": "クモと糸"},
            "parrot": {"ru": "попугаях", "en": "parrots", "es": "los loros", "zh": "鹦鹉", "ja": "オウム"},
            "animals": {"ru": "животных и еде", "en": "animals and food", "es": "animales y comida", "zh": "动物和食物", "ja": "動物と食べ物"},
            "food": {"ru": "еде и восстановлении здоровья", "en": "food and healing", "es": "comida y salud", "zh": "食物和恢复生命", "ja": "食べ物と回復"},
            "inventory": {"ru": "инвентаре", "en": "inventory", "es": "el inventario", "zh": "背包", "ja": "持ち物"},
            "saving": {"ru": "сохранениях и ошибках", "en": "saving and errors", "es": "guardado y errores", "zh": "保存和错误", "ja": "保存とエラー"},
            "coordinates": {"ru": "координатах и глубине", "en": "coordinates and depth", "es": "coordenadas y profundidad", "zh": "坐标和深度", "ja": "座標と深さ"},
            "worlds": {"ru": "мирах", "en": "worlds", "es": "los mundos", "zh": "世界", "ja": "ワールド"},
            "multiplayer": {"ru": "сетевой игре", "en": "multiplayer", "es": "el multijugador", "zh": "多人游戏", "ja": "通信プレイ"},
            "mods": {"ru": "модах", "en": "mods", "es": "los mods", "zh": "模组", "ja": "MOD"},
            "settings": {"ru": "настройках", "en": "settings", "es": "los ajustes", "zh": "设置", "ja": "設定"},
            "shop": {"ru": "магазине", "en": "the shop", "es": "la tienda", "zh": "商店", "ja": "店"},
            "pet": {"ru": "глажении персонажей", "en": "petting characters", "es": "acariciar personajes", "zh": "抚摸角色", "ja": "キャラクターを撫でること"},
            "health_status": {"ru": "твоём здоровье", "en": "your health", "es": "tu salud", "zh": "你的生命值", "ja": "体力"},
            "money_status": {"ru": "твоём балансе", "en": "your balance", "es": "tu saldo", "zh": "你的余额", "ja": "所持金"},
            "inventory_status": {"ru": "твоих предметах", "en": "your items", "es": "tus objetos", "zh": "你的物品", "ja": "持ち物"},
            "location_status": {"ru": "твоём местоположении", "en": "your location", "es": "tu ubicación", "zh": "你的位置", "ja": "現在地"}
        }
        topic = topic_names.get(helper_last_intent, {}).get(lang, "прошлой теме" if lang == "ru" else "the previous topic")
        return {"ru": f"Помню, мы говорили про {topic}. Спроси точнее: как это найти, использовать или исправить?",
                "en": f"I remember we were talking about {topic}. Ask what you want to know: how to find, use, or fix it.",
                "es": f"Recuerdo que hablábamos de {topic}. Pregunta cómo encontrarlo, usarlo o arreglarlo.",
                "zh": f"我记得我们刚才在聊{topic}。你想知道如何找到、使用还是修复它？",
                "ja": f"{topic}について話していたのを覚えています。見つけ方、使い方、直し方のどれを知りたいですか？"}[lang]

    return {"ru": "Пока не нашёл подходящий ответ. Попробуй добавить слово о теме: «кирка», «паук», «блок», «магазин» или «сервер». Можно писать своими словами и с небольшими опечатками.",
            "en": "I couldn't find a matching answer yet. Add a topic word like pickaxe, spider, block, shop, or server. You can phrase it your own way and make small typos.",
            "es": "Aún no encuentro la respuesta. Añade una palabra como pico, araña, bloque, tienda o servidor.",
            "zh": "暂时没有找到答案。试着加入镐子、蜘蛛、方块、商店或服务器等词。",
            "ja": "答えが見つかりませんでした。ツルハシ、クモ、ブロック、店、サーバーなどの言葉を加えてください。"}[lang]


def draw_game_helper():
    """Показывает созданное автором окно для вопроса и ответа помощника."""
    if not helper_open:
        return
    panel_width, panel_height = u(900), u(506)
    panel = pygame.transform.scale(textures["text_window"], (panel_width, panel_height))
    panel_rect = panel.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    screen.blit(panel, panel_rect)
    assistant_portrait = pygame.transform.scale(textures["assistant_icon"], (u(105), u(105)))
    screen.blit(assistant_portrait, (panel_rect.x + u(36), panel_rect.y + u(250)))
    helper_titles = {"ru": "ПОМОЩНИК ПО ИГРЕ", "en": "GAME HELPER", "es": "AYUDA DEL JUEGO",
                     "zh": "游戏助手", "ja": "ゲームヘルパー"}
    title = font_menu.render(helper_titles[lang], True, (28, 34, 42))
    screen.blit(title, (panel_rect.centerx - title.get_width() // 2, panel_rect.y + u(24)))
    prompts = {"ru": "Вопрос:", "en": "Your question:", "es": "Tu pregunta:",
               "zh": "你的问题：", "ja": "質問："}
    prompt = font.render(prompts[lang], True, (35, 55, 70))
    screen.blit(prompt, (panel_rect.x + u(190), panel_rect.y + u(270)))
    cursor = "|" if int(time.time() * 2) % 2 else ""
    shown_question = helper_question + cursor
    while shown_question and font.size(shown_question)[0] > u(560):
        shown_question = shown_question[1:]
    question_hints = {"ru": "Напиши вопрос и нажми Enter", "en": "Type a question and press Enter",
                      "es": "Escribe una pregunta y pulsa Enter", "zh": "输入问题并按回车",
                      "ja": "質問を入力してEnterを押す"}
    question_surface = font.render(shown_question or question_hints[lang], True, (35, 40, 48))
    if question_surface.get_width() > u(560):
        question_surface = pygame.transform.smoothscale(
            question_surface, (u(560), max(1, round(question_surface.get_height() * u(560) / question_surface.get_width()))))
    screen.blit(question_surface, (panel_rect.x + u(205), panel_rect.y + u(294)))

    # Ответ должен находиться внутри белой части рамки, а не поверх прозрачного фона.
    # Светлая подложка также сохраняет контраст, если текстура окна изменится.
    answer_rect = pygame.Rect(panel_rect.x + u(172), panel_rect.y + u(322),
                              panel_width - u(220), u(90))
    pygame.draw.rect(screen, (255, 255, 255), answer_rect, border_radius=u(5))
    pygame.draw.rect(screen, (205, 210, 215), answer_rect, max(1, u(1)), border_radius=u(5))
    helper_font = pygame.font.SysFont({"zh": "Microsoft YaHei", "ja": "Yu Gothic UI"}.get(lang), u(17))
    answer_words = helper_answer.split()
    lines, current = [], ""
    text_x = answer_rect.x + u(12)
    max_width = answer_rect.width - u(24)
    for word in answer_words:
        if helper_font.size(word)[0] > max_width:
            if current:
                lines.append(current)
                current = ""
            piece = ""
            for character in word:
                candidate_piece = piece + character
                if piece and helper_font.size(candidate_piece)[0] > max_width:
                    lines.append(piece)
                    piece = character
                else:
                    piece = candidate_piece
            if piece:
                lines.append(piece)
            continue
        candidate = f"{current} {word}".strip()
        if current and helper_font.size(candidate)[0] > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    line_step = u(18)
    max_lines = max(1, (answer_rect.height - u(14)) // line_step)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        last_line = lines[-1]
        while last_line and helper_font.size(last_line + "…")[0] > max_width:
            last_line = last_line[:-1]
        lines[-1] = last_line.rstrip() + "…"
    previous_clip = screen.get_clip()
    screen.set_clip(answer_rect)
    for index, line in enumerate(lines):
        rendered = helper_font.render(line, True, (30, 34, 40))
        screen.blit(rendered, (text_x, answer_rect.y + u(7) + index * line_step))
    screen.set_clip(previous_clip)
    footers = {"ru": "Enter — спросить   Esc — закрыть", "en": "Enter — ask   Esc — close",
               "es": "Enter — preguntar   Esc — cerrar", "zh": "Enter —提问   Esc —关闭",
               "ja": "Enter — 質問   Esc — 閉じる"}
    footer = font.render(footers[lang], True, (35, 40, 48))
    footer_rect = footer.get_rect(center=(panel_rect.centerx, panel_rect.y + u(433))).inflate(u(14), u(8))
    pygame.draw.rect(screen, (255, 255, 255), footer_rect, border_radius=u(4))
    screen.blit(footer, footer.get_rect(center=footer_rect.center))


# Главный цикл: игра обновляется, пока игрок не закроет окно.
def draw_game_ui():
    """Показывает баланс, инвентарь и кнопки продажи."""
    global sell_buttons, sell_all_buttons
    labels = INVENTORY_LABELS[lang]
    sell_buttons = {}
    sell_all_buttons = {}
    if inventory_open:
        panel = pygame.Surface((u(500), HEIGHT), pygame.SRCALPHA)
        panel.fill((35, 38, 43, 245))
        panel_x = WIDTH - u(500)
        screen.blit(panel, (panel_x, 0))
        title = font.render(LANG_PACK[lang]["inv_title"], True, (255, 255, 255))
        screen.blit(title, (panel_x + u(20), u(30)))
        category_names = {
            "ru": ("Шахта", "Океан", "Поверхность", "Все"), "en": ("Mine", "Ocean", "Surface", "All"),
            "es": ("Mina", "Océano", "Superficie", "Todo"), "zh": ("矿井", "海洋", "地表", "全部"),
            "ja": ("鉱山", "海", "地上", "全部")
        }[lang]
        for category, rect, label in zip(("mine", "ocean", "surface", "all"),
                                         get_inventory_category_rects(), category_names):
            pygame.draw.rect(screen, (65, 115, 155) if category == inventory_category else (65, 68, 75),
                             rect, border_radius=u(4))
            category_text = font_sub.render(label, True, (255, 255, 255))
            screen.blit(category_text, (rect.centerx - category_text.get_width() // 2,
                                        rect.centery - category_text.get_height() // 2))

    balance = font.render(LANG_PACK[lang]["balance"].format(gromki), True, (255, 220, 80))
    balance_shadow = font.render(LANG_PACK[lang]["balance"].format(gromki), True, (45, 45, 45))
    screen.blit(balance_shadow, (u(17), u(13)))
    screen.blit(balance, (u(16), u(12)))
    health_label = font.render(LANG_PACK[lang]["player_hp"].format(player_health[0]), True, (255, 110, 110))
    screen.blit(health_label, (u(16), u(42)))
    if player_count == 2:
        health2_label = font.render(LANG_PACK[lang]["player_hp"].format(player_health[1]), True, (110, 205, 255))
        screen.blit(health2_label, (u(16), u(63)))
    coordinate_player_x, coordinate_player_y = (player2_x, player2_y) if (
        netplay.role == "client" and netplay.player_index == 1) else (player_x, player_y)
    coordinate_parts = {
        "ru": f"Координаты: X {coordinate_player_x // BLOCK_SIZE}, Y {coordinate_player_y // BLOCK_SIZE}",
        "en": f"Coordinates: X {coordinate_player_x // BLOCK_SIZE}, Y {coordinate_player_y // BLOCK_SIZE}",
        "es": f"Coordenadas: X {coordinate_player_x // BLOCK_SIZE}, Y {coordinate_player_y // BLOCK_SIZE}",
        "zh": f"坐标：X {coordinate_player_x // BLOCK_SIZE}, Y {coordinate_player_y // BLOCK_SIZE}",
        "ja": f"座標：X {coordinate_player_x // BLOCK_SIZE}, Y {coordinate_player_y // BLOCK_SIZE}"
    }
    if current_zone == "mine":
        depth_level = mine_depth_tier(coordinate_player_x) + 1
        depth_labels = {"ru": f"Глубина шахты: уровень {depth_level}",
                        "en": f"Mine depth: level {depth_level}",
                        "es": f"Profundidad: nivel {depth_level}",
                        "zh": f"矿井深度：第 {depth_level} 层",
                        "ja": f"鉱山の深さ：レベル {depth_level}"}
        coordinate_parts[lang] += "  |  " + depth_labels[lang]
    coordinate_surface = font_sub.render(coordinate_parts[lang], True, (220, 240, 255))
    coordinate_bg = pygame.Rect(u(12), u(86), coordinate_surface.get_width() + u(14),
                                coordinate_surface.get_height() + u(8))
    pygame.draw.rect(screen, (25, 31, 39), coordinate_bg, border_radius=u(4))
    screen.blit(coordinate_surface, (coordinate_bg.x + u(7), coordinate_bg.y + u(4)))
    notice_y = u(116)
    if netplay.role == "host" and network_notice:
        title = font_sub.render(LANG_PACK[lang]["network_host_address"], True, (150, 240, 180))
        screen.blit(title, (u(16), notice_y))
        notice_y += u(20)
        for address_line in network_notice.splitlines():
            address_surface = font_sub.render(address_line, True, (180, 230, 255))
            screen.blit(address_surface, (u(16), notice_y))
            notice_y += u(19)
    screen.blit(textures["inventory_button"], inventory_button_rect)
    if not inventory_open:
        helper_label = font_sub.render("H — ПОМОЩНИК" if lang == "ru" else "H — GAME HELPER", True, (255, 255, 255))
        pygame.draw.rect(screen, (45, 72, 95), helper_button_rect, border_radius=u(6))
        assistant_button_icon = pygame.transform.scale(textures["assistant_icon"], (u(42), u(42)))
        screen.blit(assistant_button_icon, (helper_button_rect.x + u(6),
                                            helper_button_rect.centery - assistant_button_icon.get_height() // 2))
        screen.blit(helper_label, (helper_button_rect.x + u(54),
                                   helper_button_rect.centery - helper_label.get_height() // 2))
    if current_zone == "surface":
        screen.blit(textures["store_building"], store_hud_rect)
        store_hint = font_sub.render(LANG_PACK[lang]["store_name"], True, (255, 255, 255))
        screen.blit(store_hint, (store_hud_rect.centerx - store_hint.get_width() // 2,
                                 store_hud_rect.bottom + u(2)))
    screen.blit(textures["exit"], exit_button_rect.topleft)

    if inventory_open:
        visible_rows = max(1, (HEIGHT - u(80) - u(110)) // u(125) + 1)
        inventory_items = filtered_inventory_items()
        if not inventory_items:
            empty_text = font_sub.render("В этой категории пока пусто" if lang == "ru" else "This category is empty",
                                         True, (230, 230, 230))
            screen.blit(empty_text, (WIDTH - u(485), u(126)))
        for index, (item, amount) in enumerate(inventory_items):
            column, actual_row = index % 5, index // 5
            row = actual_row - inventory_scroll_row
            if not 0 <= row < visible_rows:
                continue
            x, y = WIDTH - u(485) + column * u(96), u(110) + row * u(125)
            screen.blit(inventory_slot_texture, (x, y))

            icon = pygame.transform.scale(textures[item], (u(44), u(44)))
            screen.blit(icon, (x + (u(88) - icon.get_width()) // 2, y + u(8)))
            if inventory_category == "mine":
                depth_badge = font_sub.render(f"Г{mining_depth_for_item(item)}" if lang == "ru"
                                              else f"D{mining_depth_for_item(item)}", True, (255, 230, 90))
                screen.blit(depth_badge, (x + u(3), y + u(3)))

            label_lines = []
            current_line = ""
            for word in labels[item].split():
                candidate = f"{current_line} {word}".strip()
                if current_line and font_sub.size(candidate)[0] > u(80):
                    label_lines.append(current_line)
                    current_line = word
                else:
                    current_line = candidate
            if current_line:
                label_lines.append(current_line)
            for line_index, line in enumerate(label_lines[:2]):
                label = font_sub.render(line, True, (30, 25, 22))
                screen.blit(label, (x + (u(88) - label.get_width()) // 2, y + u(56) + line_index * u(13)))

            amount_text = font_sub.render(f"x{amount}", True, (30, 25, 22))
            screen.blit(amount_text, (x + (u(88) - amount_text.get_width()) // 2, y + u(84)))
            is_melon = item == "melon"
            is_mod_food = item in MOD_FOOD_ITEMS
            is_grind = item == "bone" and amount >= 2
            is_craft = item == "raspberry" and inventory["gelatin"] > 0
            action_key = ("eat" if is_melon or is_mod_food else "grind" if is_grind else
                          "craft_marmalade" if is_craft else "sell")
            action_color = (45, 125, 65) if is_melon or is_mod_food or is_craft else (110, 80, 38) if is_grind else (110, 45, 38)
            is_sell_button = action_key == "sell"
            button = pygame.Rect(x + (u(2) if is_sell_button else u(15)), y + u(106),
                                 u(84) if is_sell_button else u(58), u(18))
            if is_sell_button:
                # Две компактные кнопки помещаются рядом внутри ячейки.
                button.width = u(40)
                button.height = u(20)
                pygame.draw.rect(screen, (145, 55, 45), button, border_radius=u(3))
                button_text = font_sub.render(LANG_PACK[lang]["sell"], True, (255, 255, 255))
                if button_text.get_width() > button.width - u(4):
                    button_text = pygame.transform.smoothscale(
                        button_text, (button.width - u(4), button_text.get_height()))
                screen.blit(button_text, (button.centerx - button_text.get_width() // 2,
                                          button.centery - button_text.get_height() // 2))
                sell_all = pygame.Rect(button.right + u(3), button.y, u(40), u(20))
                pygame.draw.rect(screen, (180, 90, 35), sell_all, border_radius=u(3))
                all_text = font_sub.render(LANG_PACK[lang]["sell_all"], True, (255, 255, 255))
                if all_text.get_width() > sell_all.width - u(4):
                    all_text = pygame.transform.smoothscale(all_text, (sell_all.width - u(4), all_text.get_height()))
                screen.blit(all_text, (sell_all.centerx - all_text.get_width() // 2,
                                       sell_all.centery - all_text.get_height() // 2))
                sell_all_buttons[item] = sell_all
            else:
                pygame.draw.rect(screen, action_color, button, border_radius=u(3))
                button_text = font_sub.render(LANG_PACK[lang][action_key], True, (255, 255, 255))
                screen.blit(button_text, (button.centerx - button_text.get_width() // 2, button.y + u(2)))
            sell_buttons[item] = button

        total_rows = (len(inventory_items) + 4) // 5
        if total_rows > visible_rows:
            hint = font_sub.render("Колесо мыши — листать" if lang == "ru" else "Mouse wheel — scroll", True, (230, 230, 230))
            screen.blit(hint, (WIDTH - u(485), HEIGHT - u(28)))

    if not inventory_open:
        if current_zone == "surface":
            if selected_tool == "block":
                building_hint = {
                    "ru": "6 — блоки | клик — поставить | добывай блоки в шахте",
                    "en": "6 — blocks | click to place | mine blocks in the cave",
                    "es": "6 — bloques | clic para colocar | mina bloques en la cueva",
                    "zh": "按6选方块，点击放置；在矿井采集方块",
                    "ja": "6でブロック、クリックで設置。鉱山で採掘できます"
                }[lang]
                hint = font_sub.render(building_hint, True, (255, 255, 255))
                screen.blit(hint, (u(20), u(108)))
            if abs(player_x - mine_entrance_rect.centerx) <= u(180):
                hint = font.render(LANG_PACK[lang]["enter_mine"], True, (255, 255, 255))
                screen.blit(hint, (mine_entrance_rect.centerx - camera_x - hint.get_width() // 2,
                                   u(450) - surface_camera_y))
            for obj in visible_surface_objects(camera_x):
                if not obj["active"] or abs(player_x - obj["x"]) > u(145):
                    continue
                hint_key = "pig_hint" if obj["kind"] == "pig" else "gather_hint"
                hint = font_sub.render(LANG_PACK[lang][hint_key], True, (255, 255, 255))
                rect = surface_object_rect(obj).move(-camera_x, -surface_camera_y)
                screen.blit(hint, (rect.centerx - hint.get_width() // 2, rect.y - hint.get_height() - u(3)))
        elif abs(player_x - mine_entrance_rect.centerx) <= u(180):
            hint = font.render(LANG_PACK[lang]["leave_mine"], True, (255, 255, 255))
            screen.blit(hint, (u(20), u(450)))
        if last_action_text:
            msg = font.render(last_action_text, True, (255, 255, 120))
            screen.blit(msg, (u(20), max(notice_y, u(88))))
inventory_button_rect = pygame.Rect(WIDTH - u(70), u(8), u(60), u(60))
store_hud_rect = pygame.Rect(u(24), HEIGHT - u(155), u(90), u(90))
touch_left_rect = pygame.Rect(u(24), HEIGHT - u(255), u(82), u(82))
touch_right_rect = pygame.Rect(u(116), HEIGHT - u(255), u(82), u(82))
touch_jump_rect = pygame.Rect(WIDTH - u(198), HEIGHT - u(145), u(82), u(82))
touch_action_rect = pygame.Rect(WIDTH - u(106), HEIGHT - u(145), u(82), u(82))
touch_jump_requested = False


def draw_touch_controls():
    """Large tap controls for phones and tablets in the browser build."""
    buttons = (
        (touch_left_rect, "◀"),
        (touch_right_rect, "▶"),
        (touch_jump_rect, "▲"),
        (touch_action_rect, "E" if current_zone != "ocean" else "R"),
    )
    for rect, label in buttons:
        pygame.draw.rect(screen, (26, 32, 40), rect, border_radius=u(12))
        pygame.draw.rect(screen, (230, 230, 220), rect, max(2, u(2)), border_radius=u(12))
        label_surface = font_menu.render(label, True, (255, 255, 255))
        screen.blit(label_surface, (rect.centerx - label_surface.get_width() // 2,
                                   rect.centery - label_surface.get_height() // 2))
    action_caption = font_sub.render("ДЕЙСТВИЕ" if lang == "ru" else "ACTION", True, (255, 255, 255))
    screen.blit(action_caption, (touch_action_rect.centerx - action_caption.get_width() // 2,
                                 touch_action_rect.bottom + u(3)))
    jump_caption = font_sub.render("ПРЫЖОК" if lang == "ru" else "JUMP", True, (255, 255, 255))
    screen.blit(jump_caption, (touch_jump_rect.centerx - jump_caption.get_width() // 2,
                               touch_jump_rect.bottom + u(3)))


def toggle_fullscreen():
    global display_surface, is_fullscreen
    is_fullscreen = not is_fullscreen
    if is_fullscreen:
        try:
            display_surface = set_borderless_fullscreen()
        except pygame.error:
            display_surface = pygame.display.set_mode(DISPLAY_SIZE, pygame.FULLSCREEN)
    else:
        display_surface = set_maximized_window()
    save_game_settings()


def set_master_volume(value):
    global master_volume
    master_volume = max(0.0, min(1.0, round(value / 100, 2)))
    apply_master_volume()
    save_game_settings()


NETWORK_SYNC_FIELDS = (
    "player_x", "player_y", "player2_x", "player2_y", "player_is_jumping", "player2_is_jumping",
    "y_velocity", "player2_y_velocity", "player_facing_right", "player2_facing_right", "player_names", "current_zone",
    "gromki", "inventory", "has_iron_pickaxe", "has_gold_pickaxe", "has_abyss_pickaxe", "has_wood_sword", "has_stone_sword", "has_iron_sword",
    "selected_tool", "selected_store_item", "flashlight_on", "player_health", "mine_experience", "last_action_text", "camera_x",
    "mining_animation_started",
    "mineral_deposits", "surface_chunks", "collapse_stage", "collapse_started_at", "collapse_wall_x",
    "world_blocks",
    "collapse_boulder_count", "collapse_top_count", "collapse_small_stones", "collapse_boulders",
    "collapse_next_trigger_x", "dandelions", "spiders", "web_projectiles", "pet_effects",
    "player_slowed_until", "player_frozen_until", "next_spider_spawn_time",
    "abyss_black_hole", "melon_speed_until",
    "next_ore_chunk_x", "last_mine_refresh_time", "next_dandelion_spawn_time",
    "fishing_state", "fishing_bite_at"
)


def encode_network_value(value):
    if isinstance(value, pygame.Rect):
        return {"__rect__": [value.x, value.y, value.width, value.height]}
    if isinstance(value, dict):
        return {"__map__": [[encode_network_value(key), encode_network_value(item)]
                            for key, item in value.items()]}
    if isinstance(value, (list, tuple)):
        return [encode_network_value(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return None


def decode_network_value(value):
    if isinstance(value, dict):
        if "__rect__" in value:
            return pygame.Rect(*value["__rect__"])
        if "__map__" in value:
            return {decode_network_value(key): decode_network_value(item)
                    for key, item in value["__map__"]}
        return {key: decode_network_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [decode_network_value(item) for item in value]
    return value


def capture_network_state(full=False):
    state = {name: globals()[name] for name in NETWORK_SYNC_FIELDS}
    if not full:
        snapshot_camera_x = int(camera_x)
        first_chunk = max(0, snapshot_camera_x // SURFACE_CHUNK_WIDTH - 2)
        last_chunk = (snapshot_camera_x + WIDTH) // SURFACE_CHUNK_WIDTH + 2
        state["surface_chunks"] = {index: surface_chunks[index]
                                   for index in range(first_chunk, last_chunk + 1)
                                   if index in surface_chunks}
        state["mineral_deposits"] = [deposit for deposit in mineral_deposits
                                     if camera_x - WIDTH <= deposit["rect"].x <= camera_x + WIDTH * 2]
    return {name: encode_network_value(value) for name, value in state.items()}


def apply_network_state(snapshot):
    for name in NETWORK_SYNC_FIELDS:
        if name in snapshot:
            globals()[name] = decode_network_value(snapshot[name])


def load_server_world():
    global player_count
    try:
        with open(server_world_path, "r", encoding="utf-8") as world_file:
            apply_network_state(json.load(world_file))
        player_count = 2
        return True
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return False


def save_server_world():
    try:
        os.makedirs(save_root, exist_ok=True)
        temporary_path = server_world_path + ".tmp"
        with open(temporary_path, "w", encoding="utf-8") as world_file:
            json.dump(capture_network_state(full=True), world_file, ensure_ascii=False)
        os.replace(temporary_path, server_world_path)
        return True
    except OSError as error:
        log_system_event("SERVER SAVE ERROR", str(error))
        return False


def authenticate_network_user(username, password):
    """Registers a new game nickname or checks the saved password for that name."""
    username = str(username).strip()
    password = str(password)
    if not 3 <= len(username) <= 16 or not all(character.isalnum() or character == "_" for character in username):
        return False, "Ник: 3–16 букв, цифр или знаков _.", ""
    if not 6 <= len(password) <= 128:
        return False, "Пароль должен быть длиной от 6 до 128 знаков.", ""
    account_key = username.casefold()
    with server_accounts_lock:
        try:
            with open(server_accounts_path, "r", encoding="utf-8") as accounts_file:
                accounts = json.load(accounts_file)
            if not isinstance(accounts, dict):
                accounts = {}
        except (OSError, ValueError, json.JSONDecodeError):
            accounts = {}
        account = accounts.get(account_key)
        if account:
            try:
                salt = bytes.fromhex(account["salt"])
                saved_hash = bytes.fromhex(account["password_hash"])
            except (KeyError, TypeError, ValueError):
                return False, "Не удалось прочитать учётную запись.", ""
            attempt = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260_000)
            if not hmac.compare_digest(attempt, saved_hash):
                return False, "Этот ник уже занят. Проверь пароль.", ""
            return True, "", account.get("username", username)

        salt = secrets.token_bytes(16)
        password_hash = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 260_000)
        accounts[account_key] = {"username": username, "salt": salt.hex(),
                                 "password_hash": password_hash.hex()}
        try:
            os.makedirs(save_root, exist_ok=True)
            temporary_path = server_accounts_path + ".tmp"
            with open(temporary_path, "w", encoding="utf-8") as accounts_file:
                json.dump(accounts, accounts_file, ensure_ascii=False, indent=2)
            os.replace(temporary_path, server_accounts_path)
        except OSError:
            return False, "Не удалось сохранить аккаунт на компьютере сервера.", ""
        return True, "", username


netplay.authenticator = authenticate_network_user


def handle_network_command(command, player_index=1):
    global current_zone, player_x, player_y, player2_x, player2_y, player2_is_jumping, player2_y_velocity
    global player_is_jumping, y_velocity
    global fishing_state
    global flashlight_on, selected_store_item, has_iron_pickaxe, has_gold_pickaxe, has_wood_sword, has_stone_sword, has_iron_sword
    global gromki, last_action_text, last_mine_refresh_time
    action = command.get("action")
    if action == "tool":
        select_tool(command.get("tool", "empty"))
    elif action == "flashlight":
        if selected_tool == "flashlight" and flashlight_equipped:
            flashlight_on = not flashlight_on
        else:
            last_action_text = LANG_PACK[lang]["choose_flashlight"]
    elif action == "eat":
        eat_melon()
    elif action == "use_item":
        use_inventory_item(str(command.get("item", "")))
    elif action == "fish":
        fish_action()
    elif action == "interact":
        interacting_x = player_x if player_index == 0 else player2_x
        if current_zone == "surface":
            if interact_surface():
                return
            if abs(interacting_x - OCEAN_ACCESS_X) <= u(180):
                current_zone = "ocean"
                player_x, player2_x = u(300), u(390)
                player_y, player2_y = floor_y, floor_y
                player_is_jumping = player2_is_jumping = False
                y_velocity = player2_y_velocity = 0
                last_action_text = LANG_PACK[lang]["entered_ocean"]
            elif abs(interacting_x - mine_entrance_rect.centerx) <= u(180):
                current_zone = "mine"
                player_x, player2_x = mine_entrance_rect.right + u(15), mine_entrance_rect.right + u(110)
                player_y, player2_y = floor_y, floor_y
                player2_is_jumping, player2_y_velocity = False, 0
                last_mine_refresh_time = time.time()
                flashlight_on = False
                last_action_text = LANG_PACK[lang]["entered_mine"]
        elif current_zone == "ocean":
            fishing_state = "idle"
            current_zone = "surface"
            player_x, player2_x = OCEAN_ACCESS_X, OCEAN_ACCESS_X + u(90)
            player_y, player2_y = floor_y, floor_y
            player_is_jumping = player2_is_jumping = False
            y_velocity = player2_y_velocity = 0
            last_action_text = LANG_PACK[lang]["returned_ocean"]
        elif abs(interacting_x - mine_entrance_rect.centerx) <= u(180):
            current_zone = "surface"
            player_x, player2_x = mine_entrance_rect.right + u(15), mine_entrance_rect.right + u(110)
            player_y, player2_y = floor_y, floor_y
            player2_is_jumping, player2_y_velocity = False, 0
            flashlight_on = False
            last_action_text = LANG_PACK[lang]["returned_surface"]
    elif action == "world_click":
        world_x, world_y = int(command.get("x", 0)), int(command.get("y", 0))
        local_mouse = (world_x - camera_x, world_y)
        if current_zone == "mine":
            if not damage_other_player_at(local_mouse, camera_x, player_index):
                damage_boulder_at(local_mouse, camera_x) or damage_dandelion_at(local_mouse, camera_x)
        elif selected_tool == "block":
            place_stone_block(world_x, world_y, player_index)
        elif selected_tool == "pickaxe" and mine_placed_block(world_x, world_y):
            pass
        elif not damage_other_player_at(local_mouse, camera_x, player_index):
            damage_surface_pig_at(local_mouse, camera_x)
    elif action == "pet":
        pet_character_at(int(command.get("x", 0)), int(command.get("y", 0)), player_index)
    elif action == "sell":
        item = command.get("item", "")
        if item in inventory:
            use_inventory_item(item)
    elif action == "sell_all":
        item = command.get("item", "")
        if item in inventory:
            sell_all_inventory_item(item)
    elif action == "store_select" and command.get("item") in STORE_PRICES:
        selected_store_item = command["item"]
    elif action == "store_buy":
        item = command.get("item")
        if item in STORE_PRICES:
            selected_store_item = item
            if store_item_owned(item):
                last_action_text = LANG_PACK[lang]["store_item_owned"]
            elif buy_store_item(item):
                if item in ("sword", "stone_sword", "iron_sword"):
                    select_tool("sword")
                last_action_text = LANG_PACK[lang]["owned"]
            else:
                last_action_text = LANG_PACK[lang]["no_money"]


def update_network_play(now):
    global network_remote_keys, network_last_state_send
    for event in netplay.take_disconnect_events():
        slot = event.get("slot")
        connection_name = "server" if slot is None else f"игрок в сетевом слоте {slot}"
        log_system_event("DISCONNECT", f"{connection_name}: {event.get('reason', 'причина не указана')}")
    if netplay.role in ("host", "server"):
        if netplay.role == "host":
            network_remote_keys = {1: netplay.get_remote_keys(0)}
        else:
            network_remote_keys = {0: netplay.get_remote_keys(0), 1: netplay.get_remote_keys(1)}
        connected_names = netplay.get_client_names()
        active_slots = set(connected_names)
        for slot in active_slots - logged_network_slots:
            log_system_event("NETWORK CONNECT", f"Подключился сетевой игрок в слоте {slot}")
        logged_network_slots.intersection_update(active_slots)
        for slot, username in connected_names.items():
            player_index = 1 if netplay.role == "host" else slot
            if 0 <= player_index < len(player_names):
                player_names[player_index] = username
        for message in netplay.take_messages():
            if message.get("type") == "command":
                player_index = 1 if netplay.role == "host" else int(message.get("slot", 0))
                handle_network_command(message.get("data", {}), player_index)
        if netplay.connected and now - network_last_state_send >= 0.075:
            netplay.send({"type": "state", "data": capture_network_state()})
            network_last_state_send = now
    elif netplay.role == "client":
        keys = pygame.key.get_pressed()
        netplay.send({"type": "keys", "data": {
            "left": bool(keys[pygame.K_a]), "right": bool(keys[pygame.K_d]),
            "jump": bool(keys[pygame.K_SPACE])
        }})
        snapshot = netplay.take_state()
        if snapshot:
            apply_network_state(snapshot)


def run_dedicated_server():
    global player_count, physics_step
    if netplay.vpn_is_active(refresh=True):
        print(NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[15], flush=True)
        return
    player_count = 2
    load_server_world()
    player_count = 2
    netplay.host(max_clients=2, dedicated=True)
    print("Stickman in Mine server is running.", flush=True)
    if server_world_id:
        print(f"World: {server_world_id} (reusing this name loads its saved world).", flush=True)
    addresses = netplay.local_ip_details()
    if addresses:
        print("Connect using one of these addresses (Wi-Fi or Ethernet):", flush=True)
        for adapter, address in addresses:
            print(f"  {adapter}: {address}:{netplay.PORT}", flush=True)
    else:
        print("No network address found. Check that Wi-Fi or Ethernet is connected.", flush=True)
    print(f"For a different home, forward TCP port {netplay.PORT} on the router.", flush=True)
    print("Players: 2. Keep this window open; press Ctrl+C to stop the server.", flush=True)
    last_save = time.time()
    last_client_count = 0
    try:
        while True:
            now = time.time()
            update_network_play(now)
            if netplay.player_count != last_client_count:
                last_client_count = netplay.player_count
                print(f"Connected players: {last_client_count}/2", flush=True)
            if last_client_count:
                run_game_logic_and_graphics()
            if now - last_save >= 15:
                save_ok = save_progress()
                world_ok = save_server_world()
                log_system_event("SERVER AUTO SAVE", "Сохранение завершено" if save_ok and world_ok else "Не удалось сохранить серверный мир")
                last_save = now
            physics_step = min(max(clock.tick(60) / (1000 / 60), 0.05), 2.0)
    except KeyboardInterrupt:
        print("Saving server world...", flush=True)
    finally:
        save_progress()
        save_server_world()
        netplay.stop()
        pygame.quit()
        print("Server stopped.", flush=True)


def draw_store():
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    screen.blit(overlay, (0, 0))
    box = get_store_panel_rect()
    pygame.draw.rect(screen, (55, 60, 70), box, border_radius=u(12))
    title = font_menu.render(LANG_PACK[lang]["store_title"], True, (255, 255, 255))
    screen.blit(title, (box.centerx - title.get_width() // 2, box.y + u(35)))
    display_x = box.centerx - textures["store_display"].get_width() // 2
    display_y = box.y + u(80)
    screen.blit(textures["store_display"], (display_x, display_y))
    item_rects = get_store_item_rects()
    # Первые три товара уже нарисованы в store_display.png. Добавляем только новые мечи.
    for item in ("stone_sword", "iron_sword"):
        rect = item_rects[item]
        icon = textures[item]
        fit = min(u(60) / icon.get_width(), u(78) / icon.get_height())
        icon = pygame.transform.scale(icon, (max(1, round(icon.get_width() * fit)),
                                             max(1, round(icon.get_height() * fit))))
        screen.blit(icon, (rect.centerx - icon.get_width() // 2, rect.centery - icon.get_height() // 2))
    pygame.draw.rect(screen, (255, 190, 40), item_rects[selected_store_item], u(3), border_radius=u(3))
    fallback_names = {"stone_sword": "Каменный меч", "iron_sword": "Железный меч"}
    selected_name = LANG_PACK[lang].get(f"store_item_{selected_store_item}", fallback_names.get(selected_store_item, selected_store_item))
    name_text = selected_name
    if selected_store_item == "iron":
        name_text = LANG_PACK[lang]["iron_pick_name"]
    name = font.render(name_text, True, (255, 220, 100))
    screen.blit(name, (box.centerx - name.get_width() // 2, box.y + u(310)))
    already_owned = store_item_owned(selected_store_item)
    button_color = (70, 90, 70) if already_owned else (50, 130, 70)
    pygame.draw.rect(screen, button_color, graphics_store_buy_btn_rect, border_radius=u(8))
    button_text = (LANG_PACK[lang]["store_item_owned"] if already_owned else
                   LANG_PACK[lang]["buy"].format(STORE_PRICES[selected_store_item]))
    rendered = font_sub.render(button_text, True, (255, 255, 255))
    screen.blit(rendered, (graphics_store_buy_btn_rect.centerx - rendered.get_width() // 2,
                           graphics_store_buy_btn_rect.centery - rendered.get_height() // 2))
    close_text = font_sub.render(LANG_PACK[lang]["close"], True, (220, 220, 220))
    screen.blit(close_text, (box.centerx - close_text.get_width() // 2, box.y + u(430)))


async def main():
    global lang, gromki, has_iron_pickaxe, has_gold_pickaxe, has_wood_sword, current_graphics_store_open, inventory_open, inventory_scroll_row, inventory_category, last_action_text, current_zone, player_x, player2_x, player_y, player2_y, player_is_jumping, player2_is_jumping, selected_store_item, selected_tool, melon_speed_until, last_mine_refresh_time, player_count, y_velocity, player2_y_velocity, flashlight_on, physics_step, show_hitboxes, next_ore_chunk_x, network_join_address, network_username, network_password, network_input_focus, network_error, network_notice, player_names, helper_open, helper_question, helper_answer, fishing_state, fishing_bite_at, world_name_input, world_notice, world_scroll_offset, current_world_id, current_game_audio_track, touch_jump_requested
    state = "menu"
    running = True
    last_auto_save = time.time()
    await show_studio_splash()
    while running:
        update_game_sounds()
        if state != "game" and current_game_audio_track == "mine_footsteps":
            pygame.mixer.music.fadeout(100)
            current_game_audio_track = None
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if helper_open:
                    helper_open = False
                    pygame.key.stop_text_input()
                elif current_graphics_store_open:
                    current_graphics_store_open = False
                elif inventory_open:
                    inventory_open = False
                elif state == "player_select":
                    state = "menu"
                elif state == "world_select":
                    state = "player_select"
                    pygame.key.stop_text_input()
                elif state == "network_select":
                    state = "player_select"
                    pygame.key.stop_text_input()
                elif state == "settings":
                    state = "menu"
                elif state == "game":
                    save_progress()
                    netplay.stop()
                    state = "menu"
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                toggle_fullscreen()
            elif state == "world_select" and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    world_name_input = world_name_input[:-1]
                elif event.key == pygame.K_RETURN:
                    new_world_id = create_world(world_name_input)
                    if new_world_id and open_world(new_world_id):
                        configure_world_start()
                        player_count = 1
                        world_notice = ""
                        pygame.key.stop_text_input()
                        state = "game"
                    else:
                        world_notice = ("Введи название мира" if not world_name_input.strip() else
                                        "Не получилось создать мир") if lang == "ru" else "Enter a world name"
            elif state == "world_select" and event.type == pygame.TEXTINPUT:
                if event.text.isprintable() and len(world_name_input) < 32:
                    world_name_input += event.text
            elif event.type == pygame.MOUSEWHEEL and state == "world_select":
                mouse_x, mouse_y = to_game_position(pygame.mouse.get_pos())
                if WIDTH // 2 - u(360) <= mouse_x <= WIDTH // 2 + u(360):
                    world_count = len(list_available_worlds())
                    world_scroll_offset = max(0, min(max(0, world_count - 6),
                                                     world_scroll_offset - event.y))
            elif event.type == pygame.MOUSEWHEEL and inventory_open:
                mouse_x, mouse_y = to_game_position(pygame.mouse.get_pos())
                if mouse_x >= WIDTH - u(500):
                    visible_rows = max(1, (HEIGHT - u(80) - u(110)) // u(125) + 1)
                    total_rows = (len(filtered_inventory_items()) + 4) // 5
                    inventory_scroll_row = max(0, min(total_rows - visible_rows,
                                                     inventory_scroll_row - event.y))
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_h and state == "game" and not current_graphics_store_open and not helper_open and not inventory_open:
                helper_open = not helper_open
                if helper_open:
                    helper_question = ""
                    helper_answer = {"ru": "Привет! Задавай вопросы своими словами — я понимаю разные формулировки и некоторые опечатки.",
                                     "en": "Hi! Ask in your own words. I understand different phrasing and some typos.",
                                     "es": "¡Hola! Pregunta con tus propias palabras; entiendo distintas formas y algunos errores.",
                                     "zh": "你好！可以用自己的话提问，我能理解不同说法和一些拼写错误。",
                                     "ja": "こんにちは！自分の言葉で質問できます。言い換えや一部の誤字も理解します。"}[lang]
                    pygame.key.start_text_input()
                else:
                    pygame.key.stop_text_input()
            elif helper_open and event.type == pygame.TEXTINPUT:
                if event.text.isprintable() and len(helper_question) < 160:
                    helper_question += event.text
            elif helper_open and event.type == pygame.KEYDOWN and event.key == pygame.K_BACKSPACE:
                helper_question = helper_question[:-1]
            elif helper_open and event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                if helper_question.strip():
                    helper_answer = answer_game_question(helper_question.strip())
                    helper_question = ""
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_r and state == "game" and not helper_open:
                if netplay.role == "client":
                    netplay.send({"type": "command", "data": {"action": "fish"}})
                else:
                    fish_action()
            elif state == "network_select" and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    if network_input_focus == "address":
                        network_join_address = network_join_address[:-1]
                    elif network_input_focus == "username":
                        network_username = network_username[:-1]
                    else:
                        network_password = network_password[:-1]
                elif event.key == pygame.K_RETURN:
                    network_input_focus = {"address": "username", "username": "password",
                                           "password": "address"}[network_input_focus]
            elif state == "network_select" and event.type == pygame.TEXTINPUT:
                if not event.text.isprintable():
                    continue
                if network_input_focus == "address" and len(network_join_address) < 80:
                    network_join_address += event.text
                elif network_input_focus == "username" and len(network_username) < 16:
                    network_username += event.text
                elif network_input_focus == "password" and len(network_password) < 128:
                    network_password += event.text
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_F3 and state == "game" and not helper_open:
                show_hitboxes = not show_hitboxes
                last_action_text = LANG_PACK[lang]["hitboxes_on" if show_hitboxes else "hitboxes_off"]
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_f and state == "game" and current_zone == "mine" and not current_graphics_store_open and not helper_open:
                if netplay.role == "client":
                    netplay.send({"type": "command", "data": {"action": "flashlight"}})
                if selected_tool != "flashlight":
                    last_action_text = LANG_PACK[lang]["choose_flashlight"]
                elif flashlight_equipped:
                    flashlight_on = not flashlight_on
                    message_key = "flashlight_on" if flashlight_on else "flashlight_off"
                    last_action_text = LANG_PACK[lang][message_key]
                else:
                    last_action_text = LANG_PACK[lang]["no_flashlight"]
            elif event.type == pygame.KEYDOWN and event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9) and state == "game" and not current_graphics_store_open and not helper_open:
                if event.key == pygame.K_1:
                    select_tool("pickaxe")
                    if netplay.role == "client": netplay.send({"type": "command", "data": {"action": "tool", "tool": "pickaxe"}})
                elif event.key == pygame.K_2:
                    select_tool("flashlight")
                    if netplay.role == "client": netplay.send({"type": "command", "data": {"action": "tool", "tool": "flashlight"}})
                elif event.key == pygame.K_3:
                    select_tool("sword" if owns_sword() else "empty")
                    if netplay.role == "client": netplay.send({"type": "command", "data": {"action": "tool", "tool": selected_tool}})
                elif event.key == pygame.K_4:
                    eat_melon()
                    if netplay.role == "client": netplay.send({"type": "command", "data": {"action": "eat"}})
                elif event.key == pygame.K_5:
                    select_tool("fishing_rod")
                    if netplay.role == "client":
                        netplay.send({"type": "command", "data": {"action": "tool", "tool": "fishing_rod"}})
                elif event.key == pygame.K_6:
                    select_tool("block")
                    if netplay.role == "client":
                        netplay.send({"type": "command", "data": {"action": "tool", "tool": "block"}})
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_e and state == "game" and not current_graphics_store_open and not helper_open:
                if netplay.role == "client":
                    netplay.send({"type": "command", "data": {"action": "interact"}})
                elif current_zone == "surface":
                    if interact_surface():
                        pass
                    elif abs(player_x - OCEAN_ACCESS_X) <= u(180):
                        current_zone = "ocean"
                        player_x, player2_x = u(300), u(390)
                        player_y = player2_y = floor_y
                        player_is_jumping = player2_is_jumping = False
                        y_velocity = player2_y_velocity = 0
                        last_action_text = LANG_PACK[lang]["entered_ocean"]
                    elif abs(player_x - mine_entrance_rect.centerx) <= u(180):
                        current_zone = "mine"
                        player_x = mine_entrance_rect.right + u(15)
                        player2_x = player_x + u(100)
                        last_mine_refresh_time = time.time()
                        flashlight_on = False
                        last_action_text = LANG_PACK[lang]["entered_mine"]
                elif current_zone == "ocean":
                    fishing_state = "idle"
                    current_zone = "surface"
                    player_x, player2_x = OCEAN_ACCESS_X, OCEAN_ACCESS_X + u(90)
                    player_y = player2_y = floor_y
                    player_is_jumping = player2_is_jumping = False
                    y_velocity = player2_y_velocity = 0
                    last_action_text = LANG_PACK[lang]["returned_ocean"]
                elif current_zone == "mine" and abs(player_x - mine_entrance_rect.centerx) <= u(180):
                    current_zone = "surface"
                    player_x = mine_entrance_rect.right + u(15)
                    player2_x = player_x + u(100)
                    flashlight_on = False
                    last_action_text = LANG_PACK[lang]["returned_surface"]
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_pos = to_game_position(event.pos)
                if IS_WEB and state == "game" and not inventory_open and not current_graphics_store_open:
                    if touch_left_rect.collidepoint(mouse_pos) or touch_right_rect.collidepoint(mouse_pos):
                        continue
                    if touch_jump_rect.collidepoint(mouse_pos):
                        touch_jump_requested = True
                        continue
                    if touch_action_rect.collidepoint(mouse_pos):
                        action_key = pygame.K_r if current_zone == "ocean" else pygame.K_e
                        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=action_key, mod=0, unicode=""))
                        continue
                if state == "game" and helper_open:
                    continue
                if state == "game" and not inventory_open and helper_button_rect.collidepoint(mouse_pos):
                    helper_open = True
                    helper_question = ""
                    helper_answer = {"ru": "Привет! Задавай вопросы своими словами — я понимаю разные формулировки и некоторые опечатки.",
                                     "en": "Hi! Ask in your own words. I understand different phrasing and some typos.",
                                     "es": "¡Hola! Pregunta con tus propias palabras; entiendo distintas formas y algunos errores.",
                                     "zh": "你好！可以用自己的话提问，我能理解不同说法和一些拼写错误。",
                                     "ja": "こんにちは！自分の言葉で質問できます。言い換えや一部の誤字も理解します。"}[lang]
                    pygame.key.start_text_input()
                    continue
                shift_held = bool(pygame.key.get_mods() & pygame.KMOD_SHIFT)
                if (state == "game" and shift_held and not inventory_open and
                        not current_graphics_store_open):
                    if netplay.role == "client":
                        netplay.send({"type": "command", "data": {"action": "pet",
                            "x": mouse_pos[0] + camera_x,
                            "y": mouse_pos[1] + (surface_camera_y if current_zone == "surface" else 0)}})
                    else:
                        pet_character_at(mouse_pos[0] + camera_x,
                                         mouse_pos[1] + (surface_camera_y if current_zone == "surface" else 0), 0)
                    continue
                if state == "game" and netplay.role == "client":
                    if current_graphics_store_open:
                        clicked_item = next((name for name, rect in get_store_item_rects().items()
                                             if rect.collidepoint(mouse_pos)), None)
                        if clicked_item:
                            netplay.send({"type": "command", "data": {"action": "store_select", "item": clicked_item}})
                        elif graphics_store_buy_btn_rect.collidepoint(mouse_pos):
                            netplay.send({"type": "command", "data": {"action": "store_buy", "item": selected_store_item}})
                    elif inventory_open:
                        category_index = next((index for index, rect in enumerate(get_inventory_category_rects())
                                               if rect.collidepoint(mouse_pos)), None)
                        if category_index is not None:
                            inventory_category = ("mine", "ocean", "surface", "all")[category_index]
                            inventory_scroll_row = 0
                        else:
                            for item, button in sell_all_buttons.items():
                                if button.collidepoint(mouse_pos) and inventory.get(item, 0) > 0:
                                    netplay.send({"type": "command", "data": {"action": "sell_all", "item": item}})
                                    break
                            else:
                                for item, button in sell_buttons.items():
                                    if button.collidepoint(mouse_pos) and inventory.get(item, 0) > 0:
                                        action = "use_item" if item in MOD_FOOD_ITEMS else "sell"
                                        netplay.send({"type": "command", "data": {"action": action, "item": item}})
                                        break
                    else:
                        _, client_hotbar_slots = get_hotbar_layout()
                        client_clicked_slot = next((index for index, rect in enumerate(client_hotbar_slots)
                                                    if rect.collidepoint(mouse_pos)), None)
                        if current_zone == "surface" and store_hud_rect.collidepoint(mouse_pos):
                            pass
                        elif client_clicked_slot == 3:
                            netplay.send({"type": "command", "data": {"action": "eat"}})
                        elif client_clicked_slot == 4:
                            netplay.send({"type": "command", "data": {"action": "tool", "tool": "fishing_rod"}})
                        elif client_clicked_slot == 5:
                            netplay.send({"type": "command", "data": {"action": "tool", "tool": "block"}})
                        elif client_clicked_slot is not None and client_clicked_slot < 3:
                            client_tool = ("pickaxe", "flashlight", "sword" if owns_sword() else "empty")[client_clicked_slot]
                            netplay.send({"type": "command", "data": {"action": "tool", "tool": client_tool}})
                        else:
                            netplay.send({"type": "command", "data": {"action": "world_click",
                                "x": mouse_pos[0] + camera_x,
                                "y": mouse_pos[1] + (surface_camera_y if current_zone == "surface" else 0)}})
                if state == "network_select" and network_address_rect.collidepoint(mouse_pos):
                    network_input_focus = "address"
                    pygame.key.start_text_input()
                elif state == "network_select" and network_username_rect.collidepoint(mouse_pos):
                    network_input_focus = "username"
                    pygame.key.start_text_input()
                elif state == "network_select" and network_password_rect.collidepoint(mouse_pos):
                    network_input_focus = "password"
                    pygame.key.start_text_input()
                elif state == "network_select" and network_host_button_rect.collidepoint(mouse_pos):
                    try:
                        if NetPlay.vpn_is_active(refresh=True):
                            raise NetPlay.VPNActiveError()
                        if not 6 <= len(network_password) <= 128:
                            raise ValueError("Пароль должен быть длиной от 6 до 128 знаков.")
                        valid, reason, username = authenticate_network_user(
                            network_username, NetPlay.password_proof(network_password))
                        if not valid:
                            raise ValueError(reason)
                        network_password = ""
                        player_names = [username, "Игрок 2"]
                        netplay.authenticator = authenticate_network_user
                        netplay.host()
                        log_system_event("NETWORK HOST", "Создана сетевая игра")
                        network_notice = "\n".join(
                            f"{adapter}: {address}:{netplay.PORT}"
                            for adapter, address in netplay.local_ip_details())
                        netplay.reserved_names.add(username.casefold())
                        player_count = 2
                        if saved_session:
                            current_zone = saved_session["zone"]
                            player_x = saved_session["player_x"]
                            player2_x = saved_session["player2_x"]
                            if current_zone == "mine":
                                next_ore_chunk_x = ((max(player_x, player2_x) // WIDTH) + 1) * WIDTH
                                refresh_mine_ores(max(0, min(player_x, player2_x) - WIDTH // 2))
                                last_mine_refresh_time = time.time()
                        else:
                            current_zone = "surface"
                            player_x, player2_x = u(300), u(390)
                        player_y = player2_y = floor_y
                        player_is_jumping = player2_is_jumping = False
                        y_velocity = player2_y_velocity = 0
                        state = "game"
                        network_error = ""
                    except NetPlay.VPNActiveError:
                        network_error = NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[15]
                    except (OSError, ValueError) as error:
                        network_error = f"{NETWORK_TEXT.get(lang, NETWORK_TEXT['en'])[6]}: {error}"
                elif state == "network_select" and network_join_button_rect.collidepoint(mouse_pos):
                    try:
                        if NetPlay.vpn_is_active(refresh=True):
                            raise NetPlay.VPNActiveError()
                        netplay.join(network_join_address, network_username, network_password)
                        log_system_event("NETWORK CONNECT", "Игра подключилась к серверу")
                        player_count = 2
                        network_password = ""
                        if 0 <= netplay.player_index < len(player_names):
                            player_names[netplay.player_index] = netplay.player_name
                        current_zone = "surface"
                        player_x, player2_x = u(300), u(390)
                        player_y = player2_y = floor_y
                        state = "game"
                        network_error = ""
                        pygame.key.stop_text_input()
                    except NetPlay.VPNActiveError:
                        network_error = NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[15]
                    except (OSError, ValueError) as error:
                        network_error = f"{NETWORK_TEXT.get(lang, NETWORK_TEXT['en'])[6]}: {error}"
                elif state == "network_select" and network_dedicated_button_rect.collidepoint(mouse_pos):
                    try:
                        if NetPlay.vpn_is_active(refresh=True):
                            raise NetPlay.VPNActiveError()
                        if getattr(sys, "frozen", False):
                            base_directory = os.path.dirname(os.path.dirname(sys.executable))
                            server_executable = os.path.join(base_directory, "StickmanInMineServer",
                                                             "StickmanInMineServer.exe")
                            if not os.path.isfile(server_executable):
                                raise FileNotFoundError("StickmanInMineServer.exe")
                            server_command = [server_executable]
                            working_directory = os.path.dirname(server_executable)
                        else:
                            script_path = os.path.abspath(sys.argv[0])
                            server_command = [sys.executable, script_path, "--server"]
                            working_directory = os.path.dirname(script_path)
                        subprocess.Popen(server_command, cwd=working_directory,
                                         creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
                        network_notice = (NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[11] +
                                          " " + NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[12].format("127.0.0.1"))
                        network_error = ""
                    except NetPlay.VPNActiveError:
                        network_error = NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])[15]
                    except (OSError, FileNotFoundError) as error:
                        network_error = f"{NETWORK_TEXT.get(lang, NETWORK_TEXT['en'])[6]}: {error}"
                if exit_button_rect.collidepoint(mouse_pos):
                    if state == "game":
                        save_progress()
                        netplay.stop()
                        current_graphics_store_open = False
                        inventory_open = False
                        helper_open = False
                        ensure_worlds_directory()
                        world_name_input = ""
                        world_notice = ""
                        world_scroll_offset = 0
                        pygame.key.start_text_input()
                        state = "world_select"
                    else:
                        running = False
                elif state == "menu":
                    selected_language = next((code for code, rect in LANGUAGE_BUTTON_RECTS.items()
                                              if rect.collidepoint(mouse_pos)), None)
                    if selected_language:
                        lang, state = selected_language, "player_select"
                        set_language_fonts(lang)
                    elif settings_menu_button_rect.collidepoint(mouse_pos):
                        state = "settings"
                elif state == "settings":
                    if settings_fullscreen_rect.collidepoint(mouse_pos):
                        toggle_fullscreen()
                    elif settings_volume_down_rect.collidepoint(mouse_pos):
                        set_master_volume(round(master_volume * 100) - 10)
                    elif settings_volume_up_rect.collidepoint(mouse_pos):
                        set_master_volume(round(master_volume * 100) + 10)
                    elif settings_volume_track_rect.collidepoint(mouse_pos):
                        amount = (mouse_pos[0] - settings_volume_track_rect.x) / settings_volume_track_rect.width
                        set_master_volume(round(amount * 100))
                    elif settings_back_rect.collidepoint(mouse_pos):
                        state = "menu"
                elif state == "player_select":
                    if one_player_button_rect.collidepoint(mouse_pos):
                        player_count = 1
                        netplay.stop()
                        ensure_worlds_directory()
                        world_name_input = ""
                        world_notice = ""
                        world_scroll_offset = 0
                        state = "world_select"
                        pygame.key.start_text_input()
                    elif two_player_button_rect.collidepoint(mouse_pos):
                        network_join_address = ""
                        network_username = ""
                        network_password = ""
                        network_input_focus = "address"
                        network_error = ""
                        network_notice = ""
                        state = "network_select"
                        pygame.key.start_text_input()
                    else:
                        player_count = 0
                elif state == "world_select":
                    if world_name_input_rect.collidepoint(mouse_pos):
                        pygame.key.start_text_input()
                    elif world_create_button_rect.collidepoint(mouse_pos):
                        new_world_id = create_world(world_name_input)
                        if new_world_id and open_world(new_world_id):
                            configure_world_start()
                            player_count = 1
                            world_notice = ""
                            pygame.key.stop_text_input()
                            state = "game"
                        else:
                            world_notice = "Введи название мира" if not world_name_input.strip() else "Не получилось создать мир"
                    else:
                        selected_world = next((world_id for world_id, rect in world_row_buttons
                                               if rect.collidepoint(mouse_pos)), None)
                        if selected_world:
                            if open_world(selected_world):
                                configure_world_start()
                                player_count = 1
                                pygame.key.stop_text_input()
                                state = "game"
                            else:
                                world_notice = "Не получилось открыть мир"
                elif current_graphics_store_open:
                    clicked_item = next((name for name, rect in get_store_item_rects().items()
                                         if rect.collidepoint(mouse_pos)), None)
                    if clicked_item:
                        selected_store_item = clicked_item
                    elif graphics_store_buy_btn_rect.collidepoint(mouse_pos):
                        if store_item_owned(selected_store_item):
                            last_action_text = LANG_PACK[lang]["store_item_owned"]
                        elif buy_store_item(selected_store_item):
                            if selected_store_item in ("sword", "stone_sword", "iron_sword"):
                                select_tool("sword")
                            last_action_text = LANG_PACK[lang]["owned"]
                        else:
                            last_action_text = LANG_PACK[lang]["no_money"]
                elif (state == "game" and current_zone == "surface" and
                      store_hud_rect.collidepoint(mouse_pos)):
                    current_graphics_store_open = True
                elif state == "game" and current_zone == "mine" and not inventory_open:
                    _, hotbar_slots = get_hotbar_layout()
                    clicked_slot = next((index for index, rect in enumerate(hotbar_slots) if rect.collidepoint(mouse_pos)), None)
                    if clicked_slot is not None:
                        if clicked_slot == 3:
                            eat_melon()
                        elif clicked_slot == 4:
                            select_tool("fishing_rod")
                        elif clicked_slot == 5:
                            select_tool("block")
                        elif clicked_slot < 3:
                            select_tool(("pickaxe", "flashlight", "sword" if owns_sword() else "empty")[clicked_slot])
                    elif (damage_other_player_at(mouse_pos, camera_x)
                          or damage_boulder_at(mouse_pos, max(0, ((player_x + player2_x) // 2 if player_count == 2 else player_x) - WIDTH // 2))
                          or damage_dandelion_at(mouse_pos, max(0, ((player_x + player2_x) // 2 if player_count == 2 else player_x) - WIDTH // 2))):
                        pass
                    elif inventory_button_rect.collidepoint(mouse_pos):
                        inventory_open = not inventory_open
                elif state == "game" and current_zone == "surface" and not inventory_open:
                    _, hotbar_slots = get_hotbar_layout()
                    clicked_slot = next((index for index, rect in enumerate(hotbar_slots) if rect.collidepoint(mouse_pos)), None)
                    if clicked_slot == 3:
                        eat_melon()
                    elif clicked_slot == 4:
                        select_tool("fishing_rod")
                    elif clicked_slot == 5:
                        select_tool("block")
                    elif clicked_slot is not None and clicked_slot < 3:
                        select_tool(("pickaxe", "flashlight", "sword" if owns_sword() else "empty")[clicked_slot])
                    elif inventory_button_rect.collidepoint(mouse_pos):
                        inventory_open = True
                    elif selected_tool == "block":
                        place_stone_block(mouse_pos[0] + camera_x,
                                           mouse_pos[1] + surface_camera_y, 0)
                    elif selected_tool == "pickaxe" and mine_placed_block(
                            mouse_pos[0] + camera_x, mouse_pos[1] + surface_camera_y):
                        pass
                    elif (damage_other_player_at(mouse_pos, camera_x, vertical_camera=surface_camera_y)
                          or damage_surface_pig_at(mouse_pos, camera_x, surface_camera_y)):
                        pass
                elif inventory_button_rect.collidepoint(mouse_pos):
                    inventory_open = not inventory_open
                elif inventory_open:
                    category_index = next((index for index, rect in enumerate(get_inventory_category_rects())
                                           if rect.collidepoint(mouse_pos)), None)
                    if category_index is not None:
                        inventory_category = ("mine", "ocean", "surface", "all")[category_index]
                        inventory_scroll_row = 0
                    else:
                        for item, button in sell_all_buttons.items():
                            if button.collidepoint(mouse_pos) and inventory[item] > 0:
                                sell_all_inventory_item(item)
                                break
                        else:
                            for item, button in sell_buttons.items():
                                if button.collidepoint(mouse_pos) and inventory[item] > 0:
                                    use_inventory_item(item)
                                    break

        if state == "menu":
            run_menu_graphics()
        elif state == "settings":
            run_settings_graphics()
        elif state == "player_select":
            run_player_select_graphics()
        elif state == "world_select":
            run_world_select_graphics()
        elif state == "network_select":
            run_network_select_graphics()
        else:
            update_network_play(time.time())
            screen.fill((95, 145, 180) if current_zone == "surface" else (35, 35, 42))
            run_game_logic_and_graphics()
            draw_game_ui()
            if not inventory_open:
                draw_hotbar()
            draw_game_helper()
            if IS_WEB and not inventory_open and not current_graphics_store_open and not helper_open:
                draw_touch_controls()
            if current_graphics_store_open:
                draw_store()
            if netplay.role == "host":
                texts = NETWORK_TEXT.get(lang, NETWORK_TEXT["en"])
                status = (texts[5] if netplay.connected else texts[4])
                status_surface = font_sub.render(status, True, (255, 230, 120))
                screen.blit(status_surface, (WIDTH // 2 - status_surface.get_width() // 2, u(8)))
                if not netplay.connected:
                    internet_hint = font_sub.render(texts[8].format(netplay.PORT), True, (225, 225, 225))
                    screen.blit(internet_hint, (WIDTH // 2 - internet_hint.get_width() // 2, u(30)))
            elif netplay.role == "client" and not netplay.connected:
                status_surface = font_sub.render(texts[9], True, (255, 150, 130))
                screen.blit(status_surface, (WIDTH // 2 - status_surface.get_width() // 2, u(8)))

        present_frame()
        if state == "game" and netplay.role != "client" and time.time() - last_auto_save >= 30:
            save_ok = save_progress()
            log_system_event("AUTO SAVE", "Прогресс сохранён" if save_ok else "Не удалось сохранить прогресс")
            last_auto_save = time.time()
        physics_step = min(max(clock.tick(60) / (1000 / 60), 0.05), 2.0)
        touch_jump_requested = False
        await asyncio.sleep(0)

    save_progress()
    netplay.stop()
    show_saving_screen()
    pygame.quit()


if __name__ == "__main__":
    try:
        if DEDICATED_SERVER_MODE:
            log_system_event("SERVER START", "Запущен выделенный сервер")
            run_dedicated_server()
        else:
            log_system_event("GAME START", "Игра запущена")
            asyncio.run(main())
    except Exception:
        error_report = traceback.format_exc()
        crash_log_path = log_crash(error_report)
        if not DEDICATED_SERVER_MODE:
            try:
                message = "Игра неожиданно закрылась."
                if crash_log_path:
                    message += f"\nОписание ошибки сохранено сюда:\n{crash_log_path}"
                ctypes.windll.user32.MessageBoxW(None, message, "Stickman in Mine", 0x10)
            except (AttributeError, OSError):
                pass
        raise
